# NovaPlayer

Offline Android video player (Kotlin, Jetpack Compose, Material 3, AndroidX Media3 ExoPlayer) built around one workflow:
download several videos with 1DM into one folder, open one with **Open with → NovaPlayer**, then use **Next / Previous**
to move through the rest of that folder without going back to 1DM.

> **Status: source only. This project has not been compiled, installed or run.**
> It was written in an environment with no Android SDK, Gradle or network, so there was no build, no unit-test run,
> no emulator or device test, and no APK. Dependency versions were chosen from memory and could not be resolved.
> Expect to fix a few compile errors on the first build. See "Testing report" below.

## Build

Requirements: JDK 17, Android SDK platform 36 + build-tools 36.0.0 (Android Studio installs both).

**Android Studio** — open the project folder, let it sync, then Run, or Build > Build APK(s).

**Command line**

```
gradle wrapper --gradle-version 8.11.1     # once; creates gradle/wrapper/gradle-wrapper.jar
./gradlew testDebugUnitTest
./gradlew assembleDebug                      # app/build/outputs/apk/debug/app-debug.apk
```

`gradle-wrapper.jar` is a binary and is not included; `gradlew` tells you how to create it.

**GitHub Actions** — push to GitHub; `.github/workflows/android.yml` runs the unit tests, builds the debug APK and
uploads it as the `NovaPlayer-debug-apk` artifact. This is the quickest way to get an APK without installing anything.

If a dependency version fails to resolve, bump it in `app/build.gradle.kts` / root `build.gradle.kts`
(AGP 8.9.1, Kotlin 2.1.20, Compose BOM 2025.04.01, Media3 1.6.1, Coil 2.7.0, DataStore 1.1.2).

## How the 1DM flow works

Android gives the receiving app access to the one file it is handed, not to the folder. NovaPlayer therefore:

1. Registers `ACTION_VIEW` (and `ACTION_SEND`) filters for `video/*`, `audio/*`, Matroska, MP4, WebM, QuickTime, 3GP, MPEG, TS, AVI and M4V on `content:` and `file:` URIs. The URI is read from Intent data, `EXTRA_STREAM` or `ClipData`.
2. Starts playing the selected file immediately.
3. In the background (`PlaylistResolver`), looks for the folder, in this order:
   1. the URI is an ExternalStorageProvider document inside a folder you already authorised;
   2. MediaStore — the URI, or the file's display name and size, is matched to an indexed video and its folder (`RELATIVE_PATH`) is listed. Needs the video permission;
   3. a bounded search of the folders you authorised (name + size match).
4. Sorts the folder naturally by file name (`video2` before `video10`) and **adds the other videos around the playing item without restarting it**. Next/Previous are real playlist moves.
5. If nothing works, a prompt appears in the player ("Enable Next and Previous") with **Choose folder** and **Allow video access** buttons. There is no endless spinner.
6. The picked folder is stored with `takePersistableUriPermission` (read-only) and reused automatically, so the prompt appears once per download folder.

Android 11+ does not let you pick the top-level `Download` folder itself; pick the specific subfolder (for example `Download/1DM`).

## Features

- Home: continue watching, recent, recently added, favourites, folders, search.
- Folders: internal storage tree or flat list, nested folders, authorised-folder browsing (SAF), counts, duration, size, resolution, modified date, sorting, search, refresh, last folder remembered, excluded folders.
- Videos: grid/list, thumbnails, multi-select, favourites, history.
- Player: play/pause, previous/next, seek bar with elapsed/total/remaining, ±10 s, auto-hiding controls, double-tap seek, horizontal swipe seek, left-side brightness, right-side volume, configurable sensitivity, speed 0.25x–4x, fit/fill/stretch/crop, rotation, screen lock, resume, remembered speed/aspect, sleep timer, picture-in-picture, background audio with media notification, audio-only mode, queue, audio-track selection, hardware/software decoder preference.
- Subtitles: SRT, ASS/SSA (text only), WebVTT, embedded text tracks, external files, size, colour, position, background, delay (±0.1 / 0.5 s, external files only), automatic same-name file when the folder is readable.
- Settings: general, appearance, player, gestures, subtitles, library, storage permissions, folder management, playback preferences, about.

## Permissions

| Permission | Why |
|---|---|
| `READ_MEDIA_VIDEO` (Android 13+) / `READ_EXTERNAL_STORAGE` (≤ 12L) | List the library and find sibling videos through MediaStore |
| `FOREGROUND_SERVICE`, `FOREGROUND_SERVICE_MEDIA_PLAYBACK` | Background audio |
| `POST_NOTIFICATIONS` | Playback controls while audio plays in the background |
| `WAKE_LOCK` | Keep playing with the screen off |

Not requested: `INTERNET`, `MANAGE_EXTERNAL_STORAGE`, location, contacts, microphone. No ads, analytics, tracking or accounts.

## Project layout

```
app/src/main/java/com/novaplayer/app/
  MainActivity.kt, NovaApp.kt
  data/        MediaRepository (MediaStore + SAF), LibraryStore, SettingsRepository, Models
  playback/    PlaylistResolver (1DM logic), PlayerHolder, PlaybackService
  player/      PlayerActivity, PlayerViewModel, PlayerScreen
  ui/          NovaRoot, LibraryViewModel, screens/, components/, theme/
  util/        NaturalOrder, DocIds, SubtitleParser, Fmt, MediaTypes, Permissions
app/src/test/            JVM unit tests (natural sort, SAF doc ids, subtitle parsing, formatting)
app/src/androidTest/     device tests for intent-filter resolution and the no-INTERNET guarantee
```

## Testing report

| Check | Result |
|---|---|
| Gradle sync / clean build | **Not run** (no SDK or network where this was written) |
| Kotlin compilation | **Not run** |
| Debug APK | **Not produced** — build with the steps above or GitHub Actions |
| Unit tests (`UtilTests.kt`) | Written, **not run** |
| Instrumented tests | Written, **not run** |
| Install / playback on a device | **Not tested** |
| 1DM → Open with → NovaPlayer → playlist → Next/Previous | **Not tested** — no 1DM, device or emulator was available |
| Folder discovery, folder-picker fallback, persisted access after restart | **Not tested** |
| Static checks | Brace balance, package/directory match and `R.*` references were checked by script |

To verify the main workflow yourself: download five videos with 1DM into one folder, open one via Open with →
NovaPlayer, confirm playback, confirm the folder is found (or the prompt appears and works), press Next and Previous,
force-stop the app, repeat, and confirm no prompt appears the second time.

## Known limitations

- The first build may need small fixes (unverified code and dependency versions).
- **AVI** is not handled by Media3's built-in extractors and may not play.
- Codecs depend on the phone: AC-3 / E-AC-3 / DTS / TrueHD audio, and some HEVC or AV1 profiles, may be silent or fail. No FFmpeg extension is bundled.
- ASS/SSA is rendered as plain text (no styling, positioning or effects). PGS/VobSub image subtitles are not shown.
- Subtitle delay applies to external subtitle files only, not embedded tracks.
- If 1DM hands over a URI whose file cannot be matched in MediaStore and you have not authorised the folder, Next/Previous stay off until you choose the folder.
- With only a temporary URI grant (no MediaStore or folder access), background audio ends when the player screen closes because Android revokes that grant.
- Android 16 ignores fixed orientation on large screens (tablets, foldables unfolded); the rotate button and orientation setting only apply to phone-sized windows.
- Release builds are not minified or signed; only the debug build is wired up.
