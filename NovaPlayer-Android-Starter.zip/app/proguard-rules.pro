# Release builds are not minified by default. Add rules here if you enable isMinifyEnabled.
-keep class androidx.media3.** { *; }
