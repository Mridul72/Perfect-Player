package com.novaplayer.app.playback

import android.content.Context
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.exoplayer.DefaultRenderersFactory
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.mediacodec.MediaCodecSelector

/**
 * One ExoPlayer for the whole process, shared by PlayerActivity (UI) and PlaybackService
 * (MediaSession + notification), so audio keeps playing when the activity goes away.
 */
object PlayerHolder {
    private var player: ExoPlayer? = null

    /** Read each time a codec is created; takes effect on the next prepare(). */
    @Volatile
    var preferSoftware: Boolean = false

    fun get(context: Context): ExoPlayer =
        player ?: synchronized(this) {
            player ?: build(context.applicationContext).also { player = it }
        }

    private fun build(ctx: Context): ExoPlayer {
        val selector = MediaCodecSelector { mimeType, secure, tunneling ->
            val infos = MediaCodecSelector.DEFAULT.getDecoderInfos(mimeType, secure, tunneling)
            if (preferSoftware) infos.sortedBy { !it.softwareOnly } else infos
        }
        val renderers = DefaultRenderersFactory(ctx)
            .setEnableDecoderFallback(true)
            .setMediaCodecSelector(selector)
        return ExoPlayer.Builder(ctx, renderers)
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(C.USAGE_MEDIA)
                    .setContentType(C.AUDIO_CONTENT_TYPE_MOVIE)
                    .build(),
                true,
            )
            .setHandleAudioBecomingNoisy(true)
            .setWakeMode(C.WAKE_MODE_LOCAL)
            .setSeekBackIncrementMs(10_000)
            .setSeekForwardIncrementMs(10_000)
            .build()
    }
}
