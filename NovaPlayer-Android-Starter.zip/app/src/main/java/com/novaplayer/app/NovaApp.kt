package com.novaplayer.app

import android.app.Application
import android.content.Context
import coil.ImageLoader
import coil.ImageLoaderFactory
import coil.decode.VideoFrameDecoder
import coil.disk.DiskCache
import coil.memory.MemoryCache
import com.novaplayer.app.data.LibraryStore
import com.novaplayer.app.data.MediaRepository
import com.novaplayer.app.data.SettingsRepository
import com.novaplayer.app.playback.PlaylistResolver
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob

class NovaApp : Application(), ImageLoaderFactory {
    /** For fire-and-forget writes that must survive a screen closing. */
    val appScope = CoroutineScope(SupervisorJob() + Dispatchers.Default)

    val settings by lazy { SettingsRepository(this) }
    val library by lazy { LibraryStore(this) }
    val media by lazy { MediaRepository(this) }
    val resolver by lazy { PlaylistResolver(this, media, library) }

    override fun newImageLoader(): ImageLoader =
        ImageLoader.Builder(this)
            .components { add(VideoFrameDecoder.Factory()) }
            .memoryCache { MemoryCache.Builder(this).maxSizePercent(0.20).build() }
            .diskCache {
                DiskCache.Builder()
                    .directory(cacheDir.resolve("thumbs"))
                    .maxSizePercent(0.02)
                    .build()
            }
            .crossfade(true)
            .build()
}

val Context.nova: NovaApp get() = applicationContext as NovaApp
