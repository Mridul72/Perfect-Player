package com.novaplayer.app.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Movie
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.VideoLibrary
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.novaplayer.app.data.FolderOps
import com.novaplayer.app.data.VideoItem
import com.novaplayer.app.ui.AppActions
import com.novaplayer.app.ui.LibraryViewModel
import com.novaplayer.app.ui.Loc
import com.novaplayer.app.ui.components.EmptyState
import com.novaplayer.app.ui.components.FolderRow
import com.novaplayer.app.ui.components.SectionHeader
import com.novaplayer.app.ui.components.VideoCard

@Composable
fun HomeScreen(
    vm: LibraryViewModel,
    actions: AppActions,
    onSearch: () -> Unit,
    onOpenTab: (Int) -> Unit,
) {
    val videos by vm.videos.collectAsStateWithLifecycle()
    val history by vm.history.collectAsStateWithLifecycle()
    val favs by vm.favourites.collectAsStateWithLifecycle()
    val hasPermission by vm.hasPermission.collectAsStateWithLifecycle()
    val loading by vm.loading.collectAsStateWithLifecycle()
    val settings by vm.settings.collectAsStateWithLifecycle()

    val continueWatching = remember(history) { history.filter { it.resumable } }
    val recent = remember(history) { history.take(15) }
    val added = remember(videos) { videos.sortedByDescending { it.dateAddedSec }.take(20) }
    val folders = remember(videos) { FolderOps.flat(videos).sortedByDescending { it.count }.take(5) }
    val progress = remember(history) { history.associate { it.video.key to it.progress } }

    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 24.dp)) {
        item {
            Row(
                Modifier.fillMaxWidth().padding(start = 20.dp, end = 8.dp, top = 12.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Column(Modifier.weight(1f)) {
                    Text("NovaPlayer", style = MaterialTheme.typography.headlineMedium)
                    Text(
                        if (hasPermission) "${videos.size} videos" else "Library not connected",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
                IconButton(onClick = vm::refresh) { Icon(Icons.Rounded.Refresh, "Refresh library") }
                IconButton(onClick = onSearch) { Icon(Icons.Rounded.Search, "Search") }
            }
        }

        if (!hasPermission) {
            item {
                EmptyState(
                    Icons.Rounded.VideoLibrary,
                    "Allow access to your videos",
                    "NovaPlayer plays files offline and never uploads anything. Videos opened from another app still play without this.",
                    "Allow video access",
                    actions.requestMedia,
                )
            }
        } else if (videos.isEmpty() && !loading) {
            item {
                EmptyState(
                    Icons.Rounded.Movie,
                    "No videos found",
                    "Download or copy a video to this phone, then pull the library to refresh.",
                    "Refresh",
                    vm::refresh,
                )
            }
        }

        if (continueWatching.isNotEmpty()) {
            item { SectionHeader("Continue watching") }
            item {
                VideoStrip(continueWatching.map { it.video }, progress, settings.showThumbnails) { list, i ->
                    actions.play(list, i)
                }
            }
        }
        if (recent.isNotEmpty()) {
            item { SectionHeader("Recent", "See all") { onOpenTab(2) } }
            item {
                VideoStrip(recent.map { it.video }, progress, settings.showThumbnails) { list, i -> actions.play(list, i) }
            }
        }
        if (added.isNotEmpty()) {
            item { SectionHeader("Recently added") }
            item { VideoStrip(added, progress, settings.showThumbnails) { list, i -> actions.play(list, i) } }
        }
        if (favs.isNotEmpty()) {
            item { SectionHeader("Favourites") }
            item { VideoStrip(favs, progress, settings.showThumbnails) { list, i -> actions.play(list, i) } }
        }
        if (folders.isNotEmpty()) {
            item { SectionHeader("Folders", "Browse") { onOpenTab(1) } }
            itemsIndexed(folders) { _, f ->
                FolderRow(
                    title = f.name,
                    subtitle = "${f.count} videos  ·  ${f.path.trimEnd('/').ifEmpty { "Storage root" }}",
                    thumb = f.thumb,
                    onClick = {
                        vm.navigate(Loc.Device(f.path))
                        onOpenTab(1)
                    },
                )
            }
        }
    }
}

@Composable
private fun VideoStrip(
    items: List<VideoItem>,
    progress: Map<String, Float>,
    showThumb: Boolean,
    onPlay: (List<VideoItem>, Int) -> Unit,
) {
    LazyRow(
        contentPadding = PaddingValues(horizontal = 16.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        itemsIndexed(items) { i, v ->
            VideoCard(
                v,
                Modifier.width(220.dp),
                progress = progress[v.key]?.takeIf { it < 0.95f } ?: 0f,
                showThumb = showThumb,
                onClick = { onPlay(items, i) },
            )
        }
    }
}
