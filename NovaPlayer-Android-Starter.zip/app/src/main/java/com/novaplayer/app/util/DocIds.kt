package com.novaplayer.app.util

/**
 * Pure helpers for Storage Access Framework document ids of the ExternalStorageProvider,
 * e.g. "primary:Download/1DM/video.mp4" or "1A2B-3C4D:Movies/x.mkv".
 */
object DocIds {
    const val EXTERNAL_STORAGE_AUTHORITY = "com.android.externalstorage.documents"

    /** Document id of the folder that contains [docId]. */
    fun parentOf(docId: String): String {
        val slash = docId.lastIndexOf('/')
        if (slash >= 0) return docId.substring(0, slash)
        val colon = docId.indexOf(':')
        return if (colon >= 0) docId.substring(0, colon + 1) else docId
    }

    /** True when [docId] is the tree root itself or lies below it. */
    fun covers(treeDocId: String, docId: String): Boolean {
        val t = treeDocId.trimEnd('/')
        return docId == t || docId.startsWith("$t/") || (t.endsWith(":") && docId.startsWith(t))
    }

    /** Converts a MediaStore volume + relative folder ("Download/1DM/") into a document id. */
    fun forFolder(volume: String, folderPath: String): String {
        val vol = if (volume.isEmpty() || volume == "external_primary") "primary" else volume.uppercase()
        return vol + ":" + folderPath.trim('/')
    }
}
