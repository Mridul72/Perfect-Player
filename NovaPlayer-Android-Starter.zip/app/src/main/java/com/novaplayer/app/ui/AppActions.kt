package com.novaplayer.app.ui

import com.novaplayer.app.data.VideoItem

/** Things the Compose screens ask the hosting Activity to do. */
class AppActions(
    val play: (List<VideoItem>, Int) -> Unit,
    val requestMedia: () -> Unit,
    val requestNotifications: () -> Unit,
    val addFolder: () -> Unit,
    val openAppSettings: () -> Unit,
    val hasNotificationPermission: () -> Boolean,
)
