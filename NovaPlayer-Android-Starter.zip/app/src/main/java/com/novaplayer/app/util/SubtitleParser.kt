package com.novaplayer.app.util

import java.nio.ByteBuffer
import java.nio.charset.CharacterCodingException
import java.nio.charset.Charset
import java.nio.charset.CodingErrorAction

data class SubCue(val startMs: Long, val endMs: Long, val text: String)

/** Parses SRT, WebVTT and (basic) SSA/ASS subtitles into plain-text cues. */
object SubtitleParser {

    private val TIME = Regex(
        """((?:\d+:)?\d{1,2}:\d{2}[,.]\d{1,3})\s*-->\s*((?:\d+:)?\d{1,2}:\d{2}[,.]\d{1,3})"""
    )
    private val HTML_TAG = Regex("<[^>]*>")
    private val BRACES = Regex("\\{[^}]*\\}")

    fun parse(fileName: String, content: String): List<SubCue> {
        val text = content.removePrefix("\uFEFF")
        val ext = fileName.substringAfterLast('.', "").lowercase()
        return if (ext == "ass" || ext == "ssa" || text.contains("[Script Info]")) parseAss(text)
        else parseBlocks(text)
    }

    /** Detects BOM / UTF-8 and falls back to Windows-1252 for legacy subtitle files. */
    fun decode(bytes: ByteArray): String {
        if (bytes.size >= 2) {
            val b0 = bytes[0].toInt() and 0xFF
            val b1 = bytes[1].toInt() and 0xFF
            if (b0 == 0xFF && b1 == 0xFE) return String(bytes, 2, bytes.size - 2, Charsets.UTF_16LE)
            if (b0 == 0xFE && b1 == 0xFF) return String(bytes, 2, bytes.size - 2, Charsets.UTF_16BE)
        }
        val offset = if (bytes.size >= 3 && bytes[0] == 0xEF.toByte() &&
            bytes[1] == 0xBB.toByte() && bytes[2] == 0xBF.toByte()
        ) 3 else 0
        return try {
            Charsets.UTF_8.newDecoder()
                .onMalformedInput(CodingErrorAction.REPORT)
                .onUnmappableCharacter(CodingErrorAction.REPORT)
                .decode(ByteBuffer.wrap(bytes, offset, bytes.size - offset))
                .toString()
        } catch (e: CharacterCodingException) {
            String(bytes, offset, bytes.size - offset, Charset.forName("windows-1252"))
        }
    }

    /** Text of every cue visible at [posMs] (cues are sorted by start time). */
    fun active(cues: List<SubCue>, posMs: Long): String? {
        if (cues.isEmpty()) return null
        var lo = 0
        var hi = cues.size - 1
        var idx = -1
        while (lo <= hi) {
            val mid = (lo + hi) ushr 1
            if (cues[mid].startMs <= posMs) {
                idx = mid
                lo = mid + 1
            } else {
                hi = mid - 1
            }
        }
        if (idx < 0) return null
        val found = ArrayList<String>()
        var k = idx
        var scanned = 0
        while (k >= 0 && scanned < 8) {
            val c = cues[k]
            if (c.endMs > posMs) found.add(0, c.text)
            k--
            scanned++
        }
        return if (found.isEmpty()) null else found.joinToString("\n")
    }

    private fun parseBlocks(content: String): List<SubCue> {
        val lines = content.replace("\r\n", "\n").replace('\r', '\n').split('\n')
        val out = ArrayList<SubCue>()
        var i = 0
        while (i < lines.size) {
            val m = TIME.find(lines[i])
            if (m != null) {
                val start = ts(m.groupValues[1])
                val end = ts(m.groupValues[2])
                val sb = StringBuilder()
                i++
                while (i < lines.size && lines[i].isNotBlank()) {
                    if (sb.isNotEmpty()) sb.append('\n')
                    sb.append(lines[i])
                    i++
                }
                val text = clean(sb.toString())
                if (text.isNotEmpty()) out += SubCue(start, end, text)
            } else {
                i++
            }
        }
        return out.sortedBy { it.startMs }
    }

    private fun parseAss(text: String): List<SubCue> {
        val lines = text.replace("\r\n", "\n").replace('\r', '\n').split('\n')
        var inEvents = false
        var startIdx = 1
        var endIdx = 2
        var textIdx = 9
        var cols = 10
        val out = ArrayList<SubCue>()
        for (raw in lines) {
            val line = raw.trim()
            if (line.startsWith("[")) {
                inEvents = line.equals("[Events]", ignoreCase = true)
                continue
            }
            if (!inEvents) continue
            if (line.startsWith("Format:", ignoreCase = true)) {
                val names = line.substringAfter(':').split(',').map { it.trim().lowercase() }
                cols = names.size
                names.indexOf("start").takeIf { it >= 0 }?.let { startIdx = it }
                names.indexOf("end").takeIf { it >= 0 }?.let { endIdx = it }
                names.indexOf("text").takeIf { it >= 0 }?.let { textIdx = it }
            } else if (line.startsWith("Dialogue:", ignoreCase = true)) {
                val parts = line.substringAfter(':').trimStart().split(',', limit = cols)
                if (parts.size <= maxOf(startIdx, endIdx, textIdx)) continue
                val s = runCatching { ts(parts[startIdx]) }.getOrNull() ?: continue
                val e = runCatching { ts(parts[endIdx]) }.getOrNull() ?: continue
                val t = clean(parts[textIdx].replace("\\N", "\n").replace("\\n", "\n"))
                if (t.isNotEmpty()) out += SubCue(s, e, t)
            }
        }
        return out.sortedBy { it.startMs }
    }

    private fun ts(s: String): Long {
        val parts = s.trim().replace(',', '.').split(':')
        val secParts = parts.last().split('.')
        val sec = secParts[0].toLong()
        val ms = secParts.getOrElse(1) { "0" }.padEnd(3, '0').take(3).toLong()
        val min = parts[parts.size - 2].toLong()
        val h = if (parts.size >= 3) parts[parts.size - 3].toLong() else 0L
        return ((h * 60 + min) * 60 + sec) * 1000 + ms
    }

    private fun clean(s: String): String = s
        .replace(HTML_TAG, "")
        .replace(BRACES, "")
        .replace("&nbsp;", " ")
        .replace("&lt;", "<")
        .replace("&gt;", ">")
        .replace("&amp;", "&")
        .trim()
}
