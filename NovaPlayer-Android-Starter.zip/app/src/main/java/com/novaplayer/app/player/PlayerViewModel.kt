package com.novaplayer.app.player

import android.app.Application
import android.net.Uri
import android.provider.OpenableColumns
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.PlaybackException
import androidx.media3.common.PlaybackParameters
import androidx.media3.common.Player
import androidx.media3.common.Timeline
import androidx.media3.common.TrackSelectionOverride
import androidx.media3.common.Tracks
import androidx.media3.common.VideoSize
import androidx.media3.common.text.CueGroup
import androidx.media3.exoplayer.ExoPlayer
import com.novaplayer.app.NovaApp
import com.novaplayer.app.data.AppSettings
import com.novaplayer.app.data.VideoItem
import com.novaplayer.app.playback.PlayerHolder
import com.novaplayer.app.playback.PlaylistResolver
import com.novaplayer.app.util.MediaTypes
import com.novaplayer.app.util.SubCue
import com.novaplayer.app.util.SubtitleParser
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.Locale

enum class FolderStatus { NONE, RESOLVING, FOUND, NEEDS_FOLDER }

enum class SubMode { OFF, EMBEDDED, EXTERNAL }

data class TrackOption(
    val label: String,
    val selected: Boolean,
    val group: Tracks.Group?,
    val index: Int,
)

data class PosInfo(val position: Long = 0, val duration: Long = 0, val buffered: Long = 0)

data class PlayerUi(
    val isPlaying: Boolean = false,
    val buffering: Boolean = false,
    val ended: Boolean = false,
    val title: String = "",
    val index: Int = 0,
    val count: Int = 0,
    val hasNext: Boolean = false,
    val hasPrev: Boolean = false,
    val queue: List<VideoItem> = emptyList(),
    val speed: Float = 1f,
    val resize: Int = 0,
    val videoWidth: Int = 0,
    val videoHeight: Int = 0,
    val audioTracks: List<TrackOption> = emptyList(),
    val textTracks: List<TrackOption> = emptyList(),
    val subMode: SubMode = SubMode.OFF,
    val cueText: String? = null,
    val subtitleDelayMs: Long = 0,
    val externalSubName: String? = null,
    val audioOnly: Boolean = false,
    val repeatMode: Int = 0,
    val folderStatus: FolderStatus = FolderStatus.NONE,
    val folderLabel: String = "",
    val folderMessage: String? = null,
    val promptDismissed: Boolean = false,
    val sleepRemainingMs: Long = 0,
    val sleepAtEnd: Boolean = false,
    val error: String? = null,
    val toast: String? = null,
    val inPip: Boolean = false,
)

class PlayerViewModel(app: Application) : AndroidViewModel(app) {
    private val nova = app as NovaApp
    private val resolver = nova.resolver
    private val library = nova.library

    val player: ExoPlayer = PlayerHolder.get(app)

    val settings: StateFlow<AppSettings> =
        nova.settings.flow.stateIn(viewModelScope, SharingStarted.Eagerly, AppSettings())

    private val _ui = MutableStateFlow(PlayerUi())
    val ui: StateFlow<PlayerUi> = _ui.asStateFlow()

    private val _pos = MutableStateFlow(PosInfo())
    val position: StateFlow<PosInfo> = _pos.asStateFlow()

    private var externalUri: Uri? = null
    private var externalItem: VideoItem? = null
    private val overrides = HashMap<String, VideoItem>()
    private var subtitleFiles: List<PlaylistResolver.SubtitleFile> = emptyList()
    private var externalCues: List<SubCue> = emptyList()
    private var subMode = SubMode.OFF
    private var embeddedCueText: String? = null
    private var subtitleDelay = 0L
    private var audioOnly = false
    private var backgrounded = false
    private var sleepJob: Job? = null
    private var sleepAtEnd = false

    private var lastVideo: VideoItem? = null
    private var lastPos = 0L
    private var lastDuration = 0L

    private val listener = object : Player.Listener {
        override fun onIsPlayingChanged(isPlaying: Boolean) {
            _ui.update { it.copy(isPlaying = isPlaying) }
            if (!isPlaying) saveNow()
        }

        override fun onPlaybackStateChanged(state: Int) {
            _ui.update {
                it.copy(
                    buffering = state == Player.STATE_BUFFERING,
                    ended = state == Player.STATE_ENDED,
                )
            }
            if (state == Player.STATE_READY) {
                lastDuration = player.duration.takeIf { it != C.TIME_UNSET } ?: lastDuration
            }
            if (state == Player.STATE_ENDED) onEnded()
        }

        override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) = onItemChanged(mediaItem, reason)

        override fun onTimelineChanged(timeline: Timeline, reason: Int) = refreshQueue()

        override fun onTracksChanged(tracks: Tracks) = buildTracks(tracks)

        override fun onCues(cueGroup: CueGroup) {
            embeddedCueText = cueGroup.cues.mapNotNull { it.text?.toString() }.joinToString("\n").ifBlank { null }
            if (subMode == SubMode.EMBEDDED) pushCue()
        }

        override fun onPlayerError(error: PlaybackException) {
            _ui.update { it.copy(error = describeError(error)) }
        }

        override fun onVideoSizeChanged(videoSize: VideoSize) {
            _ui.update { it.copy(videoWidth = videoSize.width, videoHeight = videoSize.height) }
        }

        override fun onPlaybackParametersChanged(playbackParameters: PlaybackParameters) {
            _ui.update { it.copy(speed = playbackParameters.speed) }
        }

        override fun onRepeatModeChanged(repeatMode: Int) {
            _ui.update { it.copy(repeatMode = repeatMode) }
        }
    }

    init {
        player.addListener(listener)
        _ui.update {
            it.copy(
                isPlaying = player.isPlaying,
                speed = player.playbackParameters.speed,
                repeatMode = player.repeatMode,
            )
        }
        refreshQueue()
        buildTracks(player.currentTracks)
        lastVideo = videoOf(player.currentMediaItem)
        viewModelScope.launch { runTicker() }
    }

    fun hasMedia(): Boolean = player.mediaItemCount > 0

    // ---- opening content --------------------------------------------------------------------

    /** Entry point for ACTION_VIEW / ACTION_SEND: play now, discover the folder in the background. */
    fun openExternal(uri: Uri, mime: String?) {
        val current = resolver.describe(uri, mime)
        externalUri = uri
        externalItem = current
        subtitleFiles = emptyList()
        _ui.update { it.copy(folderStatus = FolderStatus.RESOLVING, folderMessage = null, promptDismissed = false) }
        startPlayback(listOf(current), 0)
        resolveFolder()
    }

    /** Entry point for playback started from the in-app library. */
    fun openQueue(items: List<VideoItem>, start: Int) {
        externalUri = null
        externalItem = null
        subtitleFiles = emptyList()
        _ui.update { it.copy(folderStatus = FolderStatus.NONE, folderLabel = "", folderMessage = null) }
        startPlayback(items, start.coerceIn(0, (items.size - 1).coerceAtLeast(0)))
    }

    private fun startPlayback(items: List<VideoItem>, start: Int) {
        if (items.isEmpty()) return
        saveNow()
        viewModelScope.launch {
            val s = nova.settings.flow.first()
            PlayerHolder.preferSoftware = s.softwareDecoder
            val entry = if (s.resume) library.entryFor(items[start].key) else null
            val startPos = entry?.takeIf { it.resumable }?.positionMs ?: 0L

            overrides.clear()
            externalCues = emptyList()
            subMode = SubMode.OFF
            subtitleDelay = 0
            embeddedCueText = null
            lastVideo = null

            player.repeatMode = when (s.repeatMode) {
                1 -> Player.REPEAT_MODE_ONE
                2 -> Player.REPEAT_MODE_ALL
                else -> Player.REPEAT_MODE_OFF
            }
            player.pauseAtEndOfMediaItems = !s.autoNext
            player.setPlaybackSpeed(s.defaultSpeed)
            player.trackSelectionParameters = player.trackSelectionParameters.buildUpon()
                .clearOverrides()
                .setTrackTypeDisabled(C.TRACK_TYPE_TEXT, false)
                .setTrackTypeDisabled(C.TRACK_TYPE_VIDEO, audioOnly || backgrounded)
                .build()
            _ui.update {
                it.copy(
                    resize = s.defaultResize, error = null, cueText = null, subMode = SubMode.OFF,
                    externalSubName = null, subtitleDelayMs = 0,
                )
            }
            player.setMediaItems(items.map(::toMediaItem), start, startPos)
            player.prepare()
            player.play()
        }
    }

    private fun toMediaItem(v: VideoItem): MediaItem =
        MediaItem.Builder()
            .setUri(v.uri)
            .setMediaId(v.uri)
            .setTag(v)
            .setMediaMetadata(MediaMetadata.Builder().setTitle(v.title).build())
            .build()

    private fun rawTag(item: MediaItem?): VideoItem? = item?.localConfiguration?.tag as? VideoItem

    private fun videoOf(item: MediaItem?): VideoItem? = rawTag(item)?.let { overrides[it.uri] ?: it }

    // ---- folder discovery (1DM flow) --------------------------------------------------------

    fun hintUri(): Uri = resolver.pickerHint(externalUri)

    fun retryResolve() = resolveFolder()

    fun dismissFolderPrompt() = _ui.update { it.copy(promptDismissed = true) }

    fun onFolderPicked(treeUri: Uri) {
        viewModelScope.launch {
            _ui.update { it.copy(folderStatus = FolderStatus.RESOLVING, folderMessage = null) }
            resolver.authoriseFolder(treeUri)
            resolveFolder(afterPick = true)
        }
    }

    private fun resolveFolder(afterPick: Boolean = false) {
        val uri = externalUri ?: return
        val cur = externalItem ?: return
        _ui.update { it.copy(folderStatus = FolderStatus.RESOLVING) }
        viewModelScope.launch {
            val r = runCatching { resolver.resolve(uri, cur) }.getOrNull()
            if (r == null) {
                _ui.update {
                    it.copy(
                        folderStatus = FolderStatus.NEEDS_FOLDER,
                        promptDismissed = false,
                        folderMessage = if (afterPick) {
                            "That folder doesn't contain this video. Pick the folder that holds the downloaded files."
                        } else null,
                    )
                }
            } else {
                mergeSiblings(r, cur)
            }
        }
    }

    /** Adds the folder's other videos around the already-playing item without interrupting it. */
    private fun mergeSiblings(r: PlaylistResolver.Resolved, cur: VideoItem) {
        if (player.mediaItemCount == 1 && rawTag(player.getMediaItemAt(0))?.uri == cur.uri) {
            val before = r.items.subList(0, r.index).map(::toMediaItem)
            val after = r.items.subList(r.index + 1, r.items.size).map(::toMediaItem)
            overrides[cur.uri] = r.items[r.index]
            if (before.isNotEmpty()) player.addMediaItems(0, before)
            if (after.isNotEmpty()) player.addMediaItems(after)
        }
        subtitleFiles = r.subtitles
        _ui.update { it.copy(folderStatus = FolderStatus.FOUND, folderLabel = r.folderLabel, folderMessage = null) }
        refreshQueue()
        autoLoadSubtitle()
    }

    // ---- transport ---------------------------------------------------------------------------

    fun togglePlay() {
        if (player.playbackState == Player.STATE_ENDED) {
            player.seekTo(0)
            player.play()
        } else if (player.isPlaying) player.pause() else player.play()
    }

    fun pause() = player.pause()

    fun seekTo(ms: Long) = player.seekTo(ms.coerceAtLeast(0))

    fun seekBy(deltaMs: Long) {
        val dur = player.duration.takeIf { it != C.TIME_UNSET } ?: Long.MAX_VALUE
        player.seekTo((player.currentPosition + deltaMs).coerceIn(0, dur))
    }

    fun currentPosition(): Long = player.currentPosition

    fun duration(): Long = player.duration.takeIf { it != C.TIME_UNSET } ?: 0L

    fun next() {
        if (player.hasNextMediaItem()) player.seekToNextMediaItem()
    }

    fun previous() {
        if (player.hasPreviousMediaItem()) player.seekToPreviousMediaItem() else player.seekTo(0)
    }

    fun jumpTo(index: Int) {
        if (index in 0 until player.mediaItemCount) {
            player.seekTo(index, 0)
            player.play()
        }
    }

    fun setSpeed(speed: Float) {
        val v = speed.coerceIn(0.25f, 4f)
        player.setPlaybackSpeed(v)
        if (settings.value.rememberPlayback) updateSettings { copy(defaultSpeed = v) }
    }

    fun setResize(mode: Int) {
        _ui.update { it.copy(resize = mode) }
        if (settings.value.rememberPlayback) updateSettings { copy(defaultResize = mode) }
    }

    fun cycleResize() = setResize((_ui.value.resize + 1) % 4)

    fun setRepeat(mode: Int) {
        player.repeatMode = when (mode) {
            1 -> Player.REPEAT_MODE_ONE
            2 -> Player.REPEAT_MODE_ALL
            else -> Player.REPEAT_MODE_OFF
        }
        updateSettings { copy(repeatMode = mode) }
    }

    fun setSoftwareDecoder(on: Boolean) {
        PlayerHolder.preferSoftware = on
        updateSettings { copy(softwareDecoder = on) }
        val play = player.playWhenReady
        player.stop()
        player.prepare()
        player.playWhenReady = play
    }

    fun setPip(inPip: Boolean) = _ui.update { it.copy(inPip = inPip) }

    fun updateSettings(transform: AppSettings.() -> AppSettings) {
        nova.appScope.launch { nova.settings.update(transform) }
    }

    fun consumeToast() = _ui.update { it.copy(toast = null) }

    // ---- audio-only / background -------------------------------------------------------------

    fun setAudioOnly(on: Boolean) {
        audioOnly = on
        applyVideoDisabled()
        _ui.update { it.copy(audioOnly = on) }
    }

    /** True while the activity is not visible but audio keeps going: drop video decoding. */
    fun setBackgrounded(b: Boolean) {
        backgrounded = b
        applyVideoDisabled()
    }

    private fun applyVideoDisabled() {
        player.trackSelectionParameters = player.trackSelectionParameters.buildUpon()
            .setTrackTypeDisabled(C.TRACK_TYPE_VIDEO, audioOnly || backgrounded)
            .build()
    }

    // ---- tracks & subtitles ------------------------------------------------------------------

    private fun buildTracks(tracks: Tracks) {
        val audio = ArrayList<TrackOption>()
        val text = ArrayList<TrackOption>()
        var anyTextSelected = false
        for (g in tracks.groups) {
            if (g.type != C.TRACK_TYPE_AUDIO && g.type != C.TRACK_TYPE_TEXT) continue
            for (i in 0 until g.length) {
                if (!g.isTrackSupported(i)) continue
                val f = g.getTrackFormat(i)
                val lang = f.language?.takeIf { it != "und" }
                    ?.let { Locale.forLanguageTag(it).displayLanguage.ifEmpty { it } }
                val codec = f.sampleMimeType?.substringAfter('/')?.uppercase()
                val base = f.label ?: lang ?: "Track"
                if (g.type == C.TRACK_TYPE_AUDIO) {
                    val ch = if (f.channelCount > 0) "${f.channelCount}ch" else null
                    val label = listOfNotNull(base, ch, codec).joinToString(" · ")
                    audio += TrackOption(label, g.isTrackSelected(i), g, i)
                } else {
                    val label = listOfNotNull(base, codec).joinToString(" · ")
                    val sel = g.isTrackSelected(i)
                    if (sel) anyTextSelected = true
                    text += TrackOption(label, sel, g, i)
                }
            }
        }
        if (subMode != SubMode.EXTERNAL) {
            subMode = if (anyTextSelected) SubMode.EMBEDDED else SubMode.OFF
        }
        _ui.update {
            it.copy(audioTracks = audio, textTracks = text, subMode = subMode)
        }
        pushCue()
    }

    fun selectAudio(opt: TrackOption) {
        val g = opt.group ?: return
        player.trackSelectionParameters = player.trackSelectionParameters.buildUpon()
            .setTrackTypeDisabled(C.TRACK_TYPE_AUDIO, false)
            .setOverrideForType(TrackSelectionOverride(g.mediaTrackGroup, opt.index))
            .build()
    }

    fun selectEmbeddedSubtitle(opt: TrackOption) {
        val g = opt.group ?: return
        externalCues = emptyList()
        subMode = SubMode.EMBEDDED
        player.trackSelectionParameters = player.trackSelectionParameters.buildUpon()
            .setTrackTypeDisabled(C.TRACK_TYPE_TEXT, false)
            .setOverrideForType(TrackSelectionOverride(g.mediaTrackGroup, opt.index))
            .build()
        _ui.update { it.copy(subMode = subMode, externalSubName = null) }
    }

    fun subtitlesOff() {
        externalCues = emptyList()
        subMode = SubMode.OFF
        embeddedCueText = null
        player.trackSelectionParameters = player.trackSelectionParameters.buildUpon()
            .setTrackTypeDisabled(C.TRACK_TYPE_TEXT, true)
            .build()
        _ui.update { it.copy(subMode = SubMode.OFF, cueText = null, externalSubName = null) }
    }

    fun setSubtitleDelay(ms: Long) {
        subtitleDelay = ms
        _ui.update { it.copy(subtitleDelayMs = ms) }
        pushCue()
    }

    fun loadExternalSubtitle(uri: Uri, nameHint: String? = null) {
        viewModelScope.launch {
            val ctx = getApplication<Application>()
            val result = withContext(Dispatchers.IO) {
                runCatching {
                    val name = nameHint ?: queryName(uri) ?: "subtitle.srt"
                    val bytes = ctx.contentResolver.openInputStream(uri)?.use { it.readBytes() }
                        ?: error("unreadable")
                    require(bytes.size <= MAX_SUBTITLE_BYTES) { "too large" }
                    name to SubtitleParser.parse(name, SubtitleParser.decode(bytes))
                }
            }
            result.onSuccess { (name, cues) ->
                if (cues.isEmpty()) {
                    _ui.update { it.copy(toast = "No subtitles found in $name") }
                } else {
                    externalCues = cues
                    subMode = SubMode.EXTERNAL
                    player.trackSelectionParameters = player.trackSelectionParameters.buildUpon()
                        .setTrackTypeDisabled(C.TRACK_TYPE_TEXT, true)
                        .build()
                    _ui.update { it.copy(subMode = SubMode.EXTERNAL, externalSubName = name, toast = "Subtitles: $name") }
                    pushCue()
                }
            }.onFailure {
                _ui.update { it.copy(toast = "Couldn't read that subtitle file") }
            }
        }
    }

    private fun queryName(uri: Uri): String? = try {
        getApplication<Application>().contentResolver
            .query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)
            ?.use { if (it.moveToFirst()) it.getString(0) else null }
    } catch (_: Exception) {
        null
    }

    /** Loads a same-named .srt/.ass/.vtt from the discovered folder, if the user allows it. */
    private fun autoLoadSubtitle() {
        if (!settings.value.subAutoLoad || subtitleFiles.isEmpty() || subMode == SubMode.EXTERNAL) return
        val video = videoOf(player.currentMediaItem) ?: return
        val base = video.name.substringBeforeLast('.').lowercase()
        val match = subtitleFiles
            .filter { it.name.lowercase().startsWith(base) }
            .sortedBy { MediaTypes.SUBTITLE_EXT.indexOf(MediaTypes.ext(it.name)) }
            .firstOrNull() ?: return
        loadExternalSubtitle(Uri.parse(match.uri), match.name)
    }

    private fun pushCue(p: Long = player.currentPosition) {
        val text = when (subMode) {
            SubMode.EXTERNAL -> SubtitleParser.active(externalCues, p - subtitleDelay)
            SubMode.EMBEDDED -> embeddedCueText
            SubMode.OFF -> null
        }
        if (text != _ui.value.cueText) _ui.update { it.copy(cueText = text) }
    }

    // ---- queue / item changes ----------------------------------------------------------------

    private fun refreshQueue() {
        val q = (0 until player.mediaItemCount).map { videoOf(player.getMediaItemAt(it)) ?: VideoItem("", "?") }
        val cur = videoOf(player.currentMediaItem)
        _ui.update {
            it.copy(
                queue = q,
                index = player.currentMediaItemIndex,
                count = q.size,
                hasNext = player.hasNextMediaItem(),
                hasPrev = player.hasPreviousMediaItem(),
                title = cur?.title ?: it.title,
            )
        }
    }

    private fun onItemChanged(item: MediaItem?, reason: Int) {
        lastVideo?.let { v ->
            if (reason == Player.MEDIA_ITEM_TRANSITION_REASON_AUTO) persist(v, lastDuration, lastDuration)
            else persist(v, lastPos, lastDuration)
        }
        val v = videoOf(item)
        lastVideo = v
        lastPos = 0
        lastDuration = 0

        if (subMode == SubMode.EXTERNAL) {
            externalCues = emptyList()
            subMode = SubMode.OFF
        }
        _ui.update { it.copy(error = null, cueText = null, externalSubName = null, subMode = subMode) }
        refreshQueue()

        if (sleepAtEnd && reason == Player.MEDIA_ITEM_TRANSITION_REASON_AUTO) {
            player.pause()
            sleepAtEnd = false
            _ui.update { it.copy(sleepAtEnd = false) }
        }
        if (v != null && (reason == Player.MEDIA_ITEM_TRANSITION_REASON_AUTO ||
                reason == Player.MEDIA_ITEM_TRANSITION_REASON_SEEK)
        ) {
            viewModelScope.launch {
                val e = if (settings.value.resume) library.entryFor(v.key) else null
                if (e != null && e.resumable && player.currentPosition < 1_500 &&
                    videoOf(player.currentMediaItem)?.key == v.key
                ) player.seekTo(e.positionMs)
            }
        }
        autoLoadSubtitle()
    }

    private fun onEnded() {
        lastVideo?.let { persist(it, lastDuration, lastDuration) }
        if (sleepAtEnd) {
            sleepAtEnd = false
            _ui.update { it.copy(sleepAtEnd = false) }
        }
    }

    // ---- sleep timer -------------------------------------------------------------------------

    fun setSleepTimer(minutes: Int) {
        sleepJob?.cancel()
        sleepAtEnd = false
        sleepJob = viewModelScope.launch {
            var remaining = minutes * 60_000L
            _ui.update { it.copy(sleepRemainingMs = remaining, sleepAtEnd = false) }
            while (remaining > 0) {
                delay(1_000)
                remaining -= 1_000
                _ui.update { it.copy(sleepRemainingMs = remaining.coerceAtLeast(0)) }
            }
            player.pause()
            _ui.update { it.copy(sleepRemainingMs = 0) }
        }
    }

    fun setSleepAtEndOfVideo() {
        sleepJob?.cancel()
        sleepAtEnd = true
        _ui.update { it.copy(sleepRemainingMs = 0, sleepAtEnd = true) }
    }

    fun cancelSleep() {
        sleepJob?.cancel()
        sleepAtEnd = false
        _ui.update { it.copy(sleepRemainingMs = 0, sleepAtEnd = false) }
    }

    // ---- progress persistence ----------------------------------------------------------------

    fun saveNow() {
        val v = lastVideo ?: return
        val pos = player.currentPosition
        val dur = player.duration.takeIf { it != C.TIME_UNSET } ?: lastDuration
        lastPos = pos
        persist(v, pos, dur)
    }

    private fun persist(v: VideoItem, pos: Long, dur: Long) {
        if (dur <= 0 || v.uri.isEmpty()) return
        val stable = (overrides[v.uri] ?: v).copy(durationMs = dur)
        nova.appScope.launch { library.recordProgress(stable, pos, dur) }
    }

    fun stopPlayback() {
        saveNow()
        player.stop()
        player.clearMediaItems()
    }

    private suspend fun runTicker() {
        var tick = 0
        while (viewModelScope.isActive) {
            val p = player.currentPosition
            val d = player.duration.takeIf { it != C.TIME_UNSET } ?: 0L
            _pos.value = PosInfo(p, d, player.bufferedPosition)
            if (player.isPlaying) {
                lastPos = p
                lastDuration = d
                if (++tick % 25 == 0) saveNow()
            }
            if (subMode == SubMode.EXTERNAL) pushCue(p)
            delay(200)
        }
    }

    private fun describeError(e: PlaybackException): String = when (e.errorCode) {
        PlaybackException.ERROR_CODE_DECODER_INIT_FAILED,
        PlaybackException.ERROR_CODE_DECODING_FORMAT_UNSUPPORTED,
        PlaybackException.ERROR_CODE_DECODING_FORMAT_EXCEEDS_CAPABILITIES ->
            "This device can't decode the video or audio format in this file (${e.errorCodeName})."
        PlaybackException.ERROR_CODE_PARSING_CONTAINER_UNSUPPORTED,
        PlaybackException.ERROR_CODE_PARSING_CONTAINER_MALFORMED ->
            "The file container isn't supported or is damaged (${e.errorCodeName})."
        PlaybackException.ERROR_CODE_IO_NO_PERMISSION,
        PlaybackException.ERROR_CODE_IO_FILE_NOT_FOUND ->
            "Access to this file was lost. Open it again from the app you came from."
        else -> "Playback error: ${e.errorCodeName}"
    }

    override fun onCleared() {
        saveNow()
        player.removeListener(listener)
        super.onCleared()
    }

    private companion object {
        const val MAX_SUBTITLE_BYTES = 8 * 1024 * 1024
    }
}
