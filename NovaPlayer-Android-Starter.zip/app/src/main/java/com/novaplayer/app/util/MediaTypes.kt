package com.novaplayer.app.util

object MediaTypes {
    val VIDEO_EXT = setOf(
        "mp4", "mkv", "avi", "mov", "webm", "3gp", "3g2", "mpeg", "mpg",
        "ts", "m2ts", "mts", "m4v", "flv", "wmv", "vob", "ogv",
    )
    val AUDIO_EXT = setOf("aac", "mp3", "flac", "wav", "ogg", "opus", "m4a")
    val SUBTITLE_EXT = listOf("srt", "ass", "ssa", "vtt")

    fun ext(name: String): String = name.substringAfterLast('.', "").lowercase()

    fun isAudioName(name: String): Boolean = ext(name) in AUDIO_EXT

    fun isSubtitle(name: String): Boolean = ext(name) in SUBTITLE_EXT

    fun isMedia(name: String, mime: String?): Boolean {
        if (mime != null && (mime.startsWith("video/") || mime.startsWith("audio/"))) return true
        val e = ext(name)
        return e in VIDEO_EXT || e in AUDIO_EXT
    }
}
