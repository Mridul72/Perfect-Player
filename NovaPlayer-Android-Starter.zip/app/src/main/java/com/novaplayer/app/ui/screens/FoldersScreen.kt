package com.novaplayer.app.ui.screens

import android.net.Uri
import android.provider.DocumentsContract
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.CreateNewFolder
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.Folder
import androidx.compose.material.icons.rounded.FolderOpen
import androidx.compose.material.icons.rounded.MoreVert
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.VideoLibrary
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.novaplayer.app.data.AppSettings
import com.novaplayer.app.data.FolderOps
import com.novaplayer.app.data.SafEntry
import com.novaplayer.app.data.sortedByField
import com.novaplayer.app.data.toVideoItem
import com.novaplayer.app.nova
import com.novaplayer.app.ui.AppActions
import com.novaplayer.app.ui.LibraryViewModel
import com.novaplayer.app.ui.Loc
import com.novaplayer.app.ui.components.ActionRow
import com.novaplayer.app.ui.components.EmptyState
import com.novaplayer.app.ui.components.FolderRow
import com.novaplayer.app.ui.components.SectionHeader
import com.novaplayer.app.ui.components.VideoRow
import com.novaplayer.app.util.Fmt
import com.novaplayer.app.util.MediaTypes
import com.novaplayer.app.util.NaturalOrder
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

@Composable
fun FoldersScreen(vm: LibraryViewModel, actions: AppActions) {
    val loc by vm.loc.collectAsStateWithLifecycle()
    val canBack by vm.canGoBack.collectAsStateWithLifecycle()
    val settings by vm.settings.collectAsStateWithLifecycle()
    var refreshKey by remember { mutableIntStateOf(0) }
    var query by rememberSaveable { mutableStateOf("") }
    var searchOpen by rememberSaveable { mutableStateOf(false) }

    BackHandler(enabled = canBack) { vm.goBack() }

    val title = when (val l = loc) {
        Loc.Root -> "Folders"
        is Loc.Device -> l.path.trimEnd('/').substringAfterLast('/').ifEmpty { "Storage root" }
        is Loc.Saf -> l.title
    }
    val subtitle = when (val l = loc) {
        Loc.Root -> "Internal storage and folders you authorised"
        is Loc.Device -> l.path.ifEmpty { "/" }
        is Loc.Saf -> "Authorised folder"
    }

    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(start = 8.dp, end = 8.dp, top = 12.dp), verticalAlignment = Alignment.CenterVertically) {
            if (canBack) {
                IconButton(onClick = { vm.goBack() }) { Icon(Icons.AutoMirrored.Rounded.ArrowBack, "Up one level") }
            } else {
                Box(Modifier.padding(start = 12.dp))
            }
            Column(Modifier.weight(1f)) {
                Text(title, style = MaterialTheme.typography.headlineMedium, maxLines = 1)
                Text(subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1)
            }
            if (loc != Loc.Root) {
                IconButton(onClick = { searchOpen = !searchOpen; if (!searchOpen) query = "" }) { Icon(Icons.Rounded.Search, "Search this folder") }
                SortMenu(settings) { f, asc -> vm.update { copy(sortField = f.name, sortAscending = asc) } }
            }
            IconButton(onClick = { vm.refresh(); refreshKey++ }) { Icon(Icons.Rounded.Refresh, "Refresh folders") }
        }
        if (searchOpen && loc != Loc.Root) {
            SearchField(query, { query = it }, Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp), "Search this folder", true)
        }

        when (val l = loc) {
            Loc.Root -> RootList(vm, actions)
            is Loc.Device -> DeviceFolder(l, vm, actions, settings, query)
            is Loc.Saf -> SafFolder(l, vm, actions, settings, refreshKey, query)
        }
    }
}

@Composable
private fun RootList(vm: LibraryViewModel, actions: AppActions) {
    val videos by vm.videos.collectAsStateWithLifecycle()
    val hasPermission by vm.hasPermission.collectAsStateWithLifecycle()
    val authorised by vm.authorised.collectAsStateWithLifecycle()
    val settings by vm.settings.collectAsStateWithLifecycle()
    var flat by rememberSaveable { mutableStateOf(false) }

    val folders = remember(videos, flat) {
        if (flat) FolderOps.flat(videos) else FolderOps.subfolders(videos, "")
    }
    val rootVideos = remember(videos) { FolderOps.direct(videos, "") }

    LazyColumn(Modifier.fillMaxSize()) {
        item { SectionHeader("On this device") }
        if (!hasPermission) {
            item {
                EmptyState(
                    Icons.Rounded.VideoLibrary,
                    "Video access is off",
                    "Allow access to browse the folders on this phone, or authorise one folder below.",
                    "Allow video access",
                    actions.requestMedia,
                )
            }
        } else {
            item {
                Row(Modifier.padding(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("Folder tree", "All folders").forEachIndexed { i, label ->
                        FilterChip(
                            selected = (i == 1) == flat,
                            onClick = { flat = i == 1 },
                            label = { Text(label) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = MaterialTheme.colorScheme.primary,
                                selectedLabelColor = Color.Black,
                            ),
                        )
                    }
                }
            }
            if (folders.isEmpty() && rootVideos.isEmpty()) {
                item { EmptyState(Icons.Rounded.Folder, "No folders with videos", "Folders appear here once they contain a video.") }
            }
            itemsIndexed(folders) { _, f ->
                var menu by remember { mutableStateOf(false) }
                FolderRow(
                    title = f.name,
                    subtitle = "${f.count} videos  ·  ${Fmt.size(f.totalBytes)}" + if (flat) "  ·  ${f.path.trimEnd('/')}" else "",
                    thumb = f.thumb,
                    onClick = { vm.navigate(Loc.Device(f.path)) },
                    trailing = {
                        Box {
                            IconButton(onClick = { menu = true }) { Icon(Icons.Rounded.MoreVert, "Folder options") }
                            DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                                DropdownMenuItem(
                                    text = { Text("Exclude from library") },
                                    onClick = { vm.exclude(f.path); menu = false },
                                )
                            }
                        }
                    },
                )
            }
            if (rootVideos.isNotEmpty()) {
                item { SectionHeader("In storage root") }
                itemsIndexed(rootVideos) { i, v ->
                    VideoRow(v, showThumb = settings.showThumbnails, onClick = { actions.play(rootVideos, i) })
                }
            }
        }

        item { SectionHeader("Authorised folders") }
        if (authorised.isEmpty()) {
            item {
                Text(
                    "Android only lets an app see folders you hand it. Add the folder your downloads go to " +
                        "(for example Download/1DM) and NovaPlayer remembers it.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(horizontal = 20.dp, vertical = 4.dp),
                )
            }
        }
        itemsIndexed(authorised) { _, a ->
            val rootDoc = remember(a.uri) { runCatching { DocumentsContract.getTreeDocumentId(Uri.parse(a.uri)) }.getOrDefault("") }
            FolderRow(
                title = a.name,
                subtitle = "Folder you authorised",
                thumb = null,
                onClick = { vm.navigate(Loc.Saf(a.uri, rootDoc, a.name)) },
                trailing = {
                    IconButton(onClick = { vm.removeAuthorisedFolder(a.uri) }) { Icon(Icons.Rounded.Delete, "Remove access to ${a.name}") }
                },
            )
        }
        item { ActionRow("Add folder", "Pick a folder once; access is remembered", Icons.Rounded.CreateNewFolder, actions.addFolder) }
    }
}

@Composable
private fun DeviceFolder(l: Loc.Device, vm: LibraryViewModel, actions: AppActions, settings: AppSettings, query: String) {
    val videos by vm.videos.collectAsStateWithLifecycle()
    val history by vm.history.collectAsStateWithLifecycle()
    val favs by vm.favourites.collectAsStateWithLifecycle()
    val progress = remember(history) { history.associate { it.video.key to it.progress } }
    val favKeys = remember(favs) { favs.map { it.key }.toSet() }

    val subfolders = remember(videos, l.path) { FolderOps.subfolders(videos, l.path) }
    val inFolder = remember(videos, l.path, query, settings.sortField, settings.sortAscending) {
        FolderOps.direct(videos, l.path)
            .filter { query.isBlank() || it.name.contains(query.trim(), ignoreCase = true) }
            .sortedByField(settings.sort, settings.sortAscending)
    }

    if (subfolders.isEmpty() && inFolder.isEmpty()) {
        EmptyState(Icons.Rounded.FolderOpen, "Nothing here", "This folder has no videos${if (query.isNotBlank()) " matching “${query.trim()}”" else ""}.")
        return
    }
    LazyColumn(Modifier.fillMaxSize()) {
        if (query.isBlank()) {
            itemsIndexed(subfolders) { _, f ->
                FolderRow(f.name, "${f.count} videos  ·  ${Fmt.size(f.totalBytes)}", f.thumb, { vm.navigate(Loc.Device(f.path)) })
            }
        }
        itemsIndexed(inFolder) { i, v ->
            VideoRow(
                v,
                progress = progress[v.key]?.takeIf { it < 0.95f } ?: 0f,
                favourite = v.key in favKeys,
                showThumb = settings.showThumbnails,
                onClick = { actions.play(inFolder, i) },
                onFavourite = { vm.toggleFavourite(v) },
            )
        }
    }
}

@Composable
private fun SafFolder(
    l: Loc.Saf,
    vm: LibraryViewModel,
    actions: AppActions,
    settings: AppSettings,
    refreshKey: Int,
    query: String,
) {
    val ctx = LocalContext.current
    val tree = remember(l.tree) { Uri.parse(l.tree) }
    val history by vm.history.collectAsStateWithLifecycle()
    val favs by vm.favourites.collectAsStateWithLifecycle()
    val progress = remember(history) { history.associate { it.video.key to it.progress } }
    val favKeys = remember(favs) { favs.map { it.key }.toSet() }

    val entries by produceState<List<SafEntry>?>(initialValue = null, l.tree, l.docId, refreshKey) {
        value = null
        value = withContext(Dispatchers.IO) { ctx.nova.media.listSaf(tree, l.docId) }
    }
    val e = entries
    if (e == null) {
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            CircularProgressIndicator(color = MaterialTheme.colorScheme.primary)
        }
        return
    }
    val folderLabel = remember(l.docId) {
        l.docId.substringAfter(':', "").trim('/').let { if (it.isEmpty()) "" else "$it/" }
    }
    val dirs = remember(e) { e.filter { it.isDir }.sortedWith(compareBy<SafEntry, String>(NaturalOrder) { it.name }) }
    val videos = remember(e, query, settings.sortField, settings.sortAscending) {
        e.filter { !it.isDir && MediaTypes.isMedia(it.name, it.mime) }
            .map { it.toVideoItem(folderLabel) }
            .filter { query.isBlank() || it.name.contains(query.trim(), ignoreCase = true) }
            .sortedByField(settings.sort, settings.sortAscending)
    }

    if (dirs.isEmpty() && videos.isEmpty()) {
        EmptyState(
            Icons.Rounded.FolderOpen,
            "Nothing playable here",
            "If this folder should have videos, access may have been removed in Android settings. Add the folder again from the Folders screen.",
        )
        return
    }
    LazyColumn(Modifier.fillMaxSize()) {
        if (query.isBlank()) {
            itemsIndexed(dirs) { _, d ->
                SafDirRow(tree, d) { vm.navigate(Loc.Saf(l.tree, d.docId, d.name)) }
            }
        }
        itemsIndexed(videos) { i, v ->
            VideoRow(
                v,
                progress = progress[v.key]?.takeIf { it < 0.95f } ?: 0f,
                favourite = v.key in favKeys,
                showThumb = settings.showThumbnails,
                onClick = { actions.play(videos, i) },
                onFavourite = { vm.toggleFavourite(v) },
            )
        }
    }
}

@Composable
private fun SafDirRow(tree: Uri, entry: SafEntry, onClick: () -> Unit) {
    val ctx = LocalContext.current
    val count by produceState(-1, entry.docId) {
        value = withContext(Dispatchers.IO) { ctx.nova.media.countMedia(tree, entry.docId) }
    }
    FolderRow(entry.name, if (count < 0) "Counting videos…" else "$count videos", null, onClick)
}
