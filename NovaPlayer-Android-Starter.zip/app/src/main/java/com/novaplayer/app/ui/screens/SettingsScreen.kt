package com.novaplayer.app.ui.screens

import android.os.Build
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.Folder
import androidx.compose.material.icons.rounded.Gesture
import androidx.compose.material.icons.rounded.History
import androidx.compose.material.icons.rounded.Info
import androidx.compose.material.icons.rounded.Palette
import androidx.compose.material.icons.rounded.PlayCircle
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.Security
import androidx.compose.material.icons.rounded.Storage
import androidx.compose.material.icons.rounded.Subtitles
import androidx.compose.material.icons.rounded.Tune
import androidx.compose.material.icons.rounded.VideoLibrary
import androidx.compose.material.icons.rounded.Videocam
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.novaplayer.app.BuildConfig
import com.novaplayer.app.data.SortField
import com.novaplayer.app.ui.AppActions
import com.novaplayer.app.ui.LibraryViewModel
import com.novaplayer.app.ui.components.ActionRow
import com.novaplayer.app.ui.components.ChoiceRow
import com.novaplayer.app.ui.components.ColorDot
import com.novaplayer.app.ui.components.SettingGroup
import com.novaplayer.app.ui.components.SliderRow
import com.novaplayer.app.ui.components.SwitchRow
import com.novaplayer.app.ui.theme.Accents
import com.novaplayer.app.util.Fmt

private val SUB_COLOR_CHOICES = listOf(
    Color.White, Color(0xFFFFE066), Color(0xFFB8F34A), Color(0xFF5CE1E6),
)
private val STEP_CHOICES = listOf(5, 10, 15, 30)

@Composable
fun SettingsScreen(vm: LibraryViewModel, actions: AppActions) {
    var page by rememberSaveable { mutableStateOf("main") }
    BackHandler(enabled = page != "main") { page = "main" }

    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(start = 8.dp, end = 8.dp, top = 12.dp), verticalAlignment = Alignment.CenterVertically) {
            if (page != "main") {
                IconButton(onClick = { page = "main" }) { Icon(Icons.AutoMirrored.Rounded.ArrowBack, "Back to settings") }
            } else {
                Row(Modifier.padding(start = 12.dp)) {}
            }
            Text(
                when (page) {
                    "general" -> "General"
                    "appearance" -> "Appearance"
                    "player" -> "Player"
                    "gestures" -> "Gestures"
                    "subtitles" -> "Subtitles"
                    "library" -> "Library"
                    "storage" -> "Storage permissions"
                    "folders" -> "Folder management"
                    "playback" -> "Playback preferences"
                    "about" -> "About"
                    else -> "Settings"
                },
                style = MaterialTheme.typography.headlineMedium,
            )
        }
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(bottom = 24.dp)) {
            when (page) {
                "general" -> GeneralPage(vm)
                "appearance" -> AppearancePage(vm)
                "player" -> PlayerPage(vm, actions)
                "gestures" -> GesturesPage(vm)
                "subtitles" -> SubtitlesPage(vm)
                "library" -> LibraryPage(vm) { page = it }
                "storage" -> StoragePage(vm, actions)
                "folders" -> FoldersPage(vm, actions)
                "playback" -> PlaybackPage(vm)
                "about" -> AboutPage()
                else -> MainPage { page = it }
            }
        }
    }
}

@Composable
private fun MainPage(go: (String) -> Unit) {
    SettingGroup("Preferences") {
        ActionRow("General", "Folder memory, history, reset", Icons.Rounded.Tune) { go("general") }
        ActionRow("Appearance", "Accent colour, grid, thumbnails", Icons.Rounded.Palette) { go("appearance") }
        ActionRow("Player", "Orientation, controls, decoder, background audio", Icons.Rounded.Videocam) { go("player") }
        ActionRow("Gestures", "Swipe and double-tap sensitivity", Icons.Rounded.Gesture) { go("gestures") }
        ActionRow("Subtitles", "Size, colour, position", Icons.Rounded.Subtitles) { go("subtitles") }
        ActionRow("Playback preferences", "Resume, auto-play, repeat, speed", Icons.Rounded.PlayCircle) { go("playback") }
    }
    SettingGroup("Library and storage") {
        ActionRow("Library", "Sorting and excluded folders", Icons.Rounded.VideoLibrary) { go("library") }
        ActionRow("Storage permissions", "Video access and notifications", Icons.Rounded.Security) { go("storage") }
        ActionRow("Folder management", "Authorised and excluded folders", Icons.Rounded.Folder) { go("folders") }
    }
    SettingGroup("NovaPlayer") {
        ActionRow("About", "Version, privacy, supported formats", Icons.Rounded.Info) { go("about") }
    }
}

@Composable
private fun GeneralPage(vm: LibraryViewModel) {
    val s by vm.settings.collectAsStateWithLifecycle()
    SettingGroup("Browsing") {
        SwitchRow("Remember last folder", "Reopen the Folders screen where you left it", s.rememberFolder) {
            vm.update { copy(rememberFolder = it) }
        }
    }
    SettingGroup("Data") {
        ActionRow("Clear watch history", "Removes continue-watching and resume positions", Icons.Rounded.History) { vm.clearHistory() }
        ActionRow("Reset all settings", "Restores defaults; favourites and folders are kept", Icons.Rounded.Refresh) { vm.resetSettings() }
    }
}

@Composable
private fun AppearancePage(vm: LibraryViewModel) {
    val s by vm.settings.collectAsStateWithLifecycle()
    SettingGroup("Theme") {
        Column(Modifier.padding(horizontal = 16.dp, vertical = 10.dp)) {
            Text("Accent colour", style = MaterialTheme.typography.titleMedium)
            Row(Modifier.padding(top = 10.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Accents.forEachIndexed { i, (_, color) ->
                    ColorDot(color, s.accent == i) { vm.update { copy(accent = i) } }
                }
            }
            Text(
                "${Accents[s.accent.coerceIn(0, Accents.lastIndex)].first} on true black",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(top = 8.dp),
            )
        }
    }
    SettingGroup("Library layout") {
        ChoiceRow("Layout", listOf("Grid", "List"), if (s.libraryGrid) 0 else 1) { vm.update { copy(libraryGrid = it == 0) } }
        ChoiceRow("Grid columns", listOf("2", "3", "4"), (s.gridColumns - 2).coerceIn(0, 2)) { vm.update { copy(gridColumns = it + 2) } }
        SwitchRow("Show thumbnails", "Turn off to save battery on very large libraries", s.showThumbnails) {
            vm.update { copy(showThumbnails = it) }
        }
    }
}

@Composable
private fun PlayerPage(vm: LibraryViewModel, actions: AppActions) {
    val s by vm.settings.collectAsStateWithLifecycle()
    SettingGroup("Display") {
        ChoiceRow("Orientation", listOf("By video", "Landscape", "Portrait", "System"), s.orientationMode) { vm.update { copy(orientationMode = it) } }
        ChoiceRow("Default aspect ratio", listOf("Fit", "Fill", "Stretch", "Crop"), s.defaultResize) { vm.update { copy(defaultResize = it) } }
        SliderRow("Hide controls after", { "${it.toInt()} s" }, s.controlsTimeoutSec.toFloat(), 2f..10f, 7) {
            vm.update { copy(controlsTimeoutSec = it.toInt()) }
        }
    }
    SettingGroup("Decoding") {
        ChoiceRow("Preferred decoder", listOf("Hardware", "Software"), if (s.softwareDecoder) 1 else 0) {
            vm.update { copy(softwareDecoder = it == 1) }
        }
        Text(
            "Software decoding can fix green or frozen video on some files but uses more battery. " +
                "Takes effect the next time a video opens.",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp),
        )
    }
    SettingGroup("Leaving the player") {
        SwitchRow("Picture-in-picture", "Shrink to a floating window when you press Home", s.pip) { vm.update { copy(pip = it) } }
        SwitchRow("Background audio", "Keep playing with the screen off or in another app", s.bgPlayback) {
            if (it && Build.VERSION.SDK_INT >= 33 && !actions.hasNotificationPermission()) actions.requestNotifications()
            vm.update { copy(bgPlayback = it) }
        }
    }
}

@Composable
private fun GesturesPage(vm: LibraryViewModel) {
    val s by vm.settings.collectAsStateWithLifecycle()
    SettingGroup("Touch gestures") {
        SwitchRow("Enable gestures", "Swipe to seek, brightness and volume; double-tap to skip", s.gestures) { vm.update { copy(gestures = it) } }
        SliderRow("Seek sensitivity", { "${Fmt.speed(it).removeSuffix("x")}×" }, s.seekSens, 0.5f..2f, 5) { vm.update { copy(seekSens = it) } }
        SliderRow("Brightness sensitivity", { "${Fmt.speed(it).removeSuffix("x")}×" }, s.brightnessSens, 0.5f..2f, 5) { vm.update { copy(brightnessSens = it) } }
        SliderRow("Volume sensitivity", { "${Fmt.speed(it).removeSuffix("x")}×" }, s.volumeSens, 0.5f..2f, 5) { vm.update { copy(volumeSens = it) } }
        ChoiceRow("Double-tap skip", STEP_CHOICES.map { "$it s" }, STEP_CHOICES.indexOf(s.doubleTapSec).coerceAtLeast(0)) {
            vm.update { copy(doubleTapSec = STEP_CHOICES[it]) }
        }
    }
    Text(
        "Left side swipe: brightness. Right side swipe: volume. Horizontal swipe: seek.",
        style = MaterialTheme.typography.bodySmall,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
        modifier = Modifier.padding(horizontal = 20.dp, vertical = 8.dp),
    )
}

@Composable
private fun SubtitlesPage(vm: LibraryViewModel) {
    val s by vm.settings.collectAsStateWithLifecycle()
    SettingGroup("Appearance") {
        SliderRow("Size", { "${it.toInt()} sp" }, s.subSize, 12f..40f, 27) { vm.update { copy(subSize = it) } }
        SliderRow("Position", { "${(it * 100).toInt()}% from bottom" }, s.subBottom, 0f..0.4f) { vm.update { copy(subBottom = it) } }
        SliderRow("Background", { "${(it * 100).toInt()}%" }, s.subBackground, 0f..0.9f) { vm.update { copy(subBackground = it) } }
        Column(Modifier.padding(horizontal = 16.dp, vertical = 8.dp)) {
            Text("Colour", style = MaterialTheme.typography.titleMedium)
            Row(Modifier.padding(top = 10.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                SUB_COLOR_CHOICES.forEach { c ->
                    val argb = c.toArgb()
                    ColorDot(c, s.subColor == argb) { vm.update { copy(subColor = argb) } }
                }
            }
        }
    }
    SettingGroup("Loading") {
        SwitchRow("Load matching subtitle file", "Uses a same-named .srt, .ass or .vtt when its folder is readable", s.subAutoLoad) {
            vm.update { copy(subAutoLoad = it) }
        }
    }
}

@Composable
private fun LibraryPage(vm: LibraryViewModel, go: (String) -> Unit) {
    val s by vm.settings.collectAsStateWithLifecycle()
    val excluded by vm.excluded.collectAsStateWithLifecycle()
    SettingGroup("Default sorting") {
        ChoiceRow("Sort by", SortField.entries.map { it.label }, s.sort.ordinal) { vm.update { copy(sortField = SortField.entries[it].name) } }
        ChoiceRow("Order", listOf("Ascending", "Descending"), if (s.sortAscending) 0 else 1) { vm.update { copy(sortAscending = it == 0) } }
    }
    SettingGroup("Scanning") {
        ActionRow("Refresh library now", "Re-reads the media database", Icons.Rounded.Refresh) { vm.refresh() }
        ActionRow("Excluded folders", "${excluded.size} hidden from the library", Icons.Rounded.Folder) { go("folders") }
    }
}

@Composable
private fun StoragePage(vm: LibraryViewModel, actions: AppActions) {
    val hasMedia by vm.hasPermission.collectAsStateWithLifecycle()
    val authorised by vm.authorised.collectAsStateWithLifecycle()
    SettingGroup("Video library access") {
        Column(Modifier.padding(16.dp)) {
            Text(if (hasMedia) "Allowed" else "Not allowed", style = MaterialTheme.typography.titleMedium, color = if (hasMedia) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error)
            Text(
                "Lets NovaPlayer list videos on this phone and find the other files in a folder when you open one from 1DM or a file manager.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(vertical = 6.dp),
            )
            if (!hasMedia) {
                Button(onClick = actions.requestMedia, colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)) {
                    Text("Allow video access", color = Color.Black)
                }
            } else {
                Button(onClick = actions.openAppSettings, colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF262626))) {
                    Text("Open app settings")
                }
            }
        }
    }
    if (Build.VERSION.SDK_INT >= 33) {
        val notif = actions.hasNotificationPermission()
        SettingGroup("Notifications") {
            Column(Modifier.padding(16.dp)) {
                Text(if (notif) "Allowed" else "Not allowed", style = MaterialTheme.typography.titleMedium, color = if (notif) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error)
                Text(
                    "Only used for the playback controls shown while audio plays in the background.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(vertical = 6.dp),
                )
                if (!notif) {
                    Button(onClick = actions.requestNotifications, colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)) {
                        Text("Allow notifications", color = Color.Black)
                    }
                }
            }
        }
    }
    SettingGroup("Authorised folders") {
        Text(
            "${authorised.size} folder(s). Pick the exact folder your downloads go to, such as Download/1DM. " +
                "Android does not allow choosing the top-level Download folder itself.",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp),
        )
        ActionRow("Add folder", null, Icons.Rounded.Add, actions.addFolder)
    }
}

@Composable
private fun FoldersPage(vm: LibraryViewModel, actions: AppActions) {
    val authorised by vm.authorised.collectAsStateWithLifecycle()
    val excluded by vm.excluded.collectAsStateWithLifecycle()
    SettingGroup("Authorised folders") {
        if (authorised.isEmpty()) {
            Text("None yet.", color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(16.dp))
        }
        authorised.forEach { a ->
            Row(Modifier.fillMaxWidth().padding(start = 16.dp, end = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f).padding(vertical = 8.dp)) {
                    Text(a.name, style = MaterialTheme.typography.titleMedium)
                    Text("Read-only access", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                IconButton(onClick = { vm.removeAuthorisedFolder(a.uri) }) { Icon(Icons.Rounded.Delete, "Remove ${a.name}") }
            }
        }
        ActionRow("Add folder", null, Icons.Rounded.Add, actions.addFolder)
    }
    SettingGroup("Excluded from library") {
        if (excluded.isEmpty()) {
            Text("No folders are hidden. Use a folder's menu in Folders to exclude it.", color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(16.dp))
        }
        excluded.sorted().forEach { path ->
            Row(Modifier.fillMaxWidth().padding(start = 16.dp, end = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                Text(path.trimEnd('/'), Modifier.weight(1f).padding(vertical = 12.dp), style = MaterialTheme.typography.bodyMedium)
                IconButton(onClick = { vm.unexclude(path) }) { Icon(Icons.Rounded.Delete, "Include $path again") }
            }
        }
    }
}

@Composable
private fun PlaybackPage(vm: LibraryViewModel) {
    val s by vm.settings.collectAsStateWithLifecycle()
    val speeds = listOf(0.5f, 0.75f, 1f, 1.25f, 1.5f, 2f)
    SettingGroup("Resume and queue") {
        SwitchRow("Resume where you left off", "Remembers the position of every video", s.resume) { vm.update { copy(resume = it) } }
        SwitchRow("Play next video automatically", "Continue through the folder when a video ends", s.autoNext) { vm.update { copy(autoNext = it) } }
        ChoiceRow("Repeat", listOf("Off", "One video", "Whole folder"), s.repeatMode) { vm.update { copy(repeatMode = it) } }
    }
    SettingGroup("Speed and seeking") {
        ChoiceRow("Default speed", speeds.map { Fmt.speed(it) }, speeds.indexOfFirst { it == s.defaultSpeed }.coerceAtLeast(2)) {
            vm.update { copy(defaultSpeed = speeds[it]) }
        }
        SwitchRow("Remember speed and aspect ratio", "Changes made in the player become the new default", s.rememberPlayback) {
            vm.update { copy(rememberPlayback = it) }
        }
        ChoiceRow("Skip buttons", STEP_CHOICES.map { "$it s" }, STEP_CHOICES.indexOf(s.seekStepSec).coerceAtLeast(1)) {
            vm.update { copy(seekStepSec = STEP_CHOICES[it]) }
        }
    }
}

@Composable
private fun AboutPage() {
    SettingGroup("NovaPlayer") {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text("Version ${BuildConfig.VERSION_NAME} (${BuildConfig.VERSION_CODE})", style = MaterialTheme.typography.titleMedium)
            Text(BuildConfig.APPLICATION_ID, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
    SettingGroup("Privacy") {
        Text(
            "No ads, no analytics, no tracking and no account. NovaPlayer does not request the INTERNET " +
                "permission, so nothing you watch can leave the device. Playback history, favourites and settings " +
                "stay in the app's private storage.",
            style = MaterialTheme.typography.bodyMedium,
            modifier = Modifier.padding(16.dp),
        )
    }
    SettingGroup("Formats") {
        Text(
            "Video: MP4, MKV, WebM, MOV, 3GP, MPEG, TS and M4V through Media3 ExoPlayer. AVI is not covered by " +
                "Media3's built-in extractors and may fail. Audio: AAC, MP3, FLAC, WAV, OGG and Opus.\n\n" +
                "Decoding uses the phone's own codecs. AC-3, E-AC-3, DTS and TrueHD audio, and some HEVC or AV1 " +
                "profiles, depend on the device and may play without sound or not at all.\n\n" +
                "Subtitles: SRT, ASS/SSA (text only, no styling or effects), WebVTT and embedded text tracks. " +
                "Image-based subtitles (PGS, VobSub) are not shown.",
            style = MaterialTheme.typography.bodyMedium,
            modifier = Modifier.padding(16.dp),
        )
    }
}
