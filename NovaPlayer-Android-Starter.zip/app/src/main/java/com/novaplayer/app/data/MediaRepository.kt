package com.novaplayer.app.data

import android.Manifest
import android.content.ContentUris
import android.content.Context
import android.content.pm.PackageManager
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.DocumentsContract
import android.provider.MediaStore
import androidx.core.content.ContextCompat
import com.novaplayer.app.util.MediaTypes
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.withContext
import java.io.File
import java.util.concurrent.ConcurrentHashMap

class MediaRepository(private val context: Context) {

    private val resolver get() = context.contentResolver
    private val metaCache = ConcurrentHashMap<String, VideoItem>()
    private val probeGate = Semaphore(3)

    fun hasMediaPermission(): Boolean {
        val perm = if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_VIDEO
        else Manifest.permission.READ_EXTERNAL_STORAGE
        return ContextCompat.checkSelfPermission(context, perm) == PackageManager.PERMISSION_GRANTED
    }

    // ---- MediaStore ---------------------------------------------------------------------

    suspend fun loadVideos(): List<VideoItem> = withContext(Dispatchers.IO) {
        if (!hasMediaPermission()) emptyList() else queryVideos()
    }

    fun queryVideos(
        selection: String? = null,
        args: Array<String>? = null,
        volume: String? = null,
        sort: String? = "${MediaStore.Video.Media.DATE_MODIFIED} DESC",
    ): List<VideoItem> {
        val out = ArrayList<VideoItem>()
        val q29 = Build.VERSION.SDK_INT >= 29
        val collection = if (volume != null && q29) MediaStore.Video.Media.getContentUri(volume)
        else MediaStore.Video.Media.EXTERNAL_CONTENT_URI

        val projection = ArrayList<String>().apply {
            add(MediaStore.Video.Media._ID)
            add(MediaStore.Video.Media.DISPLAY_NAME)
            add(MediaStore.Video.Media.SIZE)
            add(MediaStore.Video.Media.DURATION)
            add(MediaStore.Video.Media.WIDTH)
            add(MediaStore.Video.Media.HEIGHT)
            add(MediaStore.Video.Media.DATE_MODIFIED)
            add(MediaStore.Video.Media.DATE_ADDED)
            add(MediaStore.Video.Media.MIME_TYPE)
            if (q29) {
                add(MediaStore.MediaColumns.RELATIVE_PATH)
                add(MediaStore.MediaColumns.VOLUME_NAME)
            } else {
                add(LEGACY_DATA)
            }
        }.toTypedArray()

        try {
            resolver.query(collection, projection, selection, args, sort)?.use { c ->
                val iId = c.getColumnIndexOrThrow(MediaStore.Video.Media._ID)
                val iName = c.getColumnIndexOrThrow(MediaStore.Video.Media.DISPLAY_NAME)
                val iSize = c.getColumnIndexOrThrow(MediaStore.Video.Media.SIZE)
                val iDur = c.getColumnIndexOrThrow(MediaStore.Video.Media.DURATION)
                val iW = c.getColumnIndexOrThrow(MediaStore.Video.Media.WIDTH)
                val iH = c.getColumnIndexOrThrow(MediaStore.Video.Media.HEIGHT)
                val iMod = c.getColumnIndexOrThrow(MediaStore.Video.Media.DATE_MODIFIED)
                val iAdd = c.getColumnIndexOrThrow(MediaStore.Video.Media.DATE_ADDED)
                val iMime = c.getColumnIndexOrThrow(MediaStore.Video.Media.MIME_TYPE)
                val pathColumn = if (q29) MediaStore.MediaColumns.RELATIVE_PATH else LEGACY_DATA
                val iPath = c.getColumnIndexOrThrow(pathColumn)
                val iVol = if (q29) c.getColumnIndexOrThrow(MediaStore.MediaColumns.VOLUME_NAME) else -1

                while (c.moveToNext()) {
                    val name = c.getString(iName) ?: continue
                    val raw = c.getString(iPath) ?: ""
                    val folder = if (q29) raw else relativeFromData(raw)
                    val vol = if (iVol >= 0) c.getString(iVol) ?: "external_primary" else "external_primary"
                    out += VideoItem(
                        uri = ContentUris.withAppendedId(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, c.getLong(iId)).toString(),
                        name = name,
                        sizeBytes = c.getLong(iSize),
                        durationMs = c.getLong(iDur),
                        width = c.getInt(iW),
                        height = c.getInt(iH),
                        dateModifiedSec = c.getLong(iMod),
                        dateAddedSec = c.getLong(iAdd),
                        folderPath = folder,
                        volume = vol,
                        mimeType = c.getString(iMime),
                    )
                }
            }
        } catch (_: SecurityException) {
            // permission revoked while running
        } catch (_: Exception) {
            // provider hiccup: return what we have
        }
        return out
    }

    fun findVideoById(id: Long): VideoItem? =
        queryVideos("${MediaStore.Video.Media._ID}=?", arrayOf(id.toString()), sort = null).firstOrNull()

    /** Candidates matching a display name (and size when known), newest first. */
    fun findVideosByName(name: String, size: Long): List<VideoItem> =
        if (size > 0) {
            queryVideos(
                "${MediaStore.Video.Media.DISPLAY_NAME}=? AND ${MediaStore.Video.Media.SIZE}=?",
                arrayOf(name, size.toString()),
            )
        } else {
            queryVideos("${MediaStore.Video.Media.DISPLAY_NAME}=?", arrayOf(name))
        }

    /** Videos stored directly in one folder (not its sub-folders). */
    fun videosInFolder(volume: String, folderPath: String): List<VideoItem> =
        if (Build.VERSION.SDK_INT >= 29) {
            queryVideos("${MediaStore.MediaColumns.RELATIVE_PATH}=?", arrayOf(folderPath), volume, null)
        } else {
            queryVideos("$LEGACY_DATA LIKE ?", arrayOf("%/$folderPath%"), null, null)
                .filter { it.folderPath == folderPath }
        }

    private fun relativeFromData(data: String): String {
        val parent = File(data).parent ?: return ""
        @Suppress("DEPRECATION")
        val roots = listOf(Environment.getExternalStorageDirectory().path, "/sdcard", "/storage/emulated/0")
        for (r in roots) {
            if (parent == r) return ""
            if (parent.startsWith("$r/")) return parent.removePrefix("$r/") + "/"
        }
        return parent.trimStart('/') + "/"
    }

    // ---- Storage Access Framework -------------------------------------------------------

    /** Lists the direct children of [parentDocId] inside a user-authorised tree. */
    fun listSaf(treeUri: Uri, parentDocId: String): List<SafEntry> {
        val out = ArrayList<SafEntry>()
        try {
            val children = DocumentsContract.buildChildDocumentsUriUsingTree(treeUri, parentDocId)
            val cols = arrayOf(
                DocumentsContract.Document.COLUMN_DOCUMENT_ID,
                DocumentsContract.Document.COLUMN_DISPLAY_NAME,
                DocumentsContract.Document.COLUMN_MIME_TYPE,
                DocumentsContract.Document.COLUMN_SIZE,
                DocumentsContract.Document.COLUMN_LAST_MODIFIED,
            )
            resolver.query(children, cols, null, null, null)?.use { c ->
                while (c.moveToNext()) {
                    val docId = c.getString(0) ?: continue
                    val name = c.getString(1) ?: continue
                    out += SafEntry(
                        docId = docId,
                        uri = DocumentsContract.buildDocumentUriUsingTree(treeUri, docId),
                        name = name,
                        mime = c.getString(2),
                        size = if (c.isNull(3)) -1L else c.getLong(3),
                        modifiedMs = if (c.isNull(4)) 0L else c.getLong(4),
                    )
                }
            }
        } catch (_: Exception) {
            // permission lost or provider unavailable
        }
        return out
    }

    fun countMedia(treeUri: Uri, docId: String): Int =
        listSaf(treeUri, docId).count { !it.isDir && MediaTypes.isMedia(it.name, it.mime) }

    fun treeName(treeUri: Uri): String {
        val docId = try {
            DocumentsContract.getTreeDocumentId(treeUri)
        } catch (_: Exception) {
            return "Folder"
        }
        val fallback = docId.substringAfterLast('/').substringAfterLast(':').ifEmpty { "Folder" }
        val queried: String? = try {
            val docUri = DocumentsContract.buildDocumentUriUsingTree(treeUri, docId)
            resolver.query(docUri, arrayOf(DocumentsContract.Document.COLUMN_DISPLAY_NAME), null, null, null)
                ?.use { if (it.moveToFirst()) it.getString(0) else null }
        } catch (_: Exception) {
            null
        }
        return if (queried.isNullOrEmpty()) fallback else queried
    }

    // ---- metadata for items that lack it (SAF listings) ---------------------------------

    suspend fun enrich(item: VideoItem): VideoItem {
        if (item.durationMs > 0 && (item.width > 0 || item.isAudio)) return item
        metaCache[item.uri]?.let { return it }
        return withContext(Dispatchers.IO) {
            probeGate.withPermit {
                val mmr = MediaMetadataRetriever()
                try {
                    mmr.setDataSource(context, Uri.parse(item.uri))
                    val dur = mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
                    val w = mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)?.toIntOrNull() ?: 0
                    val h = mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)?.toIntOrNull() ?: 0
                    item.copy(durationMs = dur, width = w, height = h).also { metaCache[item.uri] = it }
                } catch (_: Exception) {
                    item
                } finally {
                    runCatching { mmr.release() }
                }
            }
        }
    }
}

@Suppress("DEPRECATION")
private const val LEGACY_DATA = MediaStore.Video.Media.DATA

fun SafEntry.toVideoItem(folder: String, volume: String = "external_primary"): VideoItem = VideoItem(
    uri = uri.toString(),
    name = name,
    sizeBytes = size,
    dateModifiedSec = modifiedMs / 1000,
    folderPath = folder,
    volume = volume,
    mimeType = mime,
    isAudio = MediaTypes.isAudioName(name) || mime?.startsWith("audio/") == true,
)
