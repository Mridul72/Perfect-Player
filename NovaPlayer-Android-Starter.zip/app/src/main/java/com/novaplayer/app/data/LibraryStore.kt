package com.novaplayer.app.data

import android.content.Context
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.core.stringSetPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import org.json.JSONArray
import org.json.JSONObject

private val Context.libraryStore by preferencesDataStore(name = "nova_library")

/**
 * Persists favourites, playback history / resume positions, authorised (SAF) folders and
 * excluded folders. Lists are stored as small JSON documents inside DataStore.
 */
class LibraryStore(private val context: Context) {

    private object K {
        val history = stringPreferencesKey("history")
        val favourites = stringPreferencesKey("favourites")
        val authorised = stringPreferencesKey("authorised")
        val excluded = stringSetPreferencesKey("excluded")
    }

    private val store get() = context.libraryStore

    val history: Flow<List<HistoryEntry>> = store.data.map { parseHistory(it[K.history]) }
    val favourites: Flow<List<VideoItem>> = store.data.map { parseVideos(it[K.favourites]) }
    val authorised: Flow<List<AuthorisedFolder>> = store.data.map { parseFolders(it[K.authorised]) }
    val excluded: Flow<Set<String>> = store.data.map { it[K.excluded] ?: emptySet() }

    // ---- history / resume -------------------------------------------------------------

    suspend fun recordProgress(video: VideoItem, positionMs: Long, durationMs: Long) {
        store.edit { p ->
            val list = parseHistory(p[K.history]).filterNot { it.video.key == video.key }.toMutableList()
            list.add(0, HistoryEntry(video, positionMs, durationMs, System.currentTimeMillis()))
            p[K.history] = historyToJson(list.take(MAX_HISTORY))
        }
    }

    suspend fun entryFor(key: String): HistoryEntry? =
        history.first().firstOrNull { it.video.key == key }

    suspend fun removeHistory(key: String) {
        store.edit { p ->
            p[K.history] = historyToJson(parseHistory(p[K.history]).filterNot { it.video.key == key })
        }
    }

    suspend fun clearHistory() {
        store.edit { it.remove(K.history) }
    }

    // ---- favourites -------------------------------------------------------------------

    suspend fun toggleFavourite(video: VideoItem) {
        store.edit { p ->
            val list = parseVideos(p[K.favourites]).toMutableList()
            val idx = list.indexOfFirst { it.key == video.key }
            if (idx >= 0) list.removeAt(idx) else list.add(0, video)
            p[K.favourites] = videosToJson(list)
        }
    }

    suspend fun setFavourites(videos: List<VideoItem>, favourite: Boolean) {
        store.edit { p ->
            val list = parseVideos(p[K.favourites]).toMutableList()
            for (v in videos) {
                val idx = list.indexOfFirst { it.key == v.key }
                if (favourite && idx < 0) list.add(0, v)
                if (!favourite && idx >= 0) list.removeAt(idx)
            }
            p[K.favourites] = videosToJson(list)
        }
    }

    // ---- authorised folders -----------------------------------------------------------

    suspend fun authorisedNow(): List<AuthorisedFolder> = authorised.first()

    suspend fun addAuthorised(folder: AuthorisedFolder) {
        store.edit { p ->
            val list = parseFolders(p[K.authorised]).filterNot { it.uri == folder.uri }.toMutableList()
            list.add(folder)
            p[K.authorised] = foldersToJson(list)
        }
    }

    suspend fun removeAuthorised(uri: String) {
        store.edit { p ->
            p[K.authorised] = foldersToJson(parseFolders(p[K.authorised]).filterNot { it.uri == uri })
        }
    }

    // ---- excluded folders -------------------------------------------------------------

    suspend fun addExcluded(path: String) {
        store.edit { p -> p[K.excluded] = (p[K.excluded] ?: emptySet()) + path }
    }

    suspend fun removeExcluded(path: String) {
        store.edit { p -> p[K.excluded] = (p[K.excluded] ?: emptySet()) - path }
    }

    // ---- JSON helpers -----------------------------------------------------------------

    private fun VideoItem.toJson(): JSONObject = JSONObject().apply {
        put("uri", uri); put("name", name); put("size", sizeBytes); put("dur", durationMs)
        put("w", width); put("h", height); put("mod", dateModifiedSec); put("add", dateAddedSec)
        put("folder", folderPath); put("vol", volume); put("mime", mimeType ?: ""); put("audio", isAudio)
    }

    private fun JSONObject.toVideo(): VideoItem = VideoItem(
        uri = getString("uri"),
        name = getString("name"),
        sizeBytes = optLong("size", -1),
        durationMs = optLong("dur", 0),
        width = optInt("w", 0),
        height = optInt("h", 0),
        dateModifiedSec = optLong("mod", 0),
        dateAddedSec = optLong("add", 0),
        folderPath = optString("folder", ""),
        volume = optString("vol", "external_primary"),
        mimeType = optString("mime", "").ifEmpty { null },
        isAudio = optBoolean("audio", false),
    )

    private fun videosToJson(list: List<VideoItem>): String =
        JSONArray().apply { list.forEach { put(it.toJson()) } }.toString()

    private fun parseVideos(s: String?): List<VideoItem> = parseArray(s) { it.toVideo() }

    private fun historyToJson(list: List<HistoryEntry>): String = JSONArray().apply {
        list.forEach { e ->
            put(JSONObject().apply {
                put("v", e.video.toJson()); put("pos", e.positionMs); put("dur", e.durationMs); put("t", e.lastPlayed)
            })
        }
    }.toString()

    private fun parseHistory(s: String?): List<HistoryEntry> = parseArray(s) { o ->
        HistoryEntry(o.getJSONObject("v").toVideo(), o.optLong("pos"), o.optLong("dur"), o.optLong("t"))
    }

    private fun foldersToJson(list: List<AuthorisedFolder>): String = JSONArray().apply {
        list.forEach { put(JSONObject().apply { put("uri", it.uri); put("name", it.name) }) }
    }.toString()

    private fun parseFolders(s: String?): List<AuthorisedFolder> =
        parseArray(s) { AuthorisedFolder(it.getString("uri"), it.optString("name", "Folder")) }

    private inline fun <T> parseArray(s: String?, map: (JSONObject) -> T): List<T> {
        if (s.isNullOrEmpty()) return emptyList()
        return try {
            val arr = JSONArray(s)
            val out = ArrayList<T>(arr.length())
            for (i in 0 until arr.length()) {
                try { out.add(map(arr.getJSONObject(i))) } catch (_: Exception) { /* skip corrupt row */ }
            }
            out
        } catch (_: Exception) {
            emptyList()
        }
    }

    private companion object {
        const val MAX_HISTORY = 300
    }
}
