package com.novaplayer.app.ui

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Folder
import androidx.compose.material.icons.rounded.Home
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material.icons.rounded.VideoLibrary
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import com.novaplayer.app.ui.screens.FoldersScreen
import com.novaplayer.app.ui.screens.HomeScreen
import com.novaplayer.app.ui.screens.SearchScreen
import com.novaplayer.app.ui.screens.SettingsScreen
import com.novaplayer.app.ui.screens.VideosScreen

@Composable
fun NovaRoot(vm: LibraryViewModel, actions: AppActions) {
    var tab by rememberSaveable { mutableIntStateOf(0) }
    var searching by rememberSaveable { mutableStateOf(false) }
    val tabs = listOf(
        "Home" to Icons.Rounded.Home,
        "Folders" to Icons.Rounded.Folder,
        "Videos" to Icons.Rounded.VideoLibrary,
        "Settings" to Icons.Rounded.Settings,
    )
    BackHandler(enabled = searching) { searching = false }

    Scaffold(
        containerColor = Color.Black,
        bottomBar = {
            NavigationBar(containerColor = Color(0xFF0A0A0A)) {
                tabs.forEachIndexed { i, (label, icon) ->
                    NavigationBarItem(
                        selected = tab == i,
                        onClick = { tab = i; searching = false },
                        icon = { Icon(icon, label) },
                        label = { Text(label) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = Color.Black,
                            selectedTextColor = MaterialTheme.colorScheme.primary,
                            indicatorColor = MaterialTheme.colorScheme.primary,
                            unselectedIconColor = Color(0xFF8A8A8A),
                            unselectedTextColor = Color(0xFF8A8A8A),
                        ),
                    )
                }
            }
        },
    ) { pad ->
        Box(Modifier.padding(pad).fillMaxSize()) {
            when (tab) {
                0 -> HomeScreen(vm, actions, onSearch = { searching = true }, onOpenTab = { tab = it })
                1 -> FoldersScreen(vm, actions)
                2 -> VideosScreen(vm, actions)
                else -> SettingsScreen(vm, actions)
            }
            AnimatedVisibility(visible = searching, enter = fadeIn(), exit = fadeOut()) {
                SearchScreen(vm, actions, onClose = { searching = false })
            }
        }
    }
}
