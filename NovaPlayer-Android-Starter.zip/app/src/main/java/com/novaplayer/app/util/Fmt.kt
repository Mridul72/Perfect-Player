package com.novaplayer.app.util

import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object Fmt {
    fun duration(ms: Long): String {
        val total = ms.coerceAtLeast(0L) / 1000
        val h = total / 3600
        val m = (total % 3600) / 60
        val s = total % 60
        return if (h > 0) String.format(Locale.US, "%d:%02d:%02d", h, m, s)
        else String.format(Locale.US, "%d:%02d", m, s)
    }

    fun size(bytes: Long): String {
        if (bytes <= 0) return "—"
        val kb = 1024.0
        val mb = kb * 1024
        val gb = mb * 1024
        return when {
            bytes >= gb -> String.format(Locale.US, "%.2f GB", bytes / gb)
            bytes >= mb -> String.format(Locale.US, "%.1f MB", bytes / mb)
            else -> String.format(Locale.US, "%.0f KB", bytes / kb)
        }
    }

    fun date(epochSec: Long): String {
        if (epochSec <= 0) return ""
        return SimpleDateFormat("d MMM yyyy", Locale.getDefault()).format(Date(epochSec * 1000))
    }

    fun speed(v: Float): String {
        val s = if (v % 1f == 0f) v.toInt().toString()
        else String.format(Locale.US, "%.2f", v).trimEnd('0').trimEnd('.')
        return "${s}x"
    }
}
