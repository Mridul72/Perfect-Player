package com.novaplayer.app.playback

import android.content.ContentUris
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.DocumentsContract
import android.provider.OpenableColumns
import com.novaplayer.app.data.AuthorisedFolder
import com.novaplayer.app.data.LibraryStore
import com.novaplayer.app.data.MediaRepository
import com.novaplayer.app.data.SafEntry
import com.novaplayer.app.data.VideoItem
import com.novaplayer.app.data.toVideoItem
import com.novaplayer.app.util.DocIds
import com.novaplayer.app.util.MediaTypes
import com.novaplayer.app.util.NaturalOrder
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

/**
 * Turns "open this one video" (an Intent from 1DM, a file manager, ...) into "play this folder".
 *
 * Android does not give the receiver of a content:// URI access to its directory, so the folder
 * is discovered with the following strategies, in order:
 *  1. The URI is an ExternalStorageProvider document inside a folder the user already authorised.
 *  2. MediaStore: match the URI (or its display name + size) to an indexed video, then list the
 *     videos with the same RELATIVE_PATH (needs the READ_MEDIA_VIDEO permission).
 *  3. Search the authorised folders for a file with that name and size.
 * If all fail, the caller asks the user to pick the folder once (ACTION_OPEN_DOCUMENT_TREE).
 */
class PlaylistResolver(
    private val context: Context,
    private val media: MediaRepository,
    private val library: LibraryStore,
) {
    data class SubtitleFile(val name: String, val uri: String)

    enum class Source { MEDIASTORE, SAF }

    data class Resolved(
        val items: List<VideoItem>,
        val index: Int,
        val source: Source,
        val subtitles: List<SubtitleFile> = emptyList(),
        val folderLabel: String = "",
    )

    /** Cheap description of the incoming URI so playback can start immediately. */
    fun describe(uri: Uri, mimeHint: String?): VideoItem {
        val (name, size) = queryNameSize(uri)
        val n = name ?: uri.lastPathSegment?.substringAfterLast('/') ?: "Video"
        val mime = mimeHint ?: runCatching { context.contentResolver.getType(uri) }.getOrNull()
        return VideoItem(
            uri = uri.toString(),
            name = n,
            sizeBytes = size,
            mimeType = mime,
            isAudio = mime?.startsWith("audio/") == true || MediaTypes.isAudioName(n),
        )
    }

    suspend fun resolve(uri: Uri, current: VideoItem): Resolved? = withContext(Dispatchers.IO) {
        val trees = library.authorisedNow().filter { isPersisted(Uri.parse(it.uri)) }

        // 1. Document id of the incoming URI itself, inside an authorised tree.
        parentDocIdOf(uri)?.let { parent ->
            listFromTrees(trees, parent, current)?.let { return@withContext it }
        }

        // 2. MediaStore (needs the media permission).
        val row = findMediaStoreRow(uri, current)
        if (row != null) {
            val parentDoc = DocIds.forFolder(row.volume, row.folderPath)
            listFromTrees(trees, parentDoc, current)?.let { return@withContext it }
            mediaStoreSiblings(row)?.let { return@withContext it }
        }

        // 3. Brute-force search of the authorised folders.
        searchTrees(trees, current)?.let { return@withContext it }
        null
    }

    /** Persists read access to a folder the user picked and remembers it. */
    suspend fun authoriseFolder(treeUri: Uri): AuthorisedFolder = withContext(Dispatchers.IO) {
        runCatching {
            context.contentResolver.takePersistableUriPermission(treeUri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        val folder = AuthorisedFolder(treeUri.toString(), media.treeName(treeUri))
        library.addAuthorised(folder)
        folder
    }

    /** Where the folder picker should open: the incoming file's folder when we can tell. */
    fun pickerHint(uri: Uri?): Uri {
        val parent = uri?.let { parentDocIdOf(it) } ?: "primary:Download"
        return DocumentsContract.buildDocumentUri(DocIds.EXTERNAL_STORAGE_AUTHORITY, parent)
    }

    // ---- strategy 1 & 2 helpers -----------------------------------------------------------

    private fun parentDocIdOf(uri: Uri): String? {
        if (uri.scheme != "content" || uri.authority != DocIds.EXTERNAL_STORAGE_AUTHORITY) return null
        val docId = try {
            DocumentsContract.getDocumentId(uri)
        } catch (_: Exception) {
            return null
        }
        return DocIds.parentOf(docId)
    }

    private fun findMediaStoreRow(uri: Uri, current: VideoItem): VideoItem? {
        if (!media.hasMediaPermission()) return null
        mediaStoreId(uri)?.let { id -> media.findVideoById(id)?.let { return it } }
        return media.findVideosByName(current.name, current.sizeBytes).firstOrNull()
    }

    private fun mediaStoreId(uri: Uri): Long? = try {
        when (uri.authority) {
            "media" -> if (uri.pathSegments.contains("video")) ContentUris.parseId(uri) else null
            "com.android.providers.media.documents" -> {
                val docId = DocumentsContract.getDocumentId(uri)
                if (docId.startsWith("video:")) docId.substringAfter(':').toLongOrNull() else null
            }
            else -> null
        }
    } catch (_: Exception) {
        null
    }

    private fun mediaStoreSiblings(row: VideoItem): Resolved? {
        val items = media.videosInFolder(row.volume, row.folderPath)
            .sortedWith(compareBy<VideoItem, String>(NaturalOrder) { it.name })
        if (items.isEmpty()) return null
        var idx = items.indexOfFirst { it.uri == row.uri }
        if (idx < 0) idx = items.indexOfFirst { it.name == row.name }
        if (idx < 0) return null
        return Resolved(items, idx, Source.MEDIASTORE, emptyList(), row.folderPath.trimEnd('/'))
    }

    // ---- SAF helpers ------------------------------------------------------------------------

    private fun isPersisted(treeUri: Uri): Boolean =
        context.contentResolver.persistedUriPermissions.any { it.uri == treeUri && it.isReadPermission }

    private fun listFromTrees(trees: List<AuthorisedFolder>, parentDocId: String, current: VideoItem): Resolved? {
        for (t in trees) {
            val treeUri = Uri.parse(t.uri)
            if (treeUri.authority != DocIds.EXTERNAL_STORAGE_AUTHORITY) continue
            val treeDoc = try {
                DocumentsContract.getTreeDocumentId(treeUri)
            } catch (_: Exception) {
                continue
            }
            if (!DocIds.covers(treeDoc, parentDocId)) continue
            val children = media.listSaf(treeUri, parentDocId)
            buildFromChildren(children, parentDocId, current)?.let { return it }
        }
        return null
    }

    private fun searchTrees(trees: List<AuthorisedFolder>, current: VideoItem): Resolved? {
        for (t in trees) {
            val treeUri = Uri.parse(t.uri)
            val rootDoc = runCatching { DocumentsContract.getTreeDocumentId(treeUri) }.getOrNull() ?: continue
            val queue = ArrayDeque<Pair<String, Int>>()
            queue.add(rootDoc to 0)
            var visited = 0
            while (queue.isNotEmpty() && visited < MAX_FOLDERS_SEARCHED) {
                val (docId, depth) = queue.removeFirst()
                visited++
                val children = media.listSaf(treeUri, docId)
                buildFromChildren(children, docId, current)?.let { return it }
                if (depth < MAX_DEPTH) {
                    children.filter { it.isDir }.forEach { queue.add(it.docId to depth + 1) }
                }
            }
        }
        return null
    }

    private fun buildFromChildren(children: List<SafEntry>, folderDocId: String, current: VideoItem): Resolved? {
        val vids = children
            .filter { !it.isDir && MediaTypes.isMedia(it.name, it.mime) }
            .sortedWith(compareBy<SafEntry, String>(NaturalOrder) { it.name })
        if (vids.isEmpty()) return null
        val folderPath = folderDocId.substringAfter(':', "").trim('/').let { if (it.isEmpty()) "" else "$it/" }
        val items = vids.map { it.toVideoItem(folderPath) }
        var idx = items.indexOfFirst {
            it.name == current.name && (current.sizeBytes <= 0 || it.sizeBytes == current.sizeBytes)
        }
        if (idx < 0) idx = items.indexOfFirst { it.name == current.name }
        if (idx < 0) return null
        val subs = children
            .filter { !it.isDir && MediaTypes.isSubtitle(it.name) }
            .map { SubtitleFile(it.name, it.uri.toString()) }
        return Resolved(items, idx, Source.SAF, subs, folderPath.trimEnd('/'))
    }

    private fun queryNameSize(uri: Uri): Pair<String?, Long> {
        if (uri.scheme == "file") {
            val f = File(uri.path ?: "")
            return f.name.ifEmpty { null } to (if (f.exists()) f.length() else -1L)
        }
        var name: String? = null
        var size = -1L
        try {
            context.contentResolver.query(
                uri, arrayOf(OpenableColumns.DISPLAY_NAME, OpenableColumns.SIZE), null, null, null
            )?.use { c ->
                if (c.moveToFirst()) {
                    val iName = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    val iSize = c.getColumnIndex(OpenableColumns.SIZE)
                    if (iName >= 0 && !c.isNull(iName)) name = c.getString(iName)
                    if (iSize >= 0 && !c.isNull(iSize)) size = c.getLong(iSize)
                }
            }
        } catch (_: Exception) {
            // provider refused the query; fall back to the URI itself
        }
        return name to size
    }

    private companion object {
        const val MAX_DEPTH = 6
        const val MAX_FOLDERS_SEARCHED = 500
    }
}

/** Hand-over between MainActivity (library) and PlayerActivity within the same process. */
object PlaybackRequests {
    data class Pending(val items: List<VideoItem>, val startIndex: Int)

    @Volatile
    var pending: Pending? = null

    fun take(): Pending? {
        val p = pending
        pending = null
        return p
    }
}
