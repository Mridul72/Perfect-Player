package com.novaplayer.app.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.itemsIndexed as gridItemsIndexed
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.Sort
import androidx.compose.material.icons.automirrored.rounded.ViewList
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Favorite
import androidx.compose.material.icons.rounded.GridView
import androidx.compose.material.icons.rounded.History
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.SelectAll
import androidx.compose.material.icons.rounded.VideoLibrary
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.novaplayer.app.data.AppSettings
import com.novaplayer.app.data.SortField
import com.novaplayer.app.data.sortedByField
import com.novaplayer.app.ui.AppActions
import com.novaplayer.app.ui.LibraryViewModel
import com.novaplayer.app.ui.components.EmptyState
import com.novaplayer.app.ui.components.VideoCard
import com.novaplayer.app.ui.components.VideoRow

@Composable
fun SortMenu(settings: AppSettings, onChange: (SortField, Boolean) -> Unit) {
    var open by remember { mutableStateOf(false) }
    Box {
        IconButton(onClick = { open = true }) { Icon(Icons.AutoMirrored.Rounded.Sort, "Sort") }
        DropdownMenu(expanded = open, onDismissRequest = { open = false }) {
            SortField.entries.forEach { f ->
                DropdownMenuItem(
                    text = { Text(f.label) },
                    onClick = { onChange(f, settings.sortAscending); open = false },
                    trailingIcon = { if (settings.sort == f) Icon(Icons.Rounded.Check, null) },
                )
            }
            HorizontalDivider()
            DropdownMenuItem(
                text = { Text("Ascending") },
                onClick = { onChange(settings.sort, true); open = false },
                trailingIcon = { if (settings.sortAscending) Icon(Icons.Rounded.Check, null) },
            )
            DropdownMenuItem(
                text = { Text("Descending") },
                onClick = { onChange(settings.sort, false); open = false },
                trailingIcon = { if (!settings.sortAscending) Icon(Icons.Rounded.Check, null) },
            )
        }
    }
}

@Composable
fun VideosScreen(vm: LibraryViewModel, actions: AppActions) {
    val videos by vm.videos.collectAsStateWithLifecycle()
    val favs by vm.favourites.collectAsStateWithLifecycle()
    val history by vm.history.collectAsStateWithLifecycle()
    val settings by vm.settings.collectAsStateWithLifecycle()

    var filter by rememberSaveable { mutableIntStateOf(0) } // 0 all, 1 favourites, 2 history
    var query by rememberSaveable { mutableStateOf("") }
    var searchOpen by rememberSaveable { mutableStateOf(false) }
    var selected by remember { mutableStateOf(setOf<String>()) }

    val favKeys = remember(favs) { favs.map { it.key }.toSet() }
    val progress = remember(history) { history.associate { it.video.key to it.progress } }
    val base = when (filter) {
        1 -> favs
        2 -> history.map { it.video }
        else -> videos
    }
    val list = remember(base, query, settings.sortField, settings.sortAscending, filter) {
        val matched = base.filter { query.isBlank() || it.name.contains(query.trim(), ignoreCase = true) }
        if (filter == 2) matched else matched.sortedByField(settings.sort, settings.sortAscending)
    }
    val selecting = selected.isNotEmpty()
    BackHandler(enabled = selecting) { selected = emptySet() }

    fun open(i: Int) = actions.play(list, i)
    fun toggle(key: String) {
        selected = if (key in selected) selected - key else selected + key
    }

    Column(Modifier.fillMaxSize()) {
        if (selecting) {
            val items = list.filter { it.key in selected }
            Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = { selected = emptySet() }) { Icon(Icons.Rounded.Close, "Clear selection") }
                Text("${selected.size} selected", style = MaterialTheme.typography.titleLarge, modifier = Modifier.weight(1f))
                IconButton(onClick = { selected = list.map { it.key }.toSet() }) { Icon(Icons.Rounded.SelectAll, "Select all") }
                IconButton(onClick = {
                    val allFav = items.isNotEmpty() && items.all { it.key in favKeys }
                    vm.setFavourites(items, !allFav)
                    selected = emptySet()
                }) { Icon(Icons.Rounded.Favorite, "Toggle favourite") }
                IconButton(onClick = {
                    actions.play(items, 0)
                    selected = emptySet()
                }) { Icon(Icons.Rounded.PlayArrow, "Play selected") }
            }
        } else {
            Row(Modifier.fillMaxWidth().padding(start = 20.dp, end = 8.dp, top = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("Videos", style = MaterialTheme.typography.headlineMedium)
                    Text("${list.size} shown", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                IconButton(onClick = { searchOpen = !searchOpen; if (!searchOpen) query = "" }) { Icon(Icons.Rounded.Search, "Search") }
                IconButton(onClick = { vm.update { copy(libraryGrid = !libraryGrid) } }) {
                    Icon(if (settings.libraryGrid) Icons.AutoMirrored.Rounded.ViewList else Icons.Rounded.GridView, "Change layout")
                }
                if (filter == 2) {
                    TextButton(onClick = vm::clearHistory) { Text("Clear", color = MaterialTheme.colorScheme.primary) }
                } else {
                    SortMenu(settings) { f, asc -> vm.update { copy(sortField = f.name, sortAscending = asc) } }
                }
            }
            if (searchOpen) {
                SearchField(query, { query = it }, Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp), autoFocus = true)
            }
        }

        Row(Modifier.padding(horizontal = 16.dp, vertical = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("All" to null, "Favourites" to Icons.Rounded.Favorite, "History" to Icons.Rounded.History).forEachIndexed { i, (label, icon) ->
                FilterChip(
                    selected = filter == i,
                    onClick = { filter = i; selected = emptySet() },
                    label = { Text(label) },
                    leadingIcon = if (icon != null) ({ Icon(icon, null) }) else null,
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = MaterialTheme.colorScheme.primary,
                        selectedLabelColor = Color.Black,
                        selectedLeadingIconColor = Color.Black,
                    ),
                )
            }
        }

        if (list.isEmpty()) {
            when {
                filter == 1 -> EmptyState(Icons.Rounded.Favorite, "No favourites yet", "Tap the heart on any video, or long-press to select several.")
                filter == 2 -> EmptyState(Icons.Rounded.History, "Nothing played yet", "Videos you watch show up here with your progress.")
                query.isNotBlank() -> EmptyState(Icons.Rounded.Search, "No matches", "Nothing matches “${query.trim()}”.")
                else -> EmptyState(Icons.Rounded.VideoLibrary, "No videos", "Allow video access on Home, or browse authorised folders in Folders.")
            }
        } else if (settings.libraryGrid) {
            LazyVerticalGrid(
                columns = GridCells.Fixed(settings.gridColumns.coerceIn(2, 4)),
                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp),
            ) {
                gridItemsIndexed(list) { i, v ->
                    VideoCard(
                        v,
                        progress = progress[v.key]?.takeIf { it < 0.95f } ?: 0f,
                        selected = v.key in selected,
                        showThumb = settings.showThumbnails,
                        onClick = { if (selecting) toggle(v.key) else open(i) },
                        onLongClick = { toggle(v.key) },
                    )
                }
            }
        } else {
            LazyColumn {
                itemsIndexed(list) { i, v ->
                    VideoRow(
                        v,
                        selected = v.key in selected,
                        progress = progress[v.key]?.takeIf { it < 0.95f } ?: 0f,
                        favourite = v.key in favKeys,
                        showThumb = settings.showThumbnails,
                        onClick = { if (selecting) toggle(v.key) else open(i) },
                        onLongClick = { toggle(v.key) },
                        onFavourite = { vm.toggleFavourite(v) },
                    )
                }
            }
        }
    }
}
