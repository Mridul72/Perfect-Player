package com.novaplayer.app.ui.components

import android.net.Uri
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.matchParentSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.Favorite
import androidx.compose.material.icons.rounded.FavoriteBorder
import androidx.compose.material.icons.rounded.Folder
import androidx.compose.material.icons.rounded.Headphones
import androidx.compose.material.icons.rounded.Movie
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import coil.request.ImageRequest
import coil.request.videoFrameMillis
import com.novaplayer.app.data.VideoItem
import com.novaplayer.app.nova
import com.novaplayer.app.util.Fmt

/** Fills in duration / resolution for items that come from folder listings without metadata. */
@Composable
fun rememberEnriched(item: VideoItem): VideoItem {
    val ctx = LocalContext.current
    val state = produceState(initialValue = item, item.uri) { value = ctx.nova.media.enrich(item) }
    return state.value
}

fun VideoItem.metaLine(): String =
    listOfNotNull(
        Fmt.size(sizeBytes).takeIf { sizeBytes > 0 },
        resolutionLabel,
        Fmt.date(dateModifiedSec).takeIf { it.isNotEmpty() },
    ).joinToString("  ·  ")

@Composable
fun Thumb(item: VideoItem, modifier: Modifier = Modifier, showImage: Boolean = true) {
    val ctx = LocalContext.current
    Box(
        modifier.clip(RoundedCornerShape(12.dp)).background(Color(0xFF1B1B1B)),
        contentAlignment = Alignment.Center,
    ) {
        Icon(
            if (item.isAudio) Icons.Rounded.Headphones else Icons.Rounded.Movie,
            null,
            tint = Color(0xFF3A3A3A),
            modifier = Modifier.size(28.dp),
        )
        if (showImage && !item.isAudio) {
            val request = remember(item.uri) {
                ImageRequest.Builder(ctx)
                    .data(Uri.parse(item.uri))
                    .videoFrameMillis(1500)
                    .size(480, 270)
                    .build()
            }
            AsyncImage(
                model = request,
                contentDescription = null,
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize(),
            )
        }
    }
}

@Composable
fun DurationBadge(text: String, modifier: Modifier = Modifier) {
    Text(
        text,
        color = Color.White,
        fontSize = 11.sp,
        fontWeight = FontWeight.SemiBold,
        modifier = modifier.background(Color(0xCC000000), RoundedCornerShape(6.dp)).padding(horizontal = 6.dp, vertical = 2.dp),
    )
}

@Composable
private fun SelectedOverlay(modifier: Modifier) {
    Box(
        modifier.background(MaterialTheme.colorScheme.primary.copy(alpha = 0.35f), RoundedCornerShape(12.dp)),
        contentAlignment = Alignment.Center,
    ) {
        Box(Modifier.size(32.dp).background(MaterialTheme.colorScheme.primary, CircleShape), contentAlignment = Alignment.Center) {
            Icon(Icons.Rounded.Check, null, tint = Color.Black, modifier = Modifier.size(20.dp))
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun VideoCard(
    item: VideoItem,
    modifier: Modifier = Modifier,
    progress: Float = 0f,
    selected: Boolean = false,
    showThumb: Boolean = true,
    onClick: () -> Unit,
    onLongClick: () -> Unit = {},
) {
    val v = rememberEnriched(item)
    Column(modifier.combinedClickable(onClick = onClick, onLongClick = onLongClick).padding(4.dp)) {
        Box {
            Thumb(v, Modifier.fillMaxWidth().aspectRatio(16f / 9f), showThumb)
            if (v.durationMs > 0) {
                DurationBadge(Fmt.duration(v.durationMs), Modifier.align(Alignment.BottomEnd).padding(6.dp))
            }
            if (progress > 0f) {
                LinearProgressIndicator(
                    progress = { progress },
                    modifier = Modifier.align(Alignment.BottomCenter).fillMaxWidth().height(3.dp),
                    color = MaterialTheme.colorScheme.primary,
                    trackColor = Color(0x66000000),
                )
            }
            if (selected) SelectedOverlay(Modifier.matchParentSize())
        }
        Text(
            v.title,
            maxLines = 2,
            overflow = TextOverflow.Ellipsis,
            style = MaterialTheme.typography.bodyMedium,
            modifier = Modifier.padding(top = 6.dp),
        )
        val meta = v.metaLine()
        if (meta.isNotEmpty()) {
            Text(
                meta,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun VideoRow(
    item: VideoItem,
    modifier: Modifier = Modifier,
    selected: Boolean = false,
    progress: Float = 0f,
    favourite: Boolean = false,
    showThumb: Boolean = true,
    onClick: () -> Unit,
    onLongClick: () -> Unit = {},
    onFavourite: (() -> Unit)? = null,
) {
    val v = rememberEnriched(item)
    Row(
        modifier.fillMaxWidth()
            .combinedClickable(onClick = onClick, onLongClick = onLongClick)
            .background(if (selected) MaterialTheme.colorScheme.primary.copy(alpha = 0.12f) else Color.Transparent)
            .padding(horizontal = 16.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        Box {
            Thumb(v, Modifier.width(128.dp).aspectRatio(16f / 9f), showThumb)
            if (v.durationMs > 0) {
                DurationBadge(Fmt.duration(v.durationMs), Modifier.align(Alignment.BottomEnd).padding(5.dp))
            }
            if (progress > 0f) {
                LinearProgressIndicator(
                    progress = { progress },
                    modifier = Modifier.align(Alignment.BottomCenter).fillMaxWidth().height(3.dp),
                    color = MaterialTheme.colorScheme.primary,
                    trackColor = Color(0x66000000),
                )
            }
            if (selected) SelectedOverlay(Modifier.matchParentSize())
        }
        Column(Modifier.weight(1f)) {
            Text(v.title, maxLines = 2, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.bodyMedium)
            val meta = v.metaLine()
            if (meta.isNotEmpty()) {
                Text(
                    meta,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(top = 2.dp),
                )
            }
        }
        if (onFavourite != null) {
            IconButton(onClick = onFavourite) {
                Icon(
                    if (favourite) Icons.Rounded.Favorite else Icons.Rounded.FavoriteBorder,
                    if (favourite) "Remove from favourites" else "Add to favourites",
                    tint = if (favourite) MaterialTheme.colorScheme.primary else Color(0xFF6A6A6A),
                )
            }
        }
    }
}

@Composable
fun FolderRow(
    title: String,
    subtitle: String,
    thumb: VideoItem?,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    trailing: @Composable (() -> Unit)? = null,
) {
    Row(
        modifier.fillMaxWidth().clickable(onClick = onClick).padding(horizontal = 16.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        Box(
            Modifier.size(width = 72.dp, height = 54.dp).clip(RoundedCornerShape(12.dp)).background(Color(0xFF1B1B1B)),
            contentAlignment = Alignment.Center,
        ) {
            Icon(Icons.Rounded.Folder, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(28.dp))
            if (thumb != null && !thumb.isAudio) Thumb(thumb, Modifier.matchParentSize().background(Color(0x99000000)))
        }
        Column(Modifier.weight(1f)) {
            Text(title, maxLines = 1, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.titleMedium)
            Text(
                subtitle,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
        trailing?.invoke()
    }
}

@Composable
fun SectionHeader(title: String, action: String? = null, onAction: () -> Unit = {}) {
    Row(
        Modifier.fillMaxWidth().padding(start = 20.dp, end = 12.dp, top = 20.dp, bottom = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(title, style = MaterialTheme.typography.titleLarge, modifier = Modifier.weight(1f))
        if (action != null) {
            androidx.compose.material3.TextButton(onClick = onAction) {
                Text(action, color = MaterialTheme.colorScheme.primary)
            }
        }
    }
}

@Composable
fun EmptyState(
    icon: ImageVector,
    title: String,
    body: String,
    actionLabel: String? = null,
    onAction: () -> Unit = {},
    modifier: Modifier = Modifier,
) {
    Column(
        modifier.fillMaxWidth().padding(32.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
    ) {
        Icon(icon, null, tint = Color(0xFF3A3A3A), modifier = Modifier.size(56.dp))
        Text(title, style = MaterialTheme.typography.titleMedium, modifier = Modifier.padding(top = 12.dp), textAlign = TextAlign.Center)
        Text(
            body,
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            textAlign = TextAlign.Center,
            modifier = Modifier.padding(top = 6.dp),
        )
        if (actionLabel != null) {
            Button(
                onClick = onAction,
                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                modifier = Modifier.padding(top = 16.dp),
            ) { Text(actionLabel, color = Color.Black) }
        }
    }
}
