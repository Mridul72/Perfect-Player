package com.novaplayer.app.ui

import android.app.Application
import android.content.Intent
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.novaplayer.app.NovaApp
import com.novaplayer.app.data.AppSettings
import com.novaplayer.app.data.AuthorisedFolder
import com.novaplayer.app.data.HistoryEntry
import com.novaplayer.app.data.VideoItem
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

/** Where the folder browser currently is. Encoded as a string so it can be remembered. */
sealed interface Loc {
    data object Root : Loc
    data class Device(val path: String) : Loc
    data class Saf(val tree: String, val docId: String, val title: String) : Loc

    fun encode(): String = when (this) {
        Root -> "root"
        is Device -> "d:$path"
        is Saf -> "s:$tree|$docId|$title"
    }

    companion object {
        fun parse(s: String): Loc = when {
            s.startsWith("d:") -> Device(s.removePrefix("d:"))
            s.startsWith("s:") -> {
                val p = s.removePrefix("s:").split("|", limit = 3)
                if (p.size == 3) Saf(p[0], p[1], p[2]) else Root
            }
            else -> Root
        }
    }
}

class LibraryViewModel(app: Application) : AndroidViewModel(app) {
    private val nova = app as NovaApp

    val settings: StateFlow<AppSettings> =
        nova.settings.flow.stateIn(viewModelScope, SharingStarted.Eagerly, AppSettings())
    val history: StateFlow<List<HistoryEntry>> =
        nova.library.history.stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
    val favourites: StateFlow<List<VideoItem>> =
        nova.library.favourites.stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
    val authorised: StateFlow<List<AuthorisedFolder>> =
        nova.library.authorised.stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
    val excluded: StateFlow<Set<String>> =
        nova.library.excluded.stateIn(viewModelScope, SharingStarted.Eagerly, emptySet())

    private val all = MutableStateFlow<List<VideoItem>>(emptyList())

    /** Library without the folders the user excluded (exclusion covers sub-folders). */
    val videos: StateFlow<List<VideoItem>> = combine(all, excluded) { list, ex ->
        if (ex.isEmpty()) list else list.filter { v -> ex.none { v.folderPath.startsWith(it) } }
    }.stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    private val _loading = MutableStateFlow(false)
    val loading: StateFlow<Boolean> = _loading.asStateFlow()

    private val _hasPermission = MutableStateFlow(nova.media.hasMediaPermission())
    val hasPermission: StateFlow<Boolean> = _hasPermission.asStateFlow()

    // ---- folder browser navigation ---------------------------------------------------------

    private val _loc = MutableStateFlow<Loc>(Loc.Root)
    val loc: StateFlow<Loc> = _loc.asStateFlow()
    private val backStack = ArrayList<Loc>()
    private val _canGoBack = MutableStateFlow(false)
    val canGoBack: StateFlow<Boolean> = _canGoBack.asStateFlow()

    init {
        viewModelScope.launch {
            val s = nova.settings.flow.first()
            if (s.rememberFolder) restore(Loc.parse(s.lastFolder))
        }
        refresh()
    }

    private fun restore(target: Loc) {
        backStack.clear()
        backStack.add(Loc.Root)
        if (target is Loc.Device) {
            var path = ""
            target.path.trim('/').split('/').filter { it.isNotEmpty() }.dropLast(1).forEach { seg ->
                path += "$seg/"
                backStack.add(Loc.Device(path))
            }
        }
        if (target is Loc.Root) backStack.clear()
        _loc.value = target
        _canGoBack.value = backStack.isNotEmpty()
    }

    fun navigate(to: Loc) {
        backStack.add(_loc.value)
        _loc.value = to
        _canGoBack.value = true
        rememberLoc()
    }

    fun goBack(): Boolean {
        if (backStack.isEmpty()) return false
        _loc.value = backStack.removeAt(backStack.lastIndex)
        _canGoBack.value = backStack.isNotEmpty()
        rememberLoc()
        return true
    }

    private fun rememberLoc() {
        val enc = _loc.value.encode()
        update { copy(lastFolder = enc) }
    }

    // ---- library -------------------------------------------------------------------------------

    fun refresh() {
        viewModelScope.launch {
            _hasPermission.value = nova.media.hasMediaPermission()
            _loading.value = true
            all.value = nova.media.loadVideos()
            _loading.value = false
        }
    }

    fun onPermissionChanged() = refresh()

    fun update(transform: AppSettings.() -> AppSettings) {
        nova.appScope.launch { nova.settings.update(transform) }
    }

    fun resetSettings() {
        nova.appScope.launch { nova.settings.reset() }
    }

    fun toggleFavourite(v: VideoItem) {
        nova.appScope.launch { nova.library.toggleFavourite(v) }
    }

    fun setFavourites(items: List<VideoItem>, favourite: Boolean) {
        nova.appScope.launch { nova.library.setFavourites(items, favourite) }
    }

    fun clearHistory() {
        nova.appScope.launch { nova.library.clearHistory() }
    }

    fun removeHistory(key: String) {
        nova.appScope.launch { nova.library.removeHistory(key) }
    }

    fun exclude(path: String) {
        nova.appScope.launch { nova.library.addExcluded(path) }
    }

    fun unexclude(path: String) {
        nova.appScope.launch { nova.library.removeExcluded(path) }
    }

    fun addAuthorisedFolder(uri: Uri) {
        nova.appScope.launch { nova.resolver.authoriseFolder(uri) }
    }

    fun removeAuthorisedFolder(uri: String) {
        runCatching {
            getApplication<Application>().contentResolver
                .releasePersistableUriPermission(Uri.parse(uri), Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        nova.appScope.launch { nova.library.removeAuthorised(uri) }
    }
}
