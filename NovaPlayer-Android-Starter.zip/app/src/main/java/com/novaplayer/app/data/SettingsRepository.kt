package com.novaplayer.app.data

import android.content.Context
import androidx.datastore.preferences.core.MutablePreferences
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.floatPreferencesKey
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.settingsStore by preferencesDataStore(name = "nova_settings")

class SettingsRepository(private val context: Context) {

    private object K {
        val accent = intPreferencesKey("accent")
        val libraryGrid = booleanPreferencesKey("library_grid")
        val gridColumns = intPreferencesKey("grid_columns")
        val showThumbnails = booleanPreferencesKey("show_thumbnails")
        val sortField = stringPreferencesKey("sort_field")
        val sortAscending = booleanPreferencesKey("sort_ascending")
        val rememberFolder = booleanPreferencesKey("remember_folder")
        val lastFolder = stringPreferencesKey("last_folder")
        val resume = booleanPreferencesKey("resume")
        val autoNext = booleanPreferencesKey("auto_next")
        val repeatMode = intPreferencesKey("repeat_mode")
        val defaultSpeed = floatPreferencesKey("default_speed")
        val rememberPlayback = booleanPreferencesKey("remember_playback")
        val defaultResize = intPreferencesKey("default_resize")
        val seekStepSec = intPreferencesKey("seek_step")
        val controlsTimeoutSec = intPreferencesKey("controls_timeout")
        val orientationMode = intPreferencesKey("orientation_mode")
        val bgPlayback = booleanPreferencesKey("bg_playback")
        val pip = booleanPreferencesKey("pip")
        val softwareDecoder = booleanPreferencesKey("software_decoder")
        val gestures = booleanPreferencesKey("gestures")
        val seekSens = floatPreferencesKey("seek_sens")
        val brightnessSens = floatPreferencesKey("brightness_sens")
        val volumeSens = floatPreferencesKey("volume_sens")
        val doubleTapSec = intPreferencesKey("double_tap_sec")
        val subSize = floatPreferencesKey("sub_size")
        val subColor = intPreferencesKey("sub_color")
        val subBottom = floatPreferencesKey("sub_bottom")
        val subBackground = floatPreferencesKey("sub_background")
        val subAutoLoad = booleanPreferencesKey("sub_auto_load")
    }

    val flow: Flow<AppSettings> = context.settingsStore.data.map { read(it) }

    /** Atomically transforms the stored settings: `update { copy(pip = false) }`. */
    suspend fun update(transform: AppSettings.() -> AppSettings) {
        context.settingsStore.edit { p ->
            val next = read(p).transform()
            write(p, next)
        }
    }

    suspend fun reset() {
        context.settingsStore.edit { it.clear() }
    }

    private fun read(p: Preferences): AppSettings {
        val d = AppSettings()
        return AppSettings(
            accent = p[K.accent] ?: d.accent,
            libraryGrid = p[K.libraryGrid] ?: d.libraryGrid,
            gridColumns = p[K.gridColumns] ?: d.gridColumns,
            showThumbnails = p[K.showThumbnails] ?: d.showThumbnails,
            sortField = p[K.sortField] ?: d.sortField,
            sortAscending = p[K.sortAscending] ?: d.sortAscending,
            rememberFolder = p[K.rememberFolder] ?: d.rememberFolder,
            lastFolder = p[K.lastFolder] ?: d.lastFolder,
            resume = p[K.resume] ?: d.resume,
            autoNext = p[K.autoNext] ?: d.autoNext,
            repeatMode = p[K.repeatMode] ?: d.repeatMode,
            defaultSpeed = p[K.defaultSpeed] ?: d.defaultSpeed,
            rememberPlayback = p[K.rememberPlayback] ?: d.rememberPlayback,
            defaultResize = p[K.defaultResize] ?: d.defaultResize,
            seekStepSec = p[K.seekStepSec] ?: d.seekStepSec,
            controlsTimeoutSec = p[K.controlsTimeoutSec] ?: d.controlsTimeoutSec,
            orientationMode = p[K.orientationMode] ?: d.orientationMode,
            bgPlayback = p[K.bgPlayback] ?: d.bgPlayback,
            pip = p[K.pip] ?: d.pip,
            softwareDecoder = p[K.softwareDecoder] ?: d.softwareDecoder,
            gestures = p[K.gestures] ?: d.gestures,
            seekSens = p[K.seekSens] ?: d.seekSens,
            brightnessSens = p[K.brightnessSens] ?: d.brightnessSens,
            volumeSens = p[K.volumeSens] ?: d.volumeSens,
            doubleTapSec = p[K.doubleTapSec] ?: d.doubleTapSec,
            subSize = p[K.subSize] ?: d.subSize,
            subColor = p[K.subColor] ?: d.subColor,
            subBottom = p[K.subBottom] ?: d.subBottom,
            subBackground = p[K.subBackground] ?: d.subBackground,
            subAutoLoad = p[K.subAutoLoad] ?: d.subAutoLoad,
        )
    }

    private fun write(p: MutablePreferences, s: AppSettings) {
        p[K.accent] = s.accent
        p[K.libraryGrid] = s.libraryGrid
        p[K.gridColumns] = s.gridColumns
        p[K.showThumbnails] = s.showThumbnails
        p[K.sortField] = s.sortField
        p[K.sortAscending] = s.sortAscending
        p[K.rememberFolder] = s.rememberFolder
        p[K.lastFolder] = s.lastFolder
        p[K.resume] = s.resume
        p[K.autoNext] = s.autoNext
        p[K.repeatMode] = s.repeatMode
        p[K.defaultSpeed] = s.defaultSpeed
        p[K.rememberPlayback] = s.rememberPlayback
        p[K.defaultResize] = s.defaultResize
        p[K.seekStepSec] = s.seekStepSec
        p[K.controlsTimeoutSec] = s.controlsTimeoutSec
        p[K.orientationMode] = s.orientationMode
        p[K.bgPlayback] = s.bgPlayback
        p[K.pip] = s.pip
        p[K.softwareDecoder] = s.softwareDecoder
        p[K.gestures] = s.gestures
        p[K.seekSens] = s.seekSens
        p[K.brightnessSens] = s.brightnessSens
        p[K.volumeSens] = s.volumeSens
        p[K.doubleTapSec] = s.doubleTapSec
        p[K.subSize] = s.subSize
        p[K.subColor] = s.subColor
        p[K.subBottom] = s.subBottom
        p[K.subBackground] = s.subBackground
        p[K.subAutoLoad] = s.subAutoLoad
    }
}
