package com.novaplayer.app.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp

val Accents: List<Pair<String, Color>> = listOf(
    "Lime" to Color(0xFFB8F34A),
    "Emerald" to Color(0xFF3DDC84),
    "Aqua" to Color(0xFF4FE3C1),
    "Amber" to Color(0xFFFFB547),
    "Sky" to Color(0xFF5CC8FF),
)

object NovaColors {
    val Card = Color(0xFF161616)
    val CardHigh = Color(0xFF1F1F1F)
    val Hairline = Color(0xFF262626)
    val TextPrimary = Color(0xFFF2F2F2)
    val TextSecondary = Color(0xFF9A9A9A)
}

val NovaTypography = Typography(
    headlineMedium = TextStyle(fontWeight = FontWeight.Bold, fontSize = 28.sp, letterSpacing = (-0.5).sp),
    titleLarge = TextStyle(fontWeight = FontWeight.Bold, fontSize = 22.sp, letterSpacing = (-0.2).sp),
    titleMedium = TextStyle(fontWeight = FontWeight.SemiBold, fontSize = 16.sp),
    bodyMedium = TextStyle(fontWeight = FontWeight.Normal, fontSize = 14.sp, lineHeight = 19.sp),
    bodySmall = TextStyle(fontWeight = FontWeight.Normal, fontSize = 12.sp, lineHeight = 16.sp),
    labelLarge = TextStyle(fontWeight = FontWeight.Medium, fontSize = 14.sp),
)

@Composable
fun NovaTheme(accentIndex: Int, content: @Composable () -> Unit) {
    val accent = Accents[accentIndex.coerceIn(0, Accents.lastIndex)].second
    val scheme = darkColorScheme(
        primary = accent,
        onPrimary = Color.Black,
        primaryContainer = accent.copy(alpha = 0.22f),
        onPrimaryContainer = accent,
        secondary = accent,
        onSecondary = Color.Black,
        secondaryContainer = accent.copy(alpha = 0.20f),
        onSecondaryContainer = accent,
        background = Color.Black,
        onBackground = NovaColors.TextPrimary,
        surface = Color.Black,
        onSurface = NovaColors.TextPrimary,
        surfaceVariant = NovaColors.Card,
        onSurfaceVariant = NovaColors.TextSecondary,
        surfaceContainerLowest = Color.Black,
        surfaceContainerLow = Color(0xFF0D0D0D),
        surfaceContainer = Color(0xFF111111),
        surfaceContainerHigh = NovaColors.Card,
        surfaceContainerHighest = NovaColors.CardHigh,
        outline = Color(0xFF3A3A3A),
        outlineVariant = NovaColors.Hairline,
        error = Color(0xFFFF6B6B),
    )
    MaterialTheme(colorScheme = scheme, typography = NovaTypography, content = content)
}
