package com.novaplayer.app.util

import android.Manifest
import android.content.Context
import android.os.Build

object Permissions {
    /** The one runtime permission needed to read the video library. */
    val media: String
        get() = if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_VIDEO
        else Manifest.permission.READ_EXTERNAL_STORAGE

    private fun prefs(ctx: Context) = ctx.getSharedPreferences("nova_flags", Context.MODE_PRIVATE)

    /** Remembers that the system dialog was shown, so we never nag with repeated prompts. */
    fun mediaAsked(ctx: Context): Boolean = prefs(ctx).getBoolean("media_asked", false)
    fun markMediaAsked(ctx: Context) = prefs(ctx).edit().putBoolean("media_asked", true).apply()
}
