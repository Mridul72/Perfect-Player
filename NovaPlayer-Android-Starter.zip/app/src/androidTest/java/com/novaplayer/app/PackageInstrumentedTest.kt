package com.novaplayer.app

import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import androidx.test.platform.app.InstrumentationRegistry
import androidx.test.ext.junit.runners.AndroidJUnit4
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith

/** Runs on a device/emulator: checks the manifest wiring that the 1DM "Open with" flow relies on. */
@RunWith(AndroidJUnit4::class)
class PackageInstrumentedTest {
    private val ctx = InstrumentationRegistry.getInstrumentation().targetContext

    @Test
    fun packageName() {
        assertEquals("com.novaplayer.app", ctx.packageName)
    }

    @Test
    fun resolvesVideoViewIntentForContentUri() {
        val intent = Intent(Intent.ACTION_VIEW).apply {
            setDataAndType(Uri.parse("content://example.provider/files/clip.mp4"), "video/mp4")
        }
        val matches = ctx.packageManager.queryIntentActivities(intent, PackageManager.MATCH_DEFAULT_ONLY)
        assertTrue(matches.any { it.activityInfo.packageName == ctx.packageName })
    }

    @Test
    fun resolvesMatroskaViewIntent() {
        val intent = Intent(Intent.ACTION_VIEW).apply {
            setDataAndType(Uri.parse("content://example.provider/files/clip.mkv"), "video/x-matroska")
        }
        val matches = ctx.packageManager.queryIntentActivities(intent, PackageManager.MATCH_DEFAULT_ONLY)
        assertTrue(matches.any { it.activityInfo.packageName == ctx.packageName })
    }

    @Test
    fun noInternetPermission() {
        val info = ctx.packageManager.getPackageInfo(ctx.packageName, PackageManager.GET_PERMISSIONS)
        val requested = info.requestedPermissions?.toList().orEmpty()
        assertFalse(requested.contains("android.permission.INTERNET"))
    }
}
