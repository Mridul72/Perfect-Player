package com.novaplayer.app

import com.novaplayer.app.util.DocIds
import com.novaplayer.app.util.Fmt
import com.novaplayer.app.util.MediaTypes
import com.novaplayer.app.util.NaturalOrder
import com.novaplayer.app.util.SubtitleParser
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class NaturalOrderTest {
    @Test
    fun numbersSortNumerically() {
        val sorted = listOf("ep10.mkv", "ep2.mkv", "ep1.mkv", "ep02.mkv").sortedWith(NaturalOrder)
        assertEquals(listOf("ep1.mkv", "ep02.mkv", "ep2.mkv", "ep10.mkv").size, sorted.size)
        assertEquals("ep1.mkv", sorted.first())
        assertEquals("ep10.mkv", sorted.last())
    }

    @Test
    fun caseInsensitive() {
        val sorted = listOf("b.mp4", "A.mp4", "c.mp4").sortedWith(NaturalOrder)
        assertEquals(listOf("A.mp4", "b.mp4", "c.mp4"), sorted)
    }

    @Test
    fun mixedTextAndNumbers() {
        val sorted = listOf("Show S01E10", "Show S01E9", "Show S02E1").sortedWith(NaturalOrder)
        assertEquals(listOf("Show S01E9", "Show S01E10", "Show S02E1"), sorted)
    }
}

class DocIdsTest {
    @Test
    fun parentOfNestedFile() {
        assertEquals("primary:Download/1DM", DocIds.parentOf("primary:Download/1DM/clip.mp4"))
    }

    @Test
    fun parentOfRootFile() {
        assertEquals("primary:", DocIds.parentOf("primary:clip.mp4"))
    }

    @Test
    fun coversChildAndSelfButNotSibling() {
        assertTrue(DocIds.covers("primary:Download/1DM", "primary:Download/1DM"))
        assertTrue(DocIds.covers("primary:Download/1DM", "primary:Download/1DM/Series"))
        assertFalse(DocIds.covers("primary:Download/1DM", "primary:Download/1DM2"))
        assertFalse(DocIds.covers("primary:Download/1DM", "primary:Movies"))
    }

    @Test
    fun forFolderMapsVolumes() {
        assertEquals("primary:Download/1DM", DocIds.forFolder("external_primary", "Download/1DM/"))
        assertEquals("1A2B-3C4D:Movies", DocIds.forFolder("1a2b-3c4d", "Movies/"))
    }
}

class MediaTypesTest {
    @Test
    fun recognisesByExtensionWhenMimeIsGeneric() {
        assertTrue(MediaTypes.isMedia("movie.MKV", "application/octet-stream"))
        assertFalse(MediaTypes.isMedia("notes.txt", "text/plain"))
        assertTrue(MediaTypes.isSubtitle("movie.srt"))
    }
}

class FmtTest {
    @Test
    fun durations() {
        assertEquals("0:05", Fmt.duration(5_000))
        assertEquals("1:01:01", Fmt.duration(3_661_000))
    }

    @Test
    fun sizes() {
        assertEquals("—", Fmt.size(0))
        assertEquals("1.0 MB", Fmt.size(1024L * 1024L))
    }

    @Test
    fun speeds() {
        assertEquals("1x", Fmt.speed(1f))
        assertEquals("1.5x", Fmt.speed(1.5f))
        assertEquals("0.25x", Fmt.speed(0.25f))
    }
}

class SubtitleParserTest {
    private val srt = """
        1
        00:00:01,000 --> 00:00:02,500
        Hello <i>world</i>

        2
        00:00:03,000 --> 00:00:04,000
        Second line
        continues
    """.trimIndent()

    @Test
    fun parsesSrt() {
        val cues = SubtitleParser.parse("a.srt", srt)
        assertEquals(2, cues.size)
        assertEquals(1000L, cues[0].startMs)
        assertEquals(2500L, cues[0].endMs)
        assertEquals("Hello world", cues[0].text)
        assertEquals("Second line\ncontinues", cues[1].text)
    }

    @Test
    fun parsesVtt() {
        val vtt = "WEBVTT\n\n00:01.000 --> 00:02.000\nHi there\n"
        val cues = SubtitleParser.parse("a.vtt", vtt)
        assertEquals(1, cues.size)
        assertEquals(1000L, cues[0].startMs)
        assertEquals("Hi there", cues[0].text)
    }

    @Test
    fun parsesAss() {
        val ass = """
            [Script Info]
            Title: x

            [Events]
            Format: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text
            Dialogue: 0,0:00:01.50,0:00:03.00,Default,,0,0,0,,{\an8}Top\Nline
        """.trimIndent()
        val cues = SubtitleParser.parse("a.ass", ass)
        assertEquals(1, cues.size)
        assertEquals(1500L, cues[0].startMs)
        assertEquals("Top\nline", cues[0].text)
    }

    @Test
    fun activeCueLookup() {
        val cues = SubtitleParser.parse("a.srt", srt)
        assertNull(SubtitleParser.active(cues, 500))
        assertEquals("Hello world", SubtitleParser.active(cues, 1500))
        assertNull(SubtitleParser.active(cues, 2800))
        assertEquals("Second line\ncontinues", SubtitleParser.active(cues, 3500))
    }

    @Test
    fun decodesLegacyEncoding() {
        val bytes = byteArrayOf(0x63, 0x61, 0x66, 0xE9.toByte()) // "café" in Windows-1252
        assertEquals("café", SubtitleParser.decode(bytes))
    }
}
