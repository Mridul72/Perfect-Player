package com.novaplayer
import org.junit.Assert.assertEquals
import org.junit.Test
class VideoItemTest {
    @Test fun filenameIsPreserved() {
        val item = VideoItem(android.net.Uri.parse("content://test/1"), "clip.mp4")
        assertEquals("clip.mp4", item.name)
    }
}
