package com.nova.player

import android.content.ContentUris
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.DocumentsContract
import android.provider.MediaStore
import android.provider.OpenableColumns
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material.icons.filled.SkipPrevious
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import java.util.Locale

class MainActivity : ComponentActivity() {
    private var incomingUri by mutableStateOf<Uri?>(null)
    private var incomingName by mutableStateOf("Choose a video")
    private var statusMessage by mutableStateOf("Open a video from 1DM, then choose its folder to enable Next/Previous.")
    private var queue by mutableStateOf<List<VideoItem>>(emptyList())
    private var queueIndex by mutableIntStateOf(0)
    private var player: ExoPlayer? = null

    private val folderPicker = registerForActivityResult(ActivityResultContracts.OpenDocumentTree()) { treeUri ->
        if (treeUri != null) {
            try {
                contentResolver.takePersistableUriPermission(
                    treeUri,
                    Intent.FLAG_GRANT_READ_URI_PERMISSION
                )
                getSharedPreferences("player", MODE_PRIVATE).edit()
                    .putString("last_tree_uri", treeUri.toString()).apply()
                loadSafFolder(treeUri)
            } catch (e: Exception) {
                statusMessage = "Folder permission failed: ${e.localizedMessage ?: "please choose the folder again"}"
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        handleIntent(intent)
        setContent {
            val dark = Color(0xFF090A0D)
            MaterialTheme(colorScheme = darkColorScheme(
                background = dark, surface = Color(0xFF14161B),
                primary = Color(0xFFB7F36B), onBackground = Color.White,
                onSurface = Color.White
            )) {
                NovaScreen(
                    title = queue.getOrNull(queueIndex)?.name ?: incomingName,
                    status = if (queue.size > 1) "${queue.size} videos in folder · ${queueIndex + 1} of ${queue.size}" else statusMessage,
                    onPrevious = { move(-1) },
                    onNext = { move(1) },
                    onPickFolder = { openFolderPicker() }
                ) { view -> player?.let { view.player = it } }
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleIntent(intent)
    }

    private fun handleIntent(intent: Intent?) {
        val uri = intent?.data ?: intent?.getParcelableExtra<Uri>(Intent.EXTRA_STREAM)
        if (uri == null) {
            incomingUri = null
            incomingName = "Choose a video"
            statusMessage = "Open a video from 1DM, then choose its folder to enable Next/Previous."
            return
        }
        incomingUri = uri
        incomingName = displayName(uri)
        queue = listOf(VideoItem(uri, incomingName))
        queueIndex = 0
        preparePlayer()

        if (uri.authority == "media") {
            loadMediaStoreFolder(uri)
        } else {
            statusMessage = "Video received from 1DM. Tap the folder icon and select the folder containing this video to enable Next/Previous."
            tryLoadLastSafFolder()
        }
    }

    private fun displayName(uri: Uri): String {
        contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
            if (c.moveToFirst()) return c.getString(0) ?: "Video"
        }
        return uri.lastPathSegment ?: "Video"
    }

    private fun tryLoadLastSafFolder() {
        val saved = getSharedPreferences("player", MODE_PRIVATE).getString("last_tree_uri", null) ?: return
        try {
            loadSafFolder(Uri.parse(saved))
        } catch (_: Exception) {
            statusMessage = "Saved folder is no longer accessible. Tap the folder icon and select it again."
        }
    }

    private fun loadMediaStoreFolder(uri: Uri) {
        val projection = arrayOf(MediaStore.Video.Media._ID, MediaStore.Video.Media.DISPLAY_NAME,
            MediaStore.Video.Media.RELATIVE_PATH)
        var selectedPath: String? = null
        contentResolver.query(uri, projection, null, null, null)?.use { c ->
            if (c.moveToFirst()) selectedPath = c.getString(2)
        }
        val path = selectedPath
        if (path == null) {
            statusMessage = "Couldn't identify this video's folder. Tap the folder icon to select it."
            return
        }
        val collection = MediaStore.Video.Media.getContentUri(MediaStore.VOLUME_EXTERNAL)
        val found = mutableListOf<VideoItem>()
        contentResolver.query(collection, projection,
            "${MediaStore.Video.Media.RELATIVE_PATH}=?", arrayOf(path),
            "${MediaStore.Video.Media.DISPLAY_NAME} COLLATE NOCASE ASC"
        )?.use { c ->
            while (c.moveToNext()) {
                found += VideoItem(ContentUris.withAppendedId(collection, c.getLong(0)), c.getString(1) ?: "Video")
            }
        }
        setQueue(found, uri)
    }

    private fun loadSafFolder(treeUri: Uri) {
        val current = incomingUri
        if (current == null) {
            statusMessage = "Folder permission saved. Open a video from 1DM."
            return
        }
        val childrenUri = DocumentsContract.buildChildDocumentsUriUsingTree(
            treeUri, DocumentsContract.getTreeDocumentId(treeUri)
        )
        val projection = arrayOf(
            DocumentsContract.Document.COLUMN_DOCUMENT_ID,
            DocumentsContract.Document.COLUMN_DISPLAY_NAME,
            DocumentsContract.Document.COLUMN_MIME_TYPE
        )
        val found = mutableListOf<VideoItem>()
        contentResolver.query(childrenUri, projection, null, null,
            "${DocumentsContract.Document.COLUMN_DISPLAY_NAME} COLLATE NOCASE ASC")?.use { c ->
            val idCol = c.getColumnIndexOrThrow(DocumentsContract.Document.COLUMN_DOCUMENT_ID)
            val nameCol = c.getColumnIndexOrThrow(DocumentsContract.Document.COLUMN_DISPLAY_NAME)
            val mimeCol = c.getColumnIndexOrThrow(DocumentsContract.Document.COLUMN_MIME_TYPE)
            while (c.moveToNext()) {
                val name = c.getString(nameCol) ?: continue
                val mime = c.getString(mimeCol) ?: ""
                if (mime.startsWith("video/") || name.substringAfterLast('.', "").lowercase(Locale.ROOT) in
                    setOf("mp4", "mkv", "webm", "avi", "mov", "m4v", "3gp", "ts", "mpeg", "mpg")) {
                    val docUri = DocumentsContract.buildDocumentUriUsingTree(treeUri, c.getString(idCol))
                    found += VideoItem(docUri, name)
                }
            }
        }
        setQueue(found, current)
    }

    private fun setQueue(items: List<VideoItem>, selectedUri: Uri) {
        val selectedName = incomingName.lowercase(Locale.ROOT)
        val sorted = items.distinctBy { it.uri }.sortedBy { it.name.lowercase(Locale.ROOT) }.toMutableList()
        val matching = sorted.indexOfFirst { it.name.equals(incomingName, ignoreCase = true) }
        if (matching < 0) {
            // The selected item may be a provider URI (such as 1DM), while siblings are SAF document URIs.
            sorted.add(VideoItem(selectedUri, incomingName))
            sorted.sortBy { it.name.lowercase(Locale.ROOT) }
        } else {
            // Prefer the original shared URI for the selected item; it is the URI 1DM granted to this app.
            sorted[matching] = VideoItem(selectedUri, incomingName)
        }
        queue = sorted
        queueIndex = queue.indexOfFirst { it.name.equals(selectedName, ignoreCase = true) }.coerceAtLeast(0)
        if (queue.isEmpty()) {
            queue = listOf(VideoItem(selectedUri, incomingName))
            queueIndex = 0
            statusMessage = "No videos found in that folder. Choose the exact folder containing this video."
        } else {
            statusMessage = "Folder playlist ready. Use Next/Previous to move between videos."
        }
        preparePlayer()
    }

    private fun preparePlayer() {
        val p = player ?: ExoPlayer.Builder(this).build().also { player = it }
        if (queue.isNotEmpty()) {
            p.setMediaItems(queue.map { MediaItem.fromUri(it.uri) }, queueIndex, 0L)
            p.prepare()
            p.playWhenReady = true
        }
    }

    private fun move(delta: Int) {
        val p = player ?: return
        if (queue.size <= 1) {
            statusMessage = "Playlist has only one video. Tap the folder icon and select the folder containing your videos."
            return
        }
        val next = (p.currentMediaItemIndex + delta).coerceIn(0, queue.lastIndex)
        queueIndex = next
        p.seekTo(next, 0L)
        p.play()
    }

    private fun openFolderPicker() {
        folderPicker.launch(null)
    }

    override fun onDestroy() {
        player?.release()
        player = null
        super.onDestroy()
    }
}

data class VideoItem(val uri: Uri, val name: String)

@Composable
fun NovaScreen(
    title: String, status: String,
    onPrevious: () -> Unit, onNext: () -> Unit, onPickFolder: () -> Unit,
    attachPlayer: (PlayerView) -> Unit
) {
    Column(Modifier.fillMaxSize().background(Color(0xFF090A0D)).padding(16.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("NOVA", style = MaterialTheme.typography.titleLarge, color = Color(0xFFB7F36B))
            Spacer(Modifier.weight(1f))
            IconButton(onClick = onPickFolder) { Icon(Icons.Default.Folder, "Choose video folder") }
        }
        Spacer(Modifier.height(18.dp))
        Text(title, style = MaterialTheme.typography.titleMedium, color = Color.White, maxLines = 2)
        Text(status, color = Color.LightGray, style = MaterialTheme.typography.bodySmall)
        Spacer(Modifier.height(16.dp))
        AndroidView(
            modifier = Modifier.fillMaxWidth().weight(1f),
            factory = { context -> PlayerView(context).apply { useController = true; attachPlayer(this) } },
            update = { attachPlayer(it) }
        )
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onPrevious) { Icon(Icons.Default.SkipPrevious, "Previous", tint = Color.White) }
            Text("FOLDER PLAYBACK", color = Color(0xFFB7F36B), style = MaterialTheme.typography.labelMedium)
            IconButton(onClick = onNext) { Icon(Icons.Default.SkipNext, "Next", tint = Color.White) }
        }
    }
}
