package com.nova.player

import android.Manifest
import android.content.ContentUris
import android.content.Intent
import android.content.pm.PackageManager
import android.database.Cursor
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.provider.OpenableColumns
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material.icons.filled.SkipPrevious
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView

class MainActivity : ComponentActivity() {
    private var incomingUri by mutableStateOf<Uri?>(null)
    private var incomingName by mutableStateOf("Nova Player")
    private var queue by mutableStateOf<List<VideoItem>>(emptyList())
    private var queueIndex by mutableIntStateOf(0)
    private var player: ExoPlayer? = null

    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted -> if (granted) loadQueue(incomingUri) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        handleIntent(intent)
        setContent {
            val dark = Color(0xFF090A0D)
            MaterialTheme(colorScheme = darkColorScheme(
                background = dark, surface = Color(0xFF14161B),
                primary = Color(0xFFB7F36B), onBackground = Color.White,
                onSurface = Color.White
            )) {
                NovaScreen(
                    title = incomingName,
                    count = queue.size,
                    onPrevious = { move(-1) },
                    onNext = { move(1) },
                    onPickFolder = { openFolderPicker() }
                ) { view ->
                    player?.let { view.player = it }
                }
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleIntent(intent)
    }

    private fun handleIntent(intent: Intent?) {
        incomingUri = intent?.data ?: intent?.getParcelableExtra(Intent.EXTRA_STREAM)
        incomingName = incomingUri?.let { displayName(it) } ?: "Choose a video"
        incomingUri?.let { uri ->
            val permission = if (Build.VERSION.SDK_INT >= 33)
                Manifest.permission.READ_MEDIA_VIDEO else Manifest.permission.READ_EXTERNAL_STORAGE
            if (ContextCompat.checkSelfPermission(this, permission) == PackageManager.PERMISSION_GRANTED) {
                loadQueue(uri)
            } else {
                permissionLauncher.launch(permission)
                // Keep the incoming URI playable even if broad library permission is denied.
                queue = listOf(VideoItem(uri, incomingName))
                queueIndex = 0
                preparePlayer()
            }
        }
    }

    private fun displayName(uri: Uri): String {
        contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use {
            if (it.moveToFirst()) return it.getString(0) ?: "Video"
        }
        return uri.lastPathSegment ?: "Video"
    }

    private fun loadQueue(uri: Uri?) {
        if (uri == null) return
        val items = mutableListOf<VideoItem>()
        val isMediaStore = uri.authority == "media"
        if (isMediaStore) {
            val projection = arrayOf(MediaStore.Video.Media._ID, MediaStore.Video.Media.DISPLAY_NAME,
                MediaStore.Video.Media.RELATIVE_PATH)
            var selectedPath: String? = null
            contentResolver.query(uri, projection, null, null, null)?.use { c ->
                if (c.moveToFirst()) selectedPath = c.getString(2)
            }
            if (selectedPath != null) {
                val collection = MediaStore.Video.Media.getContentUri(MediaStore.VOLUME_EXTERNAL)
                contentResolver.query(collection, projection,
                    "${MediaStore.Video.Media.RELATIVE_PATH}=?",
                    arrayOf(selectedPath), "${MediaStore.Video.Media.DISPLAY_NAME} COLLATE NOCASE ASC"
                )?.use { c ->
                    while (c.moveToNext()) {
                        val id = c.getLong(0)
                        val name = c.getString(1) ?: "Video"
                        items += VideoItem(ContentUris.withAppendedId(collection, id), name)
                    }
                }
            }
        }
        if (items.none { it.uri == uri }) items.add(uri.let { VideoItem(it, displayName(it)) })
        queue = items.distinctBy { it.uri }
        queueIndex = queue.indexOfFirst { it.uri == uri }.let { if (it < 0) 0 else it }
        preparePlayer()
    }

    private fun preparePlayer() {
        val p = player ?: ExoPlayer.Builder(this).build().also { player = it }
        p.setMediaItems(queue.map { MediaItem.fromUri(it.uri) }, queueIndex, 0L)
        p.prepare()
        p.playWhenReady = true
    }

    private fun move(delta: Int) {
        val p = player ?: return
        val next = (p.currentMediaItemIndex + delta).coerceIn(0, (queue.size - 1).coerceAtLeast(0))
        p.seekTo(next, 0L)
        p.play()
    }

    private fun openFolderPicker() {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT_TREE)
        startActivityForResult(i, 44)
    }

    override fun onDestroy() {
        player?.release()
        player = null
        super.onDestroy()
    }
}

data class VideoItem(val uri: Uri, val name: String)

@Composable
fun NovaScreen(
    title: String, count: Int,
    onPrevious: () -> Unit, onNext: () -> Unit, onPickFolder: () -> Unit,
    attachPlayer: (PlayerView) -> Unit
) {
    Column(Modifier.fillMaxSize().background(Color(0xFF090A0D)).padding(16.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("NOVA", style = MaterialTheme.typography.titleLarge, color = Color(0xFFB7F36B))
            Spacer(Modifier.weight(1f))
            IconButton(onClick = onPickFolder) { Icon(Icons.Default.Folder, "Browse folders") }
        }
        Spacer(Modifier.height(18.dp))
        Text(title, style = MaterialTheme.typography.titleMedium, color = Color.White, maxLines = 2)
        Text(if (count > 1) "$count videos in detected folder" else "Waiting for folder playlist",
            color = Color.LightGray, style = MaterialTheme.typography.bodySmall)
        Spacer(Modifier.height(16.dp))
        AndroidView(
            modifier = Modifier.fillMaxWidth().weight(1f),
            factory = { context -> PlayerView(context).apply { useController = true; attachPlayer(this) } },
            update = { attachPlayer(it) }
        )
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onPrevious) { Icon(Icons.Default.SkipPrevious, "Previous", tint = Color.White) }
            Text("FOLDER PLAYBACK", color = Color(0xFFB7F36B), style = MaterialTheme.typography.labelMedium)
            IconButton(onClick = onNext) { Icon(Icons.Default.SkipNext, "Next", tint = Color.White) }
        }
    }
}
