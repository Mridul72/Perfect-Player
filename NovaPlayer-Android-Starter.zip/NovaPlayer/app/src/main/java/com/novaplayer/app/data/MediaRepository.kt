package com.novaplayer.app.data

import android.Manifest
import android.content.ContentUris
import android.content.Context
import android.content.pm.PackageManager
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.os.storage.StorageManager
import android.provider.DocumentsContract
import android.provider.MediaStore
import androidx.core.content.ContextCompat
import com.novaplayer.app.util.MediaTypes
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.withContext
import java.io.File
import java.util.concurrent.ConcurrentHashMap

class MediaRepository(private val context: Context) {

    private val resolver get() = context.contentResolver
    private val metaCache = ConcurrentHashMap<String, VideoItem>()
    private val probeGate = Semaphore(3)
    private val scanMutex = Mutex()
    @Volatile private var filesystemIndex: List<VideoItem> = emptyList()
    @Volatile private var lastFilesystemScanMs: Long = 0L

    fun hasMediaPermission(): Boolean {
        val perm = if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_VIDEO
        else Manifest.permission.READ_EXTERNAL_STORAGE
        return ContextCompat.checkSelfPermission(context, perm) == PackageManager.PERMISSION_GRANTED
    }

    fun hasAllFilesAccess(): Boolean = when {
        Build.VERSION.SDK_INT < 29 -> true
        Build.VERSION.SDK_INT < 30 -> false
        else -> Environment.isExternalStorageManager()
    }

    fun hasLibraryAccess(): Boolean = hasMediaPermission() || hasAllFilesAccess()

    // ---- Library discovery ---------------------------------------------------------------

    /**
     * MediaStore is the privacy-friendly baseline. When the user explicitly grants Android's
     * special all-files access, also walk shared-storage roots ourselves. That is what lets the
     * library include hidden directories and files omitted by .nomedia.
     */
    suspend fun loadVideos(forceFilesystemRefresh: Boolean = true): List<VideoItem> = withContext(Dispatchers.IO) {
        val indexed = if (hasMediaPermission()) queryVideos() else emptyList()
        if (!hasAllFilesAccess()) return@withContext indexed
        val fs = if (forceFilesystemRefresh || lastFilesystemScanMs == 0L) scanFilesystem() else filesystemIndex
        mergeByCanonicalPath(indexed, fs)
    }

    /** Rebuilds the filesystem index from every accessible shared-storage volume. */
    suspend fun scanFilesystem(): List<VideoItem> = withContext(Dispatchers.IO) {
        scanMutex.withLock {
            if (!hasAllFilesAccess()) return@withLock emptyList()
            val roots = storageRoots()
        val found = ArrayList<VideoItem>()
        val visited = HashSet<String>()
        val stack = ArrayDeque<Pair<File, Int>>()
        val maxDirectories = 200_000
        roots.forEach { stack.add(it to 0) }
        val maxFiles = 100_000
        val maxDepth = 64
        while (stack.isNotEmpty() && found.size < maxFiles && visited.size < maxDirectories) {
            val (dir, depth) = stack.removeLast()
            val canonical = runCatching { dir.canonicalPath }.getOrNull() ?: continue
            if (!visited.add(canonical) || !dir.canRead()) continue
            val children = runCatching { dir.listFiles() }.getOrNull() ?: continue
            for (child in children) {
                if (found.size >= maxFiles) break
                if (child.isDirectory) {
                    // Android/data and Android/obb are protected by Android even with broad access.
                    if (depth < maxDepth && !isRestrictedAndroidDirectory(child)) stack.add(child to depth + 1)
                } else if (child.isFile && child.canRead() && MediaTypes.ext(child.name) in MediaTypes.VIDEO_EXT) {
                    val root = roots.firstOrNull { canonical.startsWith(it.absolutePath.trimEnd('/') + "/") || canonical == it.absolutePath }
                        ?: roots.firstOrNull { child.absolutePath.startsWith(it.absolutePath.trimEnd('/') + "/") }
                    val relative = if (root != null) child.parentFile?.absolutePath.orEmpty()
                        .removePrefix(root.absolutePath.trimEnd('/')).trim('/').let { if (it.isEmpty()) "" else "$it/" }
                    else child.parentFile?.name.orEmpty() + "/"
                    val modified = child.lastModified() / 1000L
                    found += VideoItem(
                        uri = Uri.fromFile(child).toString(), name = child.name,
                        sizeBytes = child.length(), dateModifiedSec = modified, dateAddedSec = modified,
                        folderPath = relative, volume = volumeId(root),
                        mimeType = mimeFor(child.name), isAudio = false,
                    )
                }
            }
        }
            filesystemIndex = found
            lastFilesystemScanMs = System.currentTimeMillis()
            found
        }
    }

    /** Same-directory files for a file:// handoff. */
    fun filesystemSiblings(fileUri: Uri): List<VideoItem> {
        if (!hasAllFilesAccess() || fileUri.scheme != "file") return emptyList()
        val file = File(fileUri.path ?: return emptyList())
        val parent = file.parentFile ?: return emptyList()
        val root = storageRoots().firstOrNull { parent.absolutePath.startsWith(it.absolutePath) }
        val rel = if (root != null) parent.absolutePath.removePrefix(root.absolutePath.trimEnd('/')).trim('/').let { if (it.isEmpty()) "" else "$it/" }
            else parent.name + "/"
        val children = runCatching { parent.listFiles() }.getOrNull() ?: return emptyList()
        return children.filter { it.isFile && MediaTypes.ext(it.name) in MediaTypes.VIDEO_EXT }
            .map { f -> VideoItem(Uri.fromFile(f).toString(), f.name, f.length(), dateModifiedSec = f.lastModified()/1000L,
                dateAddedSec = f.lastModified()/1000L, folderPath = rel, volume = volumeId(root), mimeType = mimeFor(f.name)) }
            .sortedWith(compareBy<VideoItem, String>(com.novaplayer.app.util.NaturalOrder) { it.name })
    }

    suspend fun ensureFilesystemIndex(forceRefresh: Boolean = true) {
        if (hasAllFilesAccess() && (forceRefresh || filesystemIndex.isEmpty() || System.currentTimeMillis() - lastFilesystemScanMs > 30_000L)) {
            scanFilesystem()
        }
    }

    /** Exact filename/size matches from the last library scan; can be used for content:// handoffs. */
    fun filesystemMatches(name: String, size: Long): List<VideoItem> = filesystemIndex.filter {
        it.name.equals(name, ignoreCase = true) && (size <= 0L || it.sizeBytes == size)
    }

    fun filesystemFolder(item: VideoItem): List<VideoItem> = filesystemIndex
        .filter { it.folderPath == item.folderPath && it.volume == item.volume }
        .sortedWith(compareBy<VideoItem, String>(com.novaplayer.app.util.NaturalOrder) { it.name })

    private fun storageRoots(): List<File> {
        val roots = linkedMapOf<String, File>()
        runCatching { Environment.getExternalStorageDirectory() }.getOrNull()?.let { roots[it.absolutePath] = it }
        if (Build.VERSION.SDK_INT >= 30) {
            runCatching {
                context.getSystemService(StorageManager::class.java).storageVolumes
                    .mapNotNull { it.directory }
                    .forEach { roots[it.absolutePath] = it }
            }
        }
        // A mounted secondary volume may not be exposed by StorageManager on every OEM build.
        context.getExternalFilesDirs(null).filterNotNull().forEach { appDir ->
            val marker = "/Android/data/${context.packageName}"
            val path = appDir.absolutePath
            val idx = path.indexOf(marker)
            if (idx > 0) {
                val root = File(path.substring(0, idx))
                roots[root.absolutePath] = root
            }
        }
        return roots.values.filter { it.exists() && it.isDirectory }.distinctBy { it.absolutePath }
    }

    private fun volumeId(root: File?): String = if (root == null) "storage" else {
        val primary = runCatching { Environment.getExternalStorageDirectory().absolutePath }.getOrNull()
        if (root.absolutePath == primary) "external_primary" else root.name
    }

    private fun isRestrictedAndroidDirectory(dir: File): Boolean {
        val parent = dir.parentFile ?: return false
        return parent.name.equals("Android", true) &&
            (dir.name.equals("data", true) || dir.name.equals("obb", true))
    }

    private fun mimeFor(name: String): String? = when (MediaTypes.ext(name)) {
        "mp4", "m4v" -> "video/mp4"
        "mkv" -> "video/x-matroska"
        "webm" -> "video/webm"
        "mov" -> "video/quicktime"
        "avi" -> "video/x-msvideo"
        "3gp", "3g2" -> "video/3gpp"
        "ts", "m2ts", "mts" -> "video/mp2t"
        "mpg", "mpeg" -> "video/mpeg"
        else -> "video/*"
    }

    private fun mergeByCanonicalPath(mediaStore: List<VideoItem>, filesystem: List<VideoItem>): List<VideoItem> {
        val map = LinkedHashMap<String, VideoItem>()
        mediaStore.forEach { item -> map[item.volume + "|" + item.name.lowercase() + "|" + item.sizeBytes + "|" + item.folderPath.lowercase()] = item }
        filesystem.forEach { item ->
            val key = item.volume + "|" + item.name.lowercase() + "|" + item.sizeBytes + "|" + item.folderPath.lowercase()
            map.putIfAbsent(key, item) // keep MediaStore content:// URIs when both sources see the same file
        }
        return map.values.sortedByDescending { it.dateModifiedSec }
    }

    fun queryVideos(
        selection: String? = null,
        args: Array<String>? = null,
        volume: String? = null,
        sort: String? = "${MediaStore.Video.Media.DATE_MODIFIED} DESC",
    ): List<VideoItem> {
        val out = ArrayList<VideoItem>()
        val q29 = Build.VERSION.SDK_INT >= 29
        val collection = if (volume != null && q29) MediaStore.Video.Media.getContentUri(volume)
        else MediaStore.Video.Media.EXTERNAL_CONTENT_URI

        val projection = ArrayList<String>().apply {
            add(MediaStore.Video.Media._ID)
            add(MediaStore.Video.Media.DISPLAY_NAME)
            add(MediaStore.Video.Media.SIZE)
            add(MediaStore.Video.Media.DURATION)
            add(MediaStore.Video.Media.WIDTH)
            add(MediaStore.Video.Media.HEIGHT)
            add(MediaStore.Video.Media.DATE_MODIFIED)
            add(MediaStore.Video.Media.DATE_ADDED)
            add(MediaStore.Video.Media.MIME_TYPE)
            if (q29) {
                add(MediaStore.MediaColumns.RELATIVE_PATH)
                add(MediaStore.MediaColumns.VOLUME_NAME)
            } else {
                add(LEGACY_DATA)
            }
        }.toTypedArray()

        try {
            resolver.query(collection, projection, selection, args, sort)?.use { c ->
                val iId = c.getColumnIndexOrThrow(MediaStore.Video.Media._ID)
                val iName = c.getColumnIndexOrThrow(MediaStore.Video.Media.DISPLAY_NAME)
                val iSize = c.getColumnIndexOrThrow(MediaStore.Video.Media.SIZE)
                val iDur = c.getColumnIndexOrThrow(MediaStore.Video.Media.DURATION)
                val iW = c.getColumnIndexOrThrow(MediaStore.Video.Media.WIDTH)
                val iH = c.getColumnIndexOrThrow(MediaStore.Video.Media.HEIGHT)
                val iMod = c.getColumnIndexOrThrow(MediaStore.Video.Media.DATE_MODIFIED)
                val iAdd = c.getColumnIndexOrThrow(MediaStore.Video.Media.DATE_ADDED)
                val iMime = c.getColumnIndexOrThrow(MediaStore.Video.Media.MIME_TYPE)
                val pathColumn = if (q29) MediaStore.MediaColumns.RELATIVE_PATH else LEGACY_DATA
                val iPath = c.getColumnIndexOrThrow(pathColumn)
                val iVol = if (q29) c.getColumnIndexOrThrow(MediaStore.MediaColumns.VOLUME_NAME) else -1

                while (c.moveToNext()) {
                    val name = c.getString(iName) ?: continue
                    val raw = c.getString(iPath) ?: ""
                    val folder = if (q29) raw else relativeFromData(raw)
                    val vol = if (iVol >= 0) c.getString(iVol) ?: "external_primary" else "external_primary"
                    out += VideoItem(
                        uri = ContentUris.withAppendedId(collection, c.getLong(iId)).toString(),
                        name = name,
                        sizeBytes = c.getLong(iSize),
                        durationMs = c.getLong(iDur),
                        width = c.getInt(iW),
                        height = c.getInt(iH),
                        dateModifiedSec = c.getLong(iMod),
                        dateAddedSec = c.getLong(iAdd),
                        folderPath = folder,
                        volume = vol,
                        mimeType = c.getString(iMime),
                    )
                }
            }
        } catch (_: SecurityException) {
            // permission revoked while running
        } catch (_: Exception) {
            // provider hiccup: return what we have
        }
        return out
    }

    fun findVideoById(id: Long): VideoItem? =
        queryVideos("${MediaStore.Video.Media._ID}=?", arrayOf(id.toString()), sort = null).firstOrNull()

    /** Candidates matching a display name (and size when known), newest first. */
    fun findVideosByName(name: String, size: Long): List<VideoItem> =
        if (size > 0) {
            queryVideos(
                "${MediaStore.Video.Media.DISPLAY_NAME}=? AND ${MediaStore.Video.Media.SIZE}=?",
                arrayOf(name, size.toString()),
            )
        } else {
            queryVideos("${MediaStore.Video.Media.DISPLAY_NAME}=?", arrayOf(name))
        }

    /** Videos stored directly in one folder (not its sub-folders). */
    fun videosInFolder(volume: String, folderPath: String): List<VideoItem> =
        if (Build.VERSION.SDK_INT >= 29) {
            queryVideos("${MediaStore.MediaColumns.RELATIVE_PATH}=?", arrayOf(folderPath), volume, null)
        } else {
            queryVideos("$LEGACY_DATA LIKE ?", arrayOf("%/$folderPath%"), null, null)
                .filter { it.folderPath == folderPath }
        }

    private fun relativeFromData(data: String): String {
        val parent = File(data).parent ?: return ""
        @Suppress("DEPRECATION")
        val roots = listOf(Environment.getExternalStorageDirectory().path, "/sdcard", "/storage/emulated/0")
        for (r in roots) {
            if (parent == r) return ""
            if (parent.startsWith("$r/")) return parent.removePrefix("$r/") + "/"
        }
        return parent.trimStart('/') + "/"
    }

    // ---- Storage Access Framework -------------------------------------------------------

    /** Lists the direct children of [parentDocId] inside a user-authorised tree. */
    fun listSaf(treeUri: Uri, parentDocId: String): List<SafEntry> {
        val out = ArrayList<SafEntry>()
        try {
            val children = DocumentsContract.buildChildDocumentsUriUsingTree(treeUri, parentDocId)
            val cols = arrayOf(
                DocumentsContract.Document.COLUMN_DOCUMENT_ID,
                DocumentsContract.Document.COLUMN_DISPLAY_NAME,
                DocumentsContract.Document.COLUMN_MIME_TYPE,
                DocumentsContract.Document.COLUMN_SIZE,
                DocumentsContract.Document.COLUMN_LAST_MODIFIED,
            )
            resolver.query(children, cols, null, null, null)?.use { c ->
                while (c.moveToNext()) {
                    val docId = c.getString(0) ?: continue
                    val name = c.getString(1) ?: continue
                    out += SafEntry(
                        docId = docId,
                        uri = DocumentsContract.buildDocumentUriUsingTree(treeUri, docId),
                        name = name,
                        mime = c.getString(2),
                        size = if (c.isNull(3)) -1L else c.getLong(3),
                        modifiedMs = if (c.isNull(4)) 0L else c.getLong(4),
                    )
                }
            }
        } catch (_: Exception) {
            // permission lost or provider unavailable
        }
        return out
    }

    fun countMedia(treeUri: Uri, docId: String): Int =
        listSaf(treeUri, docId).count { !it.isDir && MediaTypes.isMedia(it.name, it.mime) }

    fun treeName(treeUri: Uri): String {
        val docId = try {
            DocumentsContract.getTreeDocumentId(treeUri)
        } catch (_: Exception) {
            return "Folder"
        }
        val fallback = docId.substringAfterLast('/').substringAfterLast(':').ifEmpty { "Folder" }
        val queried: String? = try {
            val docUri = DocumentsContract.buildDocumentUriUsingTree(treeUri, docId)
            resolver.query(docUri, arrayOf(DocumentsContract.Document.COLUMN_DISPLAY_NAME), null, null, null)
                ?.use { if (it.moveToFirst()) it.getString(0) else null }
        } catch (_: Exception) {
            null
        }
        return if (queried.isNullOrEmpty()) fallback else queried
    }

    // ---- metadata for items that lack it (SAF listings) ---------------------------------

    suspend fun enrich(item: VideoItem): VideoItem {
        if (item.durationMs > 0 && (item.width > 0 || item.isAudio)) return item
        metaCache[item.uri]?.let { return it }
        return withContext(Dispatchers.IO) {
            probeGate.withPermit {
                val mmr = MediaMetadataRetriever()
                try {
                    mmr.setDataSource(context, Uri.parse(item.uri))
                    val dur = mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
                    val w = mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)?.toIntOrNull() ?: 0
                    val h = mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)?.toIntOrNull() ?: 0
                    item.copy(durationMs = dur, width = w, height = h).also { metaCache[item.uri] = it }
                } catch (_: Exception) {
                    item
                } finally {
                    runCatching { mmr.release() }
                }
            }
        }
    }
}

@Suppress("DEPRECATION")
private const val LEGACY_DATA = MediaStore.Video.Media.DATA

fun SafEntry.toVideoItem(folder: String, volume: String = "external_primary"): VideoItem = VideoItem(
    uri = uri.toString(),
    name = name,
    sizeBytes = size,
    dateModifiedSec = modifiedMs / 1000,
    folderPath = folder,
    volume = volume,
    mimeType = mime,
    isAudio = MediaTypes.isAudioName(name) || mime?.startsWith("audio/") == true,
)
