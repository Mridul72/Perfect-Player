package com.novaplayer.app.player

import android.app.PictureInPictureParams
import android.content.Intent
import android.content.pm.ActivityInfo
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.media.AudioManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.Settings
import android.util.Rational
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.runtime.getValue
import androidx.core.app.ActivityCompat
import androidx.core.content.IntentCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import com.novaplayer.app.nova
import com.novaplayer.app.playback.PlaybackRequests
import com.novaplayer.app.playback.PlaybackService
import com.novaplayer.app.ui.theme.NovaTheme
import com.novaplayer.app.util.Permissions
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch
import kotlin.math.roundToInt

/** Bridge from the Compose player UI to things only an Activity can do. */
interface PlayerHost {
    fun close()
    fun rotate()
    fun enterPip()
    fun pickSubtitle()
    fun pickFolder()
    fun requestMediaAccess()
    fun hasMediaAccess(): Boolean
    var brightness: Float
    var volume: Float
}

class PlayerActivity : ComponentActivity(), PlayerHost {

    private val vm: PlayerViewModel by viewModels()
    private var manualOrientation: Int? = null
    private var hasResumedOnce = false

    private val folderPicker =
        registerForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri: Uri? ->
            if (uri != null) vm.onFolderPicked(uri)
        }
    private val subtitlePicker =
        registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
            if (uri != null) vm.loadExternalSubtitle(uri)
        }
    private val mediaPermission =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            if (granted) requestAllFilesAccess() else vm.retryResolve()
        }

    private val audioManager by lazy { getSystemService(AudioManager::class.java) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        configureWindow()

        if (savedInstanceState == null || !vm.hasMedia()) handleIntent(intent)
        // A plain start is allowed while we are in the foreground; Media3 promotes the service
        // to foreground-with-notification when playback is actually running.
        runCatching { startService(Intent(this, PlaybackService::class.java)) }

        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                vm.ui.map { it.videoWidth to it.videoHeight }.distinctUntilChanged().collect { applyOrientation() }
            }
        }
        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                vm.settings.map { it.orientationMode }.distinctUntilChanged().collect {
                    manualOrientation = null
                    applyOrientation()
                }
            }
        }

        setContent {
            val s by vm.settings.collectAsStateWithLifecycle()
            NovaTheme(accentIndex = s.accent) {
                PlayerScreen(vm = vm, host = this)
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleIntent(intent)
    }

    private fun handleIntent(intent: Intent) {
        val uri = extractUri(intent)
        if (uri != null) {
            vm.openExternal(uri, intent.type)
            return
        }
        val pending = PlaybackRequests.take()
        if (pending != null) {
            vm.openQueue(pending.items, pending.startIndex)
            return
        }
        // Launched from the playback notification: just show what is already playing.
        if (!vm.hasMedia()) finish()
    }

    /** Handles Intent data, EXTRA_STREAM and ClipData (URI permission flags ride along with them). */
    private fun extractUri(i: Intent): Uri? {
        i.data?.let { return it }
        IntentCompat.getParcelableExtra(i, Intent.EXTRA_STREAM, Uri::class.java)?.let { return it }
        val clip = i.clipData
        if (clip != null && clip.itemCount > 0) return clip.getItemAt(0).uri
        return null
    }

    // ---- window / orientation / system bars -------------------------------------------------

    private fun configureWindow() {
        WindowCompat.setDecorFitsSystemWindows(window, false)
        if (Build.VERSION.SDK_INT >= 28) {
            val lp = window.attributes
            lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            window.attributes = lp
        }
        hideSystemBars()
    }

    private fun hideSystemBars() {
        WindowInsetsControllerCompat(window, window.decorView).apply {
            systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            hide(WindowInsetsCompat.Type.systemBars())
        }
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) hideSystemBars()
    }

    private fun applyOrientation() {
        val ui = vm.ui.value
        requestedOrientation = manualOrientation ?: when (vm.settings.value.orientationMode) {
            1 -> ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
            2 -> ActivityInfo.SCREEN_ORIENTATION_SENSOR_PORTRAIT
            3 -> ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
            else -> if (ui.videoHeight > ui.videoWidth && ui.videoWidth > 0)
                ActivityInfo.SCREEN_ORIENTATION_SENSOR_PORTRAIT
            else ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
        }
    }

    override fun rotate() {
        val landscape = resources.configuration.orientation == Configuration.ORIENTATION_LANDSCAPE
        manualOrientation = if (landscape) ActivityInfo.SCREEN_ORIENTATION_SENSOR_PORTRAIT
        else ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
        applyOrientation()
    }

    // ---- lifecycle ----------------------------------------------------------------------------

    override fun onResume() {
        super.onResume()
        if (hasResumedOnce && nova.media.hasAllFilesAccess() && vm.ui.value.folderStatus != FolderStatus.FOUND) {
            vm.retryResolve()
        }
        hasResumedOnce = true
    }

    override fun onStart() {
        super.onStart()
        vm.setBackgrounded(false)
    }

    override fun onStop() {
        super.onStop()
        if (!isChangingConfigurations) {
            vm.saveNow()
            if (vm.settings.value.bgPlayback) vm.setBackgrounded(true) else vm.pause()
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        if (isFinishing) {
            vm.saveNow()
            val keepAlive = vm.settings.value.bgPlayback && vm.ui.value.isPlaying
            if (!keepAlive) {
                vm.stopPlayback()
                stopService(Intent(this, PlaybackService::class.java))
            }
        }
    }

    // ---- picture-in-picture --------------------------------------------------------------------

    override fun onUserLeaveHint() {
        super.onUserLeaveHint()
        if (vm.settings.value.pip && vm.ui.value.isPlaying && !isFinishing) enterPip()
    }

    override fun enterPip() {
        if (Build.VERSION.SDK_INT < 26 ||
            !packageManager.hasSystemFeature(PackageManager.FEATURE_PICTURE_IN_PICTURE)
        ) return
        val ui = vm.ui.value
        val w = if (ui.videoWidth > 0) ui.videoWidth else 16
        val h = if (ui.videoHeight > 0) ui.videoHeight else 9
        // PiP only accepts aspect ratios between 1:2.39 and 2.39:1.
        val ratio = (w.toFloat() / h).coerceIn(0.43f, 2.39f)
        val params = PictureInPictureParams.Builder()
            .setAspectRatio(Rational((ratio * 1000).roundToInt(), 1000))
            .build()
        runCatching { enterPictureInPictureMode(params) }
    }

    @Suppress("DEPRECATION", "OVERRIDE_DEPRECATION")
    override fun onPictureInPictureModeChanged(isInPictureInPictureMode: Boolean, newConfig: Configuration) {
        super.onPictureInPictureModeChanged(isInPictureInPictureMode, newConfig)
        vm.setPip(isInPictureInPictureMode)
    }

    // ---- PlayerHost -----------------------------------------------------------------------------

    override fun close() {
        finish()
    }

    override fun pickSubtitle() {
        subtitlePicker.launch(arrayOf("*/*"))
    }

    override fun pickFolder() {
        folderPicker.launch(vm.hintUri())
    }

    override fun hasMediaAccess(): Boolean = Build.VERSION.SDK_INT < 30 || nova.media.hasAllFilesAccess()

    override fun requestMediaAccess() {
        if (nova.media.hasAllFilesAccess()) {
            vm.retryResolve()
            return
        }
        if (Build.VERSION.SDK_INT >= 30 && nova.media.hasMediaPermission() && !Environment.isExternalStorageManager()) {
            requestAllFilesAccess()
            return
        }
        val perm = Permissions.media
        val canAsk = !Permissions.mediaAsked(this) || ActivityCompat.shouldShowRequestPermissionRationale(this, perm)
        if (canAsk) {
            Permissions.markMediaAsked(this)
            mediaPermission.launch(perm)
        } else {
            // The system will no longer show its dialog; send the user to the app's settings page.
            startActivity(
                Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName"))
            )
        }
    }

    private fun requestAllFilesAccess() {
        if (Build.VERSION.SDK_INT < 30 || Environment.isExternalStorageManager()) {
            vm.retryResolve()
            return
        }
        val intent = Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, Uri.parse("package:$packageName"))
        runCatching { startActivity(intent) }.onFailure {
            startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName")))
        }
    }

    override var brightness: Float
        get() = window.attributes.screenBrightness.let { if (it < 0f) 0.5f else it }
        set(v) {
            val lp = window.attributes
            lp.screenBrightness = v.coerceIn(0.01f, 1f)
            window.attributes = lp
        }

    override var volume: Float
        get() = audioManager.getStreamVolume(AudioManager.STREAM_MUSIC).toFloat() /
            audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC).coerceAtLeast(1)
        set(v) {
            val max = audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
            audioManager.setStreamVolume(AudioManager.STREAM_MUSIC, (v.coerceIn(0f, 1f) * max).roundToInt(), 0)
        }
}
