package com.novaplayer

import android.content.Intent
import android.content.pm.ActivityInfo
import android.net.Uri
import android.os.Bundle
import android.os.Build
import android.os.Environment
import android.provider.Settings
import android.view.View
import android.view.WindowManager
import android.provider.OpenableColumns
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.documentfile.provider.DocumentFile
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

private val Bg = Color(0xFF050607)
private val Panel = Color(0xFF15191B)
private val Lime = Color(0xFFB8F36B)

class MainActivity : ComponentActivity() {
    var resumeCounter by mutableIntStateOf(0)
        private set
    private var incomingUri: Uri? = null
    private val folderPicker = registerForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
        if (uri != null) {
            try {
                contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
                getSharedPreferences("nova", MODE_PRIVATE).edit().putString("tree", uri.toString()).apply()
                setContent { NovaApp(incomingUri, uri) }
            } catch (_: Exception) { setContent { NovaApp(incomingUri, savedTree()) } }
        }
    }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = android.graphics.Color.rgb(5,6,7)
        window.navigationBarColor = android.graphics.Color.rgb(5,6,7)
        incomingUri = extractUri(intent)
        setContent { NovaApp(incomingUri, savedTree()) }
    }
    override fun onResume() { super.onResume(); resumeCounter++ }
    override fun onNewIntent(intent: Intent) { super.onNewIntent(intent); setIntent(intent); incomingUri = extractUri(intent) }
    private fun extractUri(i: Intent?): Uri? = i?.data ?: i?.clipData?.getItemAt(0)?.uri ?: (i?.getParcelableExtra(Intent.EXTRA_STREAM) as? Uri)
    private fun savedTree(): Uri? = getSharedPreferences("nova", MODE_PRIVATE).getString("tree", null)?.let(Uri::parse)
    fun chooseFolder() { folderPicker.launch(savedTree()) }
    fun requestFullStorageAccess() {
        if (Build.VERSION.SDK_INT >= 30 && !Environment.isExternalStorageManager()) {
            try {
                startActivity(Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION,
                    Uri.parse("package:$packageName")))
            } catch (_: Exception) {
                startActivity(Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION))
            }
        }
    }
    fun applyImmersiveMode(enabled: Boolean) {
        if (enabled) {
            requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
            window.decorView.systemUiVisibility = (View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION)
            window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        } else {
            requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
            window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_VISIBLE
            window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        }
    }
    override fun onDestroy() { applyImmersiveMode(false); super.onDestroy() }
}

@Composable
private fun NovaApp(incoming: Uri?, initialTree: Uri?) {
    val context = LocalContext.current
    val activity = context as? MainActivity
    val repo = remember { MediaRepository(context) }
    val prefs = remember { context.getSharedPreferences("nova_settings", 0) }
    var tab by remember { mutableStateOf(if (incoming != null) "Player" else "Home") }
    var videos by remember { mutableStateOf<List<VideoItem>>(emptyList()) }
    var tree by remember { mutableStateOf(initialTree) }
    var selected by remember { mutableStateOf<VideoItem?>(null) }
    var queue by remember { mutableStateOf<List<VideoItem>>(emptyList()) }
    var query by remember { mutableStateOf("") }
    var notice by remember { mutableStateOf<String?>(null) }
    val scope = rememberCoroutineScope()
    val resumeCounter = activity?.resumeCounter ?: 0
    val player = remember { ExoPlayer.Builder(context).build() }
    DisposableEffect(Unit) { onDispose { player.release(); activity?.applyImmersiveMode(false) } }

    LaunchedEffect(resumeCounter, incoming) {
        // Ask once for Android's special all-files permission. This is the only way for a
        // sideloaded player to discover non-indexed/hidden folders without a SAF folder grant.
        if (Build.VERSION.SDK_INT >= 30 && !repo.hasFullStorageAccess() && !prefs.getBoolean("asked_all_files", false)) {
            prefs.edit().putBoolean("asked_all_files", true).apply()
            activity?.requestFullStorageAccess()
        }
        videos = repo.scanLibrary()
        if (incoming != null) {
            val name = repo.displayName(incoming) ?: incoming.lastPathSegment?.substringAfterLast('/') ?: "Opened video"
            selected = VideoItem(incoming, name)
            player.setMediaItem(MediaItem.fromUri(incoming)); player.prepare(); player.playWhenReady = true
            val list = repo.siblingCandidates(incoming)
            if (list.isNotEmpty()) {
                val match = list.firstOrNull { it.name.equals(name, true) } ?: list.first()
                queue = list
                val index = list.indexOf(match).coerceAtLeast(0)
                player.setMediaItems(list.map { MediaItem.fromUri(it.uri) }, index, 0L)
                player.prepare(); player.playWhenReady = true
                selected = match; notice = null
            } else {
                queue = emptyList()
                notice = "Playing shared video. Android did not expose its sibling folder; enable full storage access to build the folder playlist."
            }
        }
    }
    LaunchedEffect(tree) {
        if (tree != null) {
            val list = repo.scanTree(tree!!)
            videos = (videos + list).distinctBy { it.uri }
        }
    }

    MaterialTheme(colorScheme = darkColorScheme(background = Bg, surface = Panel, primary = Lime, onBackground = Color.White, onSurface = Color.White)) {
        Surface(Modifier.fillMaxSize(), color = Bg) {
            if (tab == "Player" && selected != null) {
                PlayerScreen(player, selected!!.name, notice, onFolder = { activity?.chooseFolder() },
                    onBack = { activity?.applyImmersiveMode(false); tab = "Home" },
                    onSelect = { item -> val list = queue.ifEmpty { videos }; queue = list; selected = item; val idx = list.indexOfFirst { it.uri == item.uri }.coerceAtLeast(0); player.setMediaItems(list.map { MediaItem.fromUri(it.uri) }, idx, 0L); player.prepare(); player.play(); notice = null },
                    onNext = { if (player.hasNextMediaItem()) player.seekToNextMediaItem() },
                    onPrevious = { if (player.hasPreviousMediaItem()) player.seekToPreviousMediaItem() },
                    onToggleFullscreen = { activity?.applyImmersiveMode(true) }, onExitFullscreen = { activity?.applyImmersiveMode(false) },
                    queue = queue, onDismissNotice = { notice = null })
            } else {
                Column(Modifier.fillMaxSize().padding(horizontal = 18.dp)) {
                    Spacer(Modifier.height(28.dp))
                    Text("NOVAPLAYER", color = Lime, fontSize = 28.sp, fontWeight = FontWeight.Black)
                    Text("Your videos. Your privacy.", color = Color.LightGray, fontSize = 13.sp)
                    Spacer(Modifier.height(20.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        listOf("Home", "Folders", "Videos", "Settings").forEach { label ->
                            FilterChip(selected = tab == label, onClick = { tab = label }, label = { Text(label) })
                        }
                    }
                    Spacer(Modifier.height(16.dp))
                    when (tab) {
                        "Settings" -> SettingsScreen(prefs, onFolder = { activity?.chooseFolder() }, onFullAccess = { activity?.requestFullStorageAccess() })
                        "Folders" -> FolderScreen(tree, onChoose = { activity?.chooseFolder() }, onOpen = { uri ->
                            tree = uri; scope.launch { videos = repo.scanTree(uri); notice = "${videos.size} videos found" }
                        })
                        else -> {
                            OutlinedTextField(query, { query = it }, Modifier.fillMaxWidth(), placeholder = { Text("Search videos") }, leadingIcon = { Icon(Icons.Default.Search, null) }, singleLine = true)
                            Spacer(Modifier.height(12.dp))
                            Text(if (tab == "Home") "Recent videos" else "All videos", fontSize = 21.sp, fontWeight = FontWeight.Bold)
                            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                items(videos.filter { it.name.contains(query, true) }) { item ->
                                    VideoRow(item) {
                                        selected = item; queue = videos; tab = "Player"
                                        player.setMediaItems(videos.map { MediaItem.fromUri(it.uri) }, videos.indexOf(item), 0L); player.prepare(); player.play()
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

private suspend fun scanAndMatch(repo: MediaRepository, tree: Uri, incoming: Uri, name: String, done: (List<VideoItem>, VideoItem?) -> Unit) {
    val list = repo.scanTree(tree)
    val match = list.firstOrNull { it.uri == incoming } ?: list.firstOrNull { it.name.equals(name, true) }
    done(list, match)
}

@Composable
private fun VideoRow(item: VideoItem, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(14.dp)).clickable(onClick = onClick).padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
        Icon(Icons.Default.PlayCircle, null, tint = Lime, modifier = Modifier.size(38.dp)); Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) { Text(item.name, maxLines = 2, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.SemiBold); Text(if (item.size > 0) "%.1f MB".format(item.size / 1048576f) else "Video", color = Color.Gray, fontSize = 12.sp) }
        Icon(Icons.Default.PlayArrow, null, tint = Color.Gray)
    }
}

@OptIn(UnstableApi::class)
@Composable
private fun PlayerScreen(player: ExoPlayer, title: String, message: String?, onFolder: () -> Unit, onBack: () -> Unit,
                         onSelect: (VideoItem) -> Unit, onNext: () -> Unit, onPrevious: () -> Unit,
                         onToggleFullscreen: () -> Unit, onExitFullscreen: () -> Unit, queue: List<VideoItem>, onDismissNotice: () -> Unit) {
    var controls by remember { mutableStateOf(true) }
    var fullscreen by remember { mutableStateOf(false) }
    var pos by remember { mutableLongStateOf(0L) }
    var dur by remember { mutableLongStateOf(0L) }
    var speed by remember { mutableFloatStateOf(1f) }
    LaunchedEffect(player) { while (true) { pos = player.currentPosition.coerceAtLeast(0); dur = player.duration.coerceAtLeast(0); delay(400) } }
    BackHandler(fullscreen) { fullscreen = false; onExitFullscreen() }
    Column(Modifier.fillMaxSize().background(Bg).padding(if (fullscreen) 0.dp else 14.dp), verticalArrangement = Arrangement.SpaceBetween) {
        if (!fullscreen && controls) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, null) }
                Text("NOVAPLAYER", color = Lime, fontWeight = FontWeight.Black, fontSize = 20.sp)
                Spacer(Modifier.weight(1f)); IconButton(onClick = onFolder) { Icon(Icons.Default.FolderOpen, "Choose folder", tint = Lime) }
                IconButton(onClick = { fullscreen = true; onToggleFullscreen() }) { Icon(Icons.Default.Fullscreen, "Fullscreen", tint = Lime) }
            }
            Text(title, fontSize = 16.sp, fontWeight = FontWeight.Bold, maxLines = 2, overflow = TextOverflow.Ellipsis)
        }
        Box(Modifier.fillMaxWidth().weight(1f).pointerInput(fullscreen) {
            detectTapGestures(onTap = { controls = !controls }, onDoubleTap = { offset ->
                if (offset.x < size.width / 2f) player.seekTo((player.currentPosition - 10_000).coerceAtLeast(0))
                else player.seekTo(player.currentPosition + 10_000)
                controls = true
            })
        }, contentAlignment = Alignment.Center) {
            AndroidView(factory = { PlayerView(it).apply { this.player = player; useController = false; resizeMode = AspectRatioFrameLayout.RESIZE_MODE_FIT } }, update = { it.player = player }, modifier = Modifier.fillMaxSize())
            if (controls) {
                Row(Modifier.align(Alignment.Center), horizontalArrangement = Arrangement.spacedBy(30.dp), verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = { player.seekTo((player.currentPosition - 10_000).coerceAtLeast(0)) }) { Icon(Icons.Default.Replay10, "Back 10", tint = Color.White, modifier = Modifier.size(42.dp)) }
                    IconButton(onClick = { if (player.isPlaying) player.pause() else player.play() }) { Icon(if (player.isPlaying) Icons.Default.PauseCircleFilled else Icons.Default.PlayCircleFilled, "Play/Pause", tint = Lime, modifier = Modifier.size(64.dp)) }
                    IconButton(onClick = { player.seekTo(player.currentPosition + 10_000) }) { Icon(Icons.Default.Forward10, "Forward 10", tint = Color.White, modifier = Modifier.size(42.dp)) }
                }
            }
        }
        if (controls) {
            if (!fullscreen && message != null) Card(colors = CardDefaults.cardColors(containerColor = Panel), modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(10.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) { Text(message, Modifier.weight(1f), color = Color.LightGray, fontSize = 12.sp); TextButton(onClick = onDismissNotice) { Text("Hide") } }
                    if (queue.isNotEmpty()) {
                        Text("Choose the matching video", color = Lime, fontWeight = FontWeight.SemiBold)
                        LazyColumn(Modifier.heightIn(max = 150.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            items(queue) { item -> Text(item.name, Modifier.fillMaxWidth().clickable { onSelect(item) }.padding(8.dp), color = Color.White, maxLines = 1, overflow = TextOverflow.Ellipsis) }
                        }
                    }
                }
            }
            Slider(value = if (dur > 0) pos.toFloat().coerceIn(0f, dur.toFloat()) else 0f, onValueChange = { player.seekTo(it.toLong()) }, valueRange = 0f..dur.coerceAtLeast(1L).toFloat())
            Row(Modifier.fillMaxWidth()) { Text(clock(pos), color = Color.Gray, fontSize = 12.sp); Spacer(Modifier.weight(1f)); Text(clock(dur), color = Color.Gray, fontSize = 12.sp) }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly, verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onPrevious) { Icon(Icons.Default.SkipPrevious, "Previous", tint = Color.White, modifier = Modifier.size(32.dp)) }
                IconButton(onClick = { player.seekTo((player.currentPosition - 10_000).coerceAtLeast(0)) }) { Icon(Icons.Default.Replay10, "Back 10", tint = Color.White) }
                IconButton(onClick = { if (player.isPlaying) player.pause() else player.play() }) { Icon(if (player.isPlaying) Icons.Default.PauseCircleFilled else Icons.Default.PlayCircleFilled, "Play", tint = Lime, modifier = Modifier.size(50.dp)) }
                IconButton(onClick = { player.seekTo(player.currentPosition + 10_000) }) { Icon(Icons.Default.Forward10, "Forward 10", tint = Color.White) }
                IconButton(onClick = onNext) { Icon(Icons.Default.SkipNext, "Next", tint = Color.White, modifier = Modifier.size(32.dp)) }
                var menu by remember { mutableStateOf(false) }
                Box { TextButton(onClick = { menu = true }) { Text("${speed}x", color = Lime) }; DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) { listOf(0.5f, 0.75f, 1f, 1.25f, 1.5f, 2f).forEach { v -> DropdownMenuItem(text = { Text("${v}x") }, onClick = { speed = v; player.setPlaybackSpeed(v); menu = false }) } } }
            }
            if (!fullscreen && queue.isNotEmpty()) Text("${queue.size} videos in folder playlist", color = Color.Gray, fontSize = 11.sp)
            if (fullscreen) Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) { TextButton(onClick = { fullscreen = false; onExitFullscreen() }) { Text("Exit fullscreen", color = Lime) } }
        }
    }
}
private fun clock(ms: Long): String { val s = (ms.coerceAtLeast(0) / 1000).toInt(); return "%d:%02d".format(s / 60, s % 60) }

@Composable
private fun FolderScreen(tree: Uri?, onChoose: () -> Unit, onOpen: (Uri) -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Folders", fontSize = 22.sp, fontWeight = FontWeight.Bold)
        Text("Full library scanning is preferred. Folder access is an optional fallback for locations Android does not expose.", color = Color.LightGray)
        Button(onClick = onChoose) { Icon(Icons.Default.CreateNewFolder, null); Spacer(Modifier.width(8.dp)); Text("Choose folder") }
        if (tree != null) Card(colors = CardDefaults.cardColors(containerColor = Panel), onClick = { onOpen(tree) }) {
            Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) { Icon(Icons.Default.Folder, null, tint = Lime); Spacer(Modifier.width(12.dp)); Column { Text(DocumentFile.fromTreeUri(LocalContext.current, tree)?.name ?: "Authorised folder"); Text("Tap to scan this folder and subfolders", color = Color.Gray, fontSize = 12.sp) } }
        }
    }
}

@Composable
private fun SettingsScreen(prefs: android.content.SharedPreferences, onFolder: () -> Unit, onFullAccess: () -> Unit) {
    var keepScreen by remember { mutableStateOf(prefs.getBoolean("keep_screen", true)) }
    var autoplay by remember { mutableStateOf(prefs.getBoolean("autoplay", true)) }
    var resume by remember { mutableStateOf(prefs.getBoolean("resume", true)) }
    var section by remember { mutableStateOf("Playback") }
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Settings", fontSize = 22.sp, fontWeight = FontWeight.Bold)
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) { listOf("Playback", "Gestures", "Subtitles", "Library", "Privacy").forEach { FilterChip(selected = section == it, onClick = { section = it }, label = { Text(it) }) } }
        when (section) {
            "Playback" -> {
                SettingToggle("Keep screen on during playback", keepScreen) { keepScreen = it; prefs.edit().putBoolean("keep_screen", it).apply() }
                SettingToggle("Autoplay next video", autoplay) { autoplay = it; prefs.edit().putBoolean("autoplay", it).apply() }
                SettingToggle("Resume from last position", resume) { resume = it; prefs.edit().putBoolean("resume", it).apply() }
                Text("Playback speed can also be changed from the player controls.", color = Color.Gray)
            }
            "Gestures" -> Text("Player supports tap to show/hide controls and 10-second skip buttons. Full swipe brightness/volume gestures are not implemented in this build.", color = Color.LightGray)
            "Subtitles" -> Text("Embedded subtitles are handled by Media3 when supported by the media format. External subtitle selection and subtitle timing controls are not implemented yet.", color = Color.LightGray)
            "Library" -> { Text("For automatic discovery of hidden folders and files excluded from MediaStore, grant Android’s special All files access once. Android still blocks protected app-private directories.", color = Color.LightGray); OutlinedButton(onClick = onFullAccess) { Icon(Icons.Default.FolderOpen, null); Spacer(Modifier.width(8.dp)); Text("Enable automatic full library scan") }; OutlinedButton(onClick = onFolder) { Icon(Icons.Default.FolderOpen, null); Spacer(Modifier.width(8.dp)); Text("Manage authorised folders") } }
            else -> Text("NovaPlayer runs locally. This project adds no analytics or advertising SDKs.", color = Color.LightGray)
        }
    }
}
@Composable private fun SettingToggle(label: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(12.dp)).padding(14.dp), verticalAlignment = Alignment.CenterVertically) { Text(label, Modifier.weight(1f)); Switch(checked, onChange) }
}
