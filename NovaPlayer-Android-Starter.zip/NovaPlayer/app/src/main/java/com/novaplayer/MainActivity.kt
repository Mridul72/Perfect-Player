package com.novaplayer

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.documentfile.provider.DocumentFile
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import kotlinx.coroutines.launch

private val Bg = Color(0xFF050607)
private val SurfaceDark = Color(0xFF15191B)
private val Lime = Color(0xFFB8F36B)

class MainActivity : ComponentActivity() {
    private var incomingUri: Uri? = null
    private val folderPicker = registerForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
        if (uri != null) {
            try {
                contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
                getSharedPreferences("nova", MODE_PRIVATE).edit().putString("tree", uri.toString()).apply()
                setContent { NovaApp(incomingUri, uri) }
            } catch (_: Exception) { }
        }
    }
    private val permissionRequest = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        setContent { NovaApp(incomingUri, savedTree()) }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = android.graphics.Color.rgb(5,6,7)
        window.navigationBarColor = android.graphics.Color.rgb(5,6,7)
        incomingUri = extractUri(intent)
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.READ_MEDIA_VIDEO) != PackageManager.PERMISSION_GRANTED) {
            permissionRequest.launch(arrayOf(Manifest.permission.READ_MEDIA_VIDEO))
        }
        setContent { NovaApp(incomingUri, savedTree()) }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent); setIntent(intent); incomingUri = extractUri(intent)
    }
    private fun extractUri(i: Intent?): Uri? = i?.data ?: (i?.getParcelableExtra(Intent.EXTRA_STREAM) as? Uri)
    private fun savedTree(): Uri? = getSharedPreferences("nova", MODE_PRIVATE).getString("tree", null)?.let(Uri::parse)
    fun chooseFolder() { folderPicker.launch(null) }
}

@Composable
private fun NovaApp(incoming: Uri?, tree: Uri?) {
    val context = LocalContext.current
    val activity = context as? MainActivity
    val repo = remember { MediaRepository(context) }
    var tab by remember { mutableStateOf("Home") }
    var videos by remember { mutableStateOf<List<VideoItem>>(emptyList()) }
    var queue by remember { mutableStateOf<List<VideoItem>>(emptyList()) }
    var selected by remember { mutableStateOf<VideoItem?>(null) }
    var folderMessage by remember { mutableStateOf<String?>(null) }
    var query by remember { mutableStateOf("") }
    val scope = rememberCoroutineScope()
    val player = remember { ExoPlayer.Builder(context).build() }
    DisposableEffect(Unit) { onDispose { player.release() } }

    LaunchedEffect(Unit) {
        videos = repo.scanMediaStore()
        if (incoming != null) {
            val siblings = repo.siblingCandidates(incoming)
            queue = siblings
            selected = VideoItem(incoming, incoming.lastPathSegment?.substringAfterLast('/') ?: "Opened video")
            if (siblings.isEmpty()) folderMessage = "1DM shared this video, but not its parent folder. Select the containing folder to enable Next/Previous."
            player.setMediaItem(MediaItem.fromUri(incoming)); player.prepare(); player.playWhenReady = true
        }
    }
    LaunchedEffect(tree) {
        if (tree != null) {
            val found = repo.scanTree(tree)
            videos = (videos + found).distinctBy { it.uri }
            if (incoming != null) {
                val match = found.firstOrNull { it.uri == incoming || it.name == incoming.lastPathSegment }
                queue = found
                if (match != null) {
                    val index = found.indexOf(match)
                    selected = match
                    player.setMediaItems(found.map { MediaItem.fromUri(it.uri) }, index, 0L)
                    player.prepare(); player.playWhenReady = true
                    folderMessage = null
                } else folderMessage = "Folder selected. The shared video could not be matched automatically; choose it from the list."
            }
        }
    }

    MaterialTheme(colorScheme = darkColorScheme(background = Bg, surface = SurfaceDark, primary = Lime, onBackground = Color.White, onSurface = Color.White)) {
        Surface(Modifier.fillMaxSize(), color = Bg) {
            if (selected != null || incoming != null && tab == "Player") {
                PlayerScreen(player, selected?.name ?: "Now playing", folderMessage,
                    onFolder = { activity?.chooseFolder() },
                    onBack = { selected = null; tab = "Home" },
                    onNext = { if (player.hasNextMediaItem()) player.seekToNextMediaItem() },
                    onPrevious = { if (player.hasPreviousMediaItem()) player.seekToPreviousMediaItem() },
                    onBrowse = { tab = "Videos"; selected = null })
            } else {
                Column(Modifier.fillMaxSize().padding(horizontal = 20.dp)) {
                    Spacer(Modifier.height(28.dp))
                    Text("NOVA", color = Lime, fontSize = 30.sp, fontWeight = FontWeight.Black)
                    Text("Your videos. Your privacy.", color = Color.LightGray, fontSize = 13.sp)
                    Spacer(Modifier.height(24.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf("Home","Folders","Videos","Settings").forEach {
                            FilterChip(selected = tab == it, onClick = { tab = it }, label = { Text(it) })
                        }
                    }
                    Spacer(Modifier.height(16.dp))
                    when (tab) {
                        "Settings" -> SettingsScreen(onFolder = { activity?.chooseFolder() })
                        "Folders" -> FolderScreen(tree, onChoose = { activity?.chooseFolder() }, onOpen = { uri ->
                            scope.launch { val list = repo.scanTree(uri); videos = list; queue = list }
                        })
                        else -> {
                            OutlinedTextField(query, { query = it }, Modifier.fillMaxWidth(), placeholder = { Text("Search videos") }, leadingIcon = { Icon(Icons.Default.Search, null) }, singleLine = true)
                            Spacer(Modifier.height(12.dp))
                            Text(if (tab == "Home") "Recently available" else "All videos", fontSize = 21.sp, fontWeight = FontWeight.Bold)
                            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                items(videos.filter { it.name.contains(query, true) }) { item ->
                                    VideoRow(item) {
                                        selected = item; queue = videos
                                        player.setMediaItems(videos.map { MediaItem.fromUri(it.uri) }, videos.indexOf(item), 0L)
                                        player.prepare(); player.playWhenReady = true
                                        tab = "Player"
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun VideoRow(item: VideoItem, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth().background(SurfaceDark, RoundedCornerShape(14.dp)).clickable(onClick = onClick).padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
        Icon(Icons.Default.PlayCircle, null, tint = Lime, modifier = Modifier.size(38.dp))
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(item.name, maxLines = 2, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.SemiBold)
            Text(if (item.size > 0) "%.1f MB".format(item.size / 1048576f) else "Video", color = Color.Gray, fontSize = 12.sp)
        }
        Icon(Icons.Default.PlayArrow, null, tint = Color.Gray)
    }
}

@Composable
private fun PlayerScreen(player: ExoPlayer, title: String, message: String?, onFolder: () -> Unit, onBack: () -> Unit, onNext: () -> Unit, onPrevious: () -> Unit, onBrowse: () -> Unit) {
    var controls by remember { mutableStateOf(true) }
    var position by remember { mutableLongStateOf(0L) }
    var duration by remember { mutableLongStateOf(0L) }
    LaunchedEffect(player) {
        while (true) {
            position = player.currentPosition
            duration = player.duration.coerceAtLeast(0L)
            kotlinx.coroutines.delay(500)
        }
    }
    Column(Modifier.fillMaxSize().background(Bg).padding(16.dp), verticalArrangement = Arrangement.SpaceBetween) {
        Column {
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, null) }
                Text("NOVAPLAYER", color = Lime, fontWeight = FontWeight.Black, fontSize = 20.sp)
                Spacer(Modifier.weight(1f))
                IconButton(onClick = onFolder) { Icon(Icons.Default.FolderOpen, "Choose containing folder", tint = Lime) }
            }
            Text(title, fontSize = 17.sp, fontWeight = FontWeight.Bold, maxLines = 2, overflow = TextOverflow.Ellipsis)
            if (message != null) Text(message, color = Color.LightGray, fontSize = 13.sp)
        }
        Box(Modifier.fillMaxWidth().weight(1f).clickable { controls = !controls }, contentAlignment = Alignment.Center) {
            AndroidView(factory = { PlayerView(it).apply { this.player = player; useController = false } }, update = { it.player = player }, modifier = Modifier.fillMaxWidth().aspectRatio(16f/9f))
        }
        if (controls) {
            Slider(value = if (duration > 0) position.toFloat().coerceIn(0f, duration.toFloat()) else 0f,
                onValueChange = { player.seekTo(it.toLong()) }, valueRange = 0f..duration.coerceAtLeast(1L).toFloat())
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Text(time(position), color = Color.Gray, fontSize = 12.sp)
                Spacer(Modifier.weight(1f))
                Text(time(duration), color = Color.Gray, fontSize = 12.sp)
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly, verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onPrevious) { Icon(Icons.Default.SkipPrevious, "Previous", tint = Color.White, modifier = Modifier.size(34.dp)) }
                IconButton(onClick = { player.seekTo((player.currentPosition - 10_000).coerceAtLeast(0)) }) { Icon(Icons.Default.Replay10, "Back 10", tint = Color.White) }
                IconButton(onClick = { if (player.isPlaying) player.pause() else player.play() }) { Icon(if (player.isPlaying) Icons.Default.PauseCircle else Icons.Default.PlayCircle, "Play pause", tint = Lime, modifier = Modifier.size(54.dp)) }
                IconButton(onClick = { player.seekTo(player.currentPosition + 10_000) }) { Icon(Icons.Default.Forward10, "Forward 10", tint = Color.White) }
                IconButton(onClick = onNext) { Icon(Icons.Default.SkipNext, "Next", tint = Color.White, modifier = Modifier.size(34.dp)) }
            }
        }
    }
}
private fun time(ms: Long): String {
    val s = (ms.coerceAtLeast(0) / 1000).toInt()
    return "%d:%02d".format(s / 60, s % 60)
}

@Composable
private fun FolderScreen(tree: Uri?, onChoose: () -> Unit, onOpen: (Uri) -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Your folders", fontSize = 22.sp, fontWeight = FontWeight.Bold)
        Text("Choose a folder once to grant NovaPlayer persistent read access.", color = Color.LightGray)
        Button(onClick = onChoose) { Icon(Icons.Default.CreateNewFolder, null); Spacer(Modifier.width(8.dp)); Text("Choose folder") }
        if (tree != null) Card(colors = CardDefaults.cardColors(containerColor = SurfaceDark), onClick = { onOpen(tree) }) {
            Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Folder, null, tint = Lime); Spacer(Modifier.width(12.dp))
                Column { Text(DocumentFile.fromTreeUri(LocalContext.current, tree)?.name ?: "Authorised folder"); Text("Tap to scan videos", color = Color.Gray, fontSize = 12.sp) }
            }
        }
    }
}
@Composable
private fun SettingsScreen(onFolder: () -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Settings", fontSize = 22.sp, fontWeight = FontWeight.Bold)
        listOf("Playback preferences", "Gesture controls", "Subtitles", "Library and thumbnails", "Privacy: no ads or analytics").forEach {
            Card(colors = CardDefaults.cardColors(containerColor = SurfaceDark)) { Text(it, Modifier.padding(16.dp)) }
        }
        OutlinedButton(onClick = onFolder) { Icon(Icons.Default.FolderOpen, null); Spacer(Modifier.width(8.dp)); Text("Manage authorised folders") }
    }
}
