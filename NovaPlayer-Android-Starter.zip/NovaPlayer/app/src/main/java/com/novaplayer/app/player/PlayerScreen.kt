package com.novaplayer.app.player

import android.content.res.Configuration
import android.view.View
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.automirrored.rounded.QueueMusic
import androidx.compose.material.icons.rounded.AspectRatio
import androidx.compose.material.icons.rounded.Audiotrack
import androidx.compose.material.icons.rounded.BrightnessMedium
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.Forward10
import androidx.compose.material.icons.rounded.Headphones
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material.icons.rounded.LockOpen
import androidx.compose.material.icons.rounded.MoreVert
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PictureInPictureAlt
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Replay
import androidx.compose.material.icons.rounded.Replay10
import androidx.compose.material.icons.rounded.ScreenRotation
import androidx.compose.material.icons.rounded.SkipNext
import androidx.compose.material.icons.rounded.SkipPrevious
import androidx.compose.material.icons.rounded.Speed
import androidx.compose.material.icons.rounded.Subtitles
import androidx.compose.material.icons.rounded.Timer
import androidx.compose.material.icons.rounded.VolumeUp
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.media3.common.Player
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import com.novaplayer.app.data.AppSettings
import com.novaplayer.app.ui.components.ChoiceRow
import com.novaplayer.app.ui.components.ColorDot
import com.novaplayer.app.ui.components.SliderRow
import com.novaplayer.app.util.Fmt
import kotlinx.coroutines.delay
import kotlin.math.abs

private enum class Panel { SPEED, SUBTITLES, AUDIO, QUEUE, SLEEP, MORE }

private sealed interface Hud {
    data class Seek(val target: Long, val delta: Long) : Hud
    data class Level(val icon: ImageVector, val fraction: Float) : Hud
    data class Message(val text: String) : Hud
}

private data class Flash(val forward: Boolean, val text: String)

private val RESIZE_LABELS = listOf("Fit", "Fill", "Stretch", "Crop")
private val SUB_COLORS = listOf(
    "White" to Color.White,
    "Yellow" to Color(0xFFFFE066),
    "Lime" to Color(0xFFB8F34A),
    "Cyan" to Color(0xFF5CE1E6),
)

@Composable
fun PlayerScreen(vm: PlayerViewModel, host: PlayerHost) {
    val ui by vm.ui.collectAsStateWithLifecycle()
    val st by vm.settings.collectAsStateWithLifecycle()
    val lifecycle = LocalLifecycleOwner.current.lifecycle
    val lifecycleState by lifecycle.currentStateFlow.collectAsState()
    val attached = lifecycleState.isAtLeast(Lifecycle.State.STARTED)

    var controlsVisible by remember { mutableStateOf(true) }
    var locked by remember { mutableStateOf(false) }
    var lockHint by remember { mutableStateOf(false) }
    var panel by remember { mutableStateOf<Panel?>(null) }
    var poke by remember { mutableIntStateOf(0) }
    var hud by remember { mutableStateOf<Hud?>(null) }
    var flash by remember { mutableStateOf<Flash?>(null) }

    LaunchedEffect(controlsVisible, poke, ui.isPlaying, panel) {
        if (controlsVisible && ui.isPlaying && panel == null) {
            delay(st.controlsTimeoutSec * 1000L)
            controlsVisible = false
        }
    }
    LaunchedEffect(hud) { if (hud != null) { delay(900); hud = null } }
    LaunchedEffect(flash) { if (flash != null) { delay(600); flash = null } }
    LaunchedEffect(lockHint) { if (lockHint) { delay(2500); lockHint = false } }
    LaunchedEffect(ui.toast) {
        ui.toast?.let {
            hud = Hud.Message(it)
            vm.consumeToast()
        }
    }

    Box(Modifier.fillMaxSize().background(Color.Black)) {
        VideoSurface(vm.player, ui.resize, attached)

        if (ui.audioOnly) AudioOnlyBackdrop(ui.title)

        if (!ui.inPip) SubtitleOverlay(ui.cueText, st)

        // Gesture layer sits above the video and below every control.
        Box(
            Modifier.fillMaxSize()
                .pointerInput(locked, st.gestures, st.doubleTapSec) {
                    detectTapGestures(
                        onTap = {
                            if (locked) lockHint = true
                            else {
                                controlsVisible = !controlsVisible
                                poke++
                            }
                        },
                        onDoubleTap = { o ->
                            if (!locked && st.gestures) {
                                val w = size.width
                                when {
                                    o.x < w * 0.35f -> {
                                        vm.seekBy(-st.doubleTapSec * 1000L)
                                        flash = Flash(false, "−${st.doubleTapSec}s")
                                    }
                                    o.x > w * 0.65f -> {
                                        vm.seekBy(st.doubleTapSec * 1000L)
                                        flash = Flash(true, "+${st.doubleTapSec}s")
                                    }
                                    else -> vm.togglePlay()
                                }
                            }
                        },
                    )
                }
                .pointerInput(locked, st.gestures, st.seekSens, st.brightnessSens, st.volumeSens) {
                    var mode = 0 // 0 undecided, 1 seek, 2 brightness, 3 volume
                    var accX = 0f
                    var accY = 0f
                    var startX = 0f
                    var startPos = 0L
                    var startBright = 0.5f
                    var startVol = 0.5f
                    var target = 0L
                    detectDragGestures(
                        onDragStart = { o: Offset ->
                            mode = 0
                            accX = 0f
                            accY = 0f
                            startX = o.x
                            startPos = vm.currentPosition()
                            startBright = host.brightness
                            startVol = host.volume
                        },
                        onDragEnd = {
                            if (mode == 1) vm.seekTo(target)
                            mode = 0
                        },
                        onDragCancel = { mode = 0 },
                        onDrag = { change, drag ->
                            if (locked || !st.gestures) return@detectDragGestures
                            accX += drag.x
                            accY += drag.y
                            if (mode == 0 && (abs(accX) > 24f || abs(accY) > 24f)) {
                                mode = if (abs(accX) > abs(accY)) 1
                                else if (startX < size.width / 2f) 2 else 3
                            }
                            when (mode) {
                                1 -> {
                                    val delta = (accX / size.width * 120_000f * st.seekSens).toLong()
                                    val dur = vm.duration()
                                    target = (startPos + delta).coerceIn(0L, if (dur > 0) dur else Long.MAX_VALUE)
                                    hud = Hud.Seek(target, target - startPos)
                                }
                                2 -> {
                                    val v = (startBright - accY / size.height * 1.3f * st.brightnessSens).coerceIn(0.02f, 1f)
                                    host.brightness = v
                                    hud = Hud.Level(Icons.Rounded.BrightnessMedium, v)
                                }
                                3 -> {
                                    val v = (startVol - accY / size.height * 1.3f * st.volumeSens).coerceIn(0f, 1f)
                                    host.volume = v
                                    hud = Hud.Level(Icons.Rounded.VolumeUp, v)
                                }
                            }
                            if (mode != 0) change.consume()
                        },
                    )
                }
        )

        if (!ui.inPip) {
            AnimatedVisibility(
                visible = controlsVisible && !locked && panel == null,
                enter = fadeIn(),
                exit = fadeOut(),
            ) {
                Controls(
                    ui = ui,
                    st = st,
                    vm = vm,
                    host = host,
                    onPanel = { panel = it },
                    onLock = { locked = true; lockHint = true },
                    onPoke = { poke++ },
                )
            }

            if (locked) LockOverlay(lockHint) { locked = false; controlsVisible = true }

            flash?.let { f ->
                Text(
                    f.text,
                    color = Color.White,
                    fontSize = 22.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier
                        .align(if (f.forward) Alignment.CenterEnd else Alignment.CenterStart)
                        .padding(horizontal = 56.dp)
                        .background(Color(0x99000000), CircleShape)
                        .padding(horizontal = 18.dp, vertical = 10.dp),
                )
            }

            hud?.let { HudView(it, Modifier.align(Alignment.TopCenter)) }

            if (ui.buffering && !ui.isPlaying && ui.error == null) {
                CircularProgressIndicator(Modifier.align(Alignment.Center), color = MaterialTheme.colorScheme.primary)
            }

            if (ui.folderStatus == FolderStatus.NEEDS_FOLDER && !ui.promptDismissed) {
                FolderPrompt(ui, host, vm, Modifier.align(Alignment.TopCenter))
            }

            ui.error?.let { ErrorOverlay(it, ui.hasNext, onNext = vm::next, onClose = host::close) }

            panel?.let { p ->
                SidePanel(title = panelTitle(p), onClose = { panel = null }) {
                    when (p) {
                        Panel.SPEED -> SpeedPanel(ui, vm)
                        Panel.SUBTITLES -> SubtitlePanel(ui, st, vm, host)
                        Panel.AUDIO -> AudioPanel(ui, vm)
                        Panel.QUEUE -> QueuePanel(ui, vm) { panel = null }
                        Panel.SLEEP -> SleepPanel(ui, vm)
                        Panel.MORE -> MorePanel(ui, st, vm)
                    }
                }
            }
        }
    }
}

private fun panelTitle(p: Panel) = when (p) {
    Panel.SPEED -> "Playback speed"
    Panel.SUBTITLES -> "Subtitles"
    Panel.AUDIO -> "Audio track"
    Panel.QUEUE -> "Up next"
    Panel.SLEEP -> "Sleep timer"
    Panel.MORE -> "More"
}

// ---------------------------------------------------------------------------------------------
// Video + overlays
// ---------------------------------------------------------------------------------------------

@Composable
private fun VideoSurface(player: Player, resize: Int, attached: Boolean) {
    val mode = when (resize) {
        1 -> AspectRatioFrameLayout.RESIZE_MODE_FIXED_WIDTH
        2 -> AspectRatioFrameLayout.RESIZE_MODE_FILL
        3 -> AspectRatioFrameLayout.RESIZE_MODE_ZOOM
        else -> AspectRatioFrameLayout.RESIZE_MODE_FIT
    }
    AndroidView(
        factory = { ctx ->
            PlayerView(ctx).apply {
                useController = false
                setShutterBackgroundColor(android.graphics.Color.BLACK)
                // Subtitles are drawn by NovaPlayer itself (size, colour, position and delay).
                subtitleView?.visibility = View.GONE
            }
        },
        update = { v ->
            v.player = if (attached) player else null
            v.resizeMode = mode
        },
        onRelease = { it.player = null },
        modifier = Modifier.fillMaxSize(),
    )
}

@Composable
private fun AudioOnlyBackdrop(title: String) {
    Box(Modifier.fillMaxSize().background(Color(0xFF050505)), contentAlignment = Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.padding(32.dp)) {
            Icon(Icons.Rounded.Headphones, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(72.dp))
            Text(
                title,
                color = Color.White,
                style = MaterialTheme.typography.titleMedium,
                textAlign = TextAlign.Center,
                maxLines = 3,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.padding(top = 16.dp),
            )
            Text("Audio only", color = Color(0xFF8A8A8A), style = MaterialTheme.typography.bodySmall)
        }
    }
}

@Composable
private fun SubtitleOverlay(text: String?, s: AppSettings) {
    if (text.isNullOrBlank()) return
    val heightDp = LocalConfiguration.current.screenHeightDp
    Box(
        Modifier.fillMaxSize().windowInsetsPadding(WindowInsets.safeDrawing),
        contentAlignment = Alignment.BottomCenter,
    ) {
        Text(
            text,
            color = Color(s.subColor),
            fontSize = s.subSize.sp,
            fontWeight = FontWeight.Medium,
            textAlign = TextAlign.Center,
            style = TextStyle(shadow = Shadow(Color.Black, Offset(2f, 2f), 6f)),
            modifier = Modifier
                .padding(start = 24.dp, end = 24.dp, bottom = (s.subBottom * heightDp).dp)
                .background(Color.Black.copy(alpha = s.subBackground), RoundedCornerShape(8.dp))
                .padding(horizontal = 10.dp, vertical = 3.dp),
        )
    }
}

@Composable
private fun HudView(h: Hud, modifier: Modifier) {
    Box(
        modifier.padding(top = 48.dp).background(Color(0xCC000000), RoundedCornerShape(16.dp)).padding(horizontal = 20.dp, vertical = 12.dp),
        contentAlignment = Alignment.Center,
    ) {
        when (h) {
            is Hud.Seek -> {
                val sign = if (h.delta >= 0) "+" else "−"
                Text(
                    "${Fmt.duration(h.target)}  ($sign${Fmt.duration(abs(h.delta))})",
                    color = Color.White,
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 20.sp,
                )
            }
            is Hud.Level -> Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Icon(h.icon, null, tint = Color.White)
                LinearProgressIndicator(
                    progress = { h.fraction },
                    modifier = Modifier.size(width = 120.dp, height = 4.dp),
                    color = MaterialTheme.colorScheme.primary,
                    trackColor = Color(0x44FFFFFF),
                )
                Text("${(h.fraction * 100).toInt()}%", color = Color.White)
            }
            is Hud.Message -> Text(h.text, color = Color.White)
        }
    }
}

@Composable
private fun LockOverlay(showButton: Boolean, onUnlock: () -> Unit) {
    Box(Modifier.fillMaxSize().windowInsetsPadding(WindowInsets.safeDrawing)) {
        AnimatedVisibility(showButton, modifier = Modifier.align(Alignment.CenterStart), enter = fadeIn(), exit = fadeOut()) {
            IconButton(
                onClick = onUnlock,
                modifier = Modifier.padding(16.dp).size(56.dp).background(Color(0xCC000000), CircleShape),
            ) {
                Icon(Icons.Rounded.LockOpen, "Unlock", tint = MaterialTheme.colorScheme.primary)
            }
        }
    }
}

@Composable
private fun ErrorOverlay(message: String, hasNext: Boolean, onNext: () -> Unit, onClose: () -> Unit) {
    Box(Modifier.fillMaxSize().background(Color(0xE6000000)), contentAlignment = Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.padding(32.dp).widthIn(max = 420.dp)) {
            Text("Can't play this file", color = Color.White, style = MaterialTheme.typography.titleLarge)
            Text(
                message,
                color = Color(0xFFB0B0B0),
                textAlign = TextAlign.Center,
                modifier = Modifier.padding(vertical = 12.dp),
            )
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                OutlinedButton(onClick = onClose) { Text("Close") }
                if (hasNext) {
                    Button(
                        onClick = onNext,
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                    ) { Text("Play next", color = Color.Black) }
                }
            }
        }
    }
}

/** Shown instead of an endless spinner when the folder can't be discovered automatically. */
@Composable
private fun FolderPrompt(ui: PlayerUi, host: PlayerHost, vm: PlayerViewModel, modifier: Modifier) {
    Surface(
        modifier = modifier
            .windowInsetsPadding(WindowInsets.safeDrawing)
            .padding(top = 64.dp, start = 16.dp, end = 16.dp)
            .widthIn(max = 460.dp),
        shape = RoundedCornerShape(20.dp),
        color = Color(0xF0161616),
        tonalElevation = 0.dp,
    ) {
        Column(Modifier.padding(18.dp)) {
            Text("Enable Next and Previous", color = Color.White, style = MaterialTheme.typography.titleMedium)
            Text(
                ui.folderMessage
                    ?: "Android only shared this one video. Choose its folder once and NovaPlayer will remember it.",
                color = Color(0xFFB0B0B0),
                style = MaterialTheme.typography.bodyMedium,
                modifier = Modifier.padding(top = 6.dp),
            )
            Row(Modifier.padding(top = 12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(
                    onClick = host::pickFolder,
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                ) { Text("Choose folder", color = Color.Black) }
                if (!host.hasMediaAccess()) {
                    OutlinedButton(onClick = host::requestMediaAccess) { Text("Enable full storage scan") }
                }
                TextButton(onClick = vm::dismissFolderPrompt) { Text("Not now") }
            }
        }
    }
}

// ---------------------------------------------------------------------------------------------
// Controls
// ---------------------------------------------------------------------------------------------

@Composable
private fun Controls(
    ui: PlayerUi,
    st: AppSettings,
    vm: PlayerViewModel,
    host: PlayerHost,
    onPanel: (Panel) -> Unit,
    onLock: () -> Unit,
    onPoke: () -> Unit,
) {
    val step = st.seekStepSec * 1000L
    Box(
        Modifier.fillMaxSize()
            .background(Brush.verticalGradient(listOf(Color(0xB3000000), Color.Transparent, Color.Transparent, Color(0xCC000000))))
            .windowInsetsPadding(WindowInsets.safeDrawing),
    ) {
        // top bar
        Row(
            Modifier.align(Alignment.TopCenter).fillMaxWidth().padding(horizontal = 8.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            ControlIcon(Icons.AutoMirrored.Rounded.ArrowBack, "Back") { host.close() }
            if (LocalConfiguration.current.orientation != Configuration.ORIENTATION_LANDSCAPE) {
                Column(Modifier.weight(1f).padding(horizontal = 4.dp)) {
                    Text(ui.title, color = Color.White, maxLines = 1, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.titleSmall)
                    val sub = buildString {
                        if (ui.count > 1) append("${ui.index + 1} of ${ui.count}")
                        if (ui.folderLabel.isNotEmpty()) {
                            if (isNotEmpty()) append("  ·  ")
                            append(ui.folderLabel)
                        }
                    }
                    if (sub.isNotEmpty()) Text(sub, color = Color(0xFFB0B0B0), maxLines = 1, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.labelSmall)
                }
            } else {
                Spacer(Modifier.weight(1f))
            }
            ControlIcon(Icons.Rounded.Subtitles, "Subtitles", tint = if (ui.subMode != SubMode.OFF) MaterialTheme.colorScheme.primary else Color.White) { onPanel(Panel.SUBTITLES) }
            ControlIcon(Icons.Rounded.Audiotrack, "Audio track") { onPanel(Panel.AUDIO) }
            ControlIcon(Icons.AutoMirrored.Rounded.QueueMusic, "Queue") { onPanel(Panel.QUEUE) }
            ControlIcon(Icons.Rounded.MoreVert, "More") { onPanel(Panel.MORE) }
        }

        // centre transport
        Row(
            Modifier.align(Alignment.Center),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(7.dp),
        ) {
            ControlIcon(Icons.Rounded.SkipPrevious, "Previous video", size = 38.dp, enabled = ui.hasPrev) { vm.previous(); onPoke() }
            ControlIcon(Icons.Rounded.Replay10, "Back 10 seconds", size = 36.dp) { vm.seekBy(-step); onPoke() }
            Box(
                Modifier.size(50.dp).clip(CircleShape).background(MaterialTheme.colorScheme.primary)
                    .clickable { vm.togglePlay(); onPoke() },
                contentAlignment = Alignment.Center,
            ) {
                Icon(
                    when {
                        ui.ended -> Icons.Rounded.Replay
                        ui.isPlaying -> Icons.Rounded.Pause
                        else -> Icons.Rounded.PlayArrow
                    },
                    if (ui.isPlaying) "Pause" else "Play",
                    tint = Color.Black,
                    modifier = Modifier.size(27.dp),
                )
            }
            ControlIcon(Icons.Rounded.Forward10, "Forward 10 seconds", size = 36.dp) { vm.seekBy(step); onPoke() }
            ControlIcon(Icons.Rounded.SkipNext, "Next video", size = 38.dp, enabled = ui.hasNext) { vm.next(); onPoke() }
        }

        // bottom: seek bar + tools
        Column(Modifier.align(Alignment.BottomCenter).fillMaxWidth().padding(horizontal = 10.dp, vertical = 2.dp)) {
            SeekBar(vm, onPoke)
            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceEvenly,
                verticalAlignment = Alignment.CenterVertically,
            ) {
                ControlIcon(Icons.Rounded.Lock, "Lock screen") { onLock() }
                ControlIcon(Icons.Rounded.ScreenRotation, "Rotate") { host.rotate(); onPoke() }
                Row(
                    Modifier.clip(RoundedCornerShape(50)).clickable { vm.cycleResize(); onPoke() }.padding(horizontal = 10.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                ) {
                    Icon(Icons.Rounded.AspectRatio, "Aspect ratio", tint = Color.White)
                    Text(RESIZE_LABELS[ui.resize.coerceIn(0, 3)], color = Color.White, style = MaterialTheme.typography.labelLarge)
                }
                Row(
                    Modifier.clip(RoundedCornerShape(50)).clickable { onPanel(Panel.SPEED) }.padding(horizontal = 10.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                ) {
                    Icon(Icons.Rounded.Speed, "Playback speed", tint = if (ui.speed != 1f) MaterialTheme.colorScheme.primary else Color.White)
                    Text(Fmt.speed(ui.speed), color = Color.White, style = MaterialTheme.typography.labelLarge)
                }
                ControlIcon(
                    Icons.Rounded.Timer, "Sleep timer",
                    tint = if (ui.sleepRemainingMs > 0 || ui.sleepAtEnd) MaterialTheme.colorScheme.primary else Color.White,
                ) { onPanel(Panel.SLEEP) }
                ControlIcon(Icons.Rounded.PictureInPictureAlt, "Picture in picture") { host.enterPip() }
            }
        }
    }
}

@Composable
private fun SeekBar(vm: PlayerViewModel, onPoke: () -> Unit) {
    val pos by vm.position.collectAsStateWithLifecycle()
    var dragging by remember { mutableStateOf(false) }
    var dragValue by remember { mutableStateOf(0f) }
    val duration = pos.duration.coerceAtLeast(1L)
    val shown = if (dragging) dragValue.toLong() else pos.position
    Column(Modifier.fillMaxWidth()) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(Fmt.duration(shown), color = Color.White, style = MaterialTheme.typography.bodySmall)
            Slider(
                value = (if (dragging) dragValue else pos.position.toFloat()).coerceIn(0f, duration.toFloat()),
                onValueChange = {
                    dragging = true
                    dragValue = it
                    onPoke()
                },
                onValueChangeFinished = {
                    vm.seekTo(dragValue.toLong())
                    dragging = false
                },
                valueRange = 0f..duration.toFloat(),
                modifier = Modifier.weight(1f).height(24.dp).padding(horizontal = 6.dp),
                colors = SliderDefaults.colors(
                    thumbColor = MaterialTheme.colorScheme.primary,
                    activeTrackColor = MaterialTheme.colorScheme.primary,
                    inactiveTrackColor = Color(0x44FFFFFF),
                ),
            )
            Text(Fmt.duration(pos.duration), color = Color.White, style = MaterialTheme.typography.bodySmall)
        }
        Text(
            "Remaining −${Fmt.duration((pos.duration - shown).coerceAtLeast(0))}",
            color = Color(0xFFB0B0B0),
            style = MaterialTheme.typography.bodySmall,
            modifier = Modifier.align(Alignment.End).padding(end = 4.dp),
        )
    }
}

@Composable
private fun ControlIcon(
    icon: ImageVector,
    description: String,
    size: androidx.compose.ui.unit.Dp = 34.dp,
    tint: Color = Color.White,
    enabled: Boolean = true,
    onClick: () -> Unit,
) {
    IconButton(onClick = onClick, enabled = enabled, modifier = Modifier.size(size)) {
        Icon(icon, description, tint = if (enabled) tint else tint.copy(alpha = 0.3f), modifier = Modifier.size(size * 0.56f))
    }
}

// ---------------------------------------------------------------------------------------------
// Side panels
// ---------------------------------------------------------------------------------------------

@Composable
private fun SidePanel(title: String, onClose: () -> Unit, content: @Composable () -> Unit) {
    Box(
        Modifier.fillMaxSize().background(Color(0x73000000)).clickable(
            interactionSource = remember { MutableInteractionSource() },
            indication = null,
            onClick = onClose,
        )
    ) {
        Surface(
            modifier = Modifier
                .align(Alignment.CenterEnd)
                .fillMaxHeight()
                .fillMaxWidth(0.92f)
                .widthIn(max = 400.dp)
                .pointerInput(Unit) { detectTapGestures { } },
            color = Color(0xF2101010),
            shape = RoundedCornerShape(topStart = 24.dp, bottomStart = 24.dp),
        ) {
            Column(Modifier.windowInsetsPadding(WindowInsets.safeDrawing).padding(vertical = 12.dp)) {
                Row(Modifier.fillMaxWidth().padding(start = 20.dp, end = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text(title, color = Color.White, style = MaterialTheme.typography.titleLarge, modifier = Modifier.weight(1f))
                    TextButton(onClick = onClose) { Text("Done", color = MaterialTheme.colorScheme.primary) }
                }
                Column(Modifier.weight(1f).verticalScroll(rememberScrollState())) { content() }
            }
        }
    }
}

@Composable
private fun OptionRow(label: String, selected: Boolean, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clickable(onClick = onClick).padding(horizontal = 20.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(label, color = Color.White, modifier = Modifier.weight(1f), maxLines = 2, overflow = TextOverflow.Ellipsis)
        if (selected) Icon(Icons.Rounded.Check, null, tint = MaterialTheme.colorScheme.primary)
    }
}

@Composable
private fun SpeedPanel(ui: PlayerUi, vm: PlayerViewModel) {
    SliderRow(
        title = "Speed",
        valueText = { Fmt.speed(it) },
        value = ui.speed,
        range = 0.25f..4f,
        steps = 74,
        onChange = { vm.setSpeed(Math.round(it * 20f) / 20f) },
    )
    val presets = listOf(0.25f, 0.5f, 0.75f, 1f, 1.25f, 1.5f, 2f, 3f, 4f)
    Row(
        Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 16.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        presets.forEach { s ->
            FilterChip(
                selected = abs(ui.speed - s) < 0.01f,
                onClick = { vm.setSpeed(s) },
                label = { Text(Fmt.speed(s)) },
                colors = FilterChipDefaults.filterChipColors(
                    selectedContainerColor = MaterialTheme.colorScheme.primary,
                    selectedLabelColor = Color.Black,
                ),
            )
        }
    }
    Text(
        "Speeds above 2x depend on the device's decoder and may drop frames on high-bitrate files.",
        color = Color(0xFF8A8A8A),
        style = MaterialTheme.typography.bodySmall,
        modifier = Modifier.padding(20.dp),
    )
}

@Composable
private fun SubtitlePanel(ui: PlayerUi, st: AppSettings, vm: PlayerViewModel, host: PlayerHost) {
    OptionRow("Off", ui.subMode == SubMode.OFF) { vm.subtitlesOff() }
    ui.externalSubName?.let { OptionRow("File: $it", ui.subMode == SubMode.EXTERNAL) { } }
    ui.textTracks.forEach { t ->
        OptionRow("Embedded: ${t.label}", ui.subMode == SubMode.EMBEDDED && t.selected) { vm.selectEmbeddedSubtitle(t) }
    }
    Row(Modifier.padding(horizontal = 16.dp, vertical = 8.dp)) {
        OutlinedButton(onClick = host::pickSubtitle) { Text("Add subtitle file (SRT, ASS, VTT)") }
    }
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Column(Modifier.weight(1f)) {
            Text("Delay", color = Color.White, style = MaterialTheme.typography.titleMedium)
            Text(
                "${if (ui.subtitleDelayMs >= 0) "+" else "−"}${abs(ui.subtitleDelayMs) / 1000.0}s  (subtitle files only)",
                color = Color(0xFF8A8A8A),
                style = MaterialTheme.typography.bodySmall,
            )
        }
        TextButton(onClick = { vm.setSubtitleDelay(ui.subtitleDelayMs - 500) }) { Text("−0.5") }
        TextButton(onClick = { vm.setSubtitleDelay(ui.subtitleDelayMs - 100) }) { Text("−0.1") }
        TextButton(onClick = { vm.setSubtitleDelay(ui.subtitleDelayMs + 100) }) { Text("+0.1") }
        TextButton(onClick = { vm.setSubtitleDelay(ui.subtitleDelayMs + 500) }) { Text("+0.5") }
    }
    SliderRow("Size", { "${it.toInt()} sp" }, st.subSize, 12f..40f, 27) { v -> vm.updateSettings { copy(subSize = v) } }
    SliderRow("Position", { "${(it * 100).toInt()}% from bottom" }, st.subBottom, 0f..0.4f) { v -> vm.updateSettings { copy(subBottom = v) } }
    SliderRow("Background", { "${(it * 100).toInt()}%" }, st.subBackground, 0f..0.9f) { v -> vm.updateSettings { copy(subBackground = v) } }
    Row(Modifier.padding(horizontal = 20.dp, vertical = 8.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        SUB_COLORS.forEach { (_, c) ->
            val argb = c.toArgb()
            ColorDot(c, st.subColor == argb) {
                vm.updateSettings { copy(subColor = argb) }
            }
        }
    }
}

@Composable
private fun AudioPanel(ui: PlayerUi, vm: PlayerViewModel) {
    if (ui.audioTracks.isEmpty()) {
        Text("No selectable audio tracks in this file.", color = Color(0xFF8A8A8A), modifier = Modifier.padding(20.dp))
    }
    ui.audioTracks.forEach { t -> OptionRow(t.label, t.selected) { vm.selectAudio(t) } }
    Text(
        "If a track is missing, its codec (for example AC-3, DTS or TrueHD) may not be supported by this device.",
        color = Color(0xFF8A8A8A),
        style = MaterialTheme.typography.bodySmall,
        modifier = Modifier.padding(20.dp),
    )
}

@Composable
private fun QueuePanel(ui: PlayerUi, vm: PlayerViewModel, onPicked: () -> Unit) {
    Box(Modifier.fillMaxWidth().padding(horizontal = 0.dp)) {
        Column {
            ui.queue.forEachIndexed { i, v ->
                OptionRow("${i + 1}.  ${v.title}", i == ui.index) {
                    vm.jumpTo(i)
                    onPicked()
                }
            }
        }
    }
}

@Composable
private fun SleepPanel(ui: PlayerUi, vm: PlayerViewModel) {
    if (ui.sleepRemainingMs > 0) {
        Text(
            "Pausing in ${Fmt.duration(ui.sleepRemainingMs)}",
            color = MaterialTheme.colorScheme.primary,
            modifier = Modifier.padding(horizontal = 20.dp, vertical = 8.dp),
        )
    }
    if (ui.sleepAtEnd) {
        Text("Pausing when this video ends", color = MaterialTheme.colorScheme.primary, modifier = Modifier.padding(horizontal = 20.dp, vertical = 8.dp))
    }
    listOf(15, 30, 45, 60, 90).forEach { m -> OptionRow("$m minutes", false) { vm.setSleepTimer(m) } }
    OptionRow("End of this video", ui.sleepAtEnd) { vm.setSleepAtEndOfVideo() }
    OptionRow("Off", ui.sleepRemainingMs == 0L && !ui.sleepAtEnd) { vm.cancelSleep() }
}

@Composable
private fun MorePanel(ui: PlayerUi, st: AppSettings, vm: PlayerViewModel) {
    ChoiceRow("Repeat", listOf("Off", "One", "All"), ui.repeatMode) { vm.setRepeat(it) }
    ChoiceRow("Audio only", listOf("Off", "On"), if (ui.audioOnly) 1 else 0) { vm.setAudioOnly(it == 1) }
    ChoiceRow("Decoder", listOf("Hardware first", "Software first"), if (st.softwareDecoder) 1 else 0) { vm.setSoftwareDecoder(it == 1) }
    ChoiceRow("Background playback", listOf("Off", "On"), if (st.bgPlayback) 1 else 0) { v -> vm.updateSettings { copy(bgPlayback = v == 1) } }
    ChoiceRow("Aspect ratio", RESIZE_LABELS, ui.resize) { vm.setResize(it) }
}
