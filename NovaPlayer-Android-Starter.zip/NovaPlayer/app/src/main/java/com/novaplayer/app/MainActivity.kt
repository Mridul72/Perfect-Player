package com.novaplayer.app

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.runtime.getValue
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.novaplayer.app.data.VideoItem
import com.novaplayer.app.player.PlayerActivity
import com.novaplayer.app.playback.PlaybackRequests
import com.novaplayer.app.ui.AppActions
import com.novaplayer.app.ui.LibraryViewModel
import com.novaplayer.app.ui.NovaRoot
import com.novaplayer.app.ui.theme.NovaTheme
import com.novaplayer.app.util.Permissions

class MainActivity : ComponentActivity() {

    private var hasResumedOnce = false
    private val vm: LibraryViewModel by viewModels()

    private val mediaPermission =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            vm.onPermissionChanged()
            if (granted) requestAllFilesAccess()
        }
    private val notificationPermission =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { _ -> }
    private val folderPicker =
        registerForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri: Uri? ->
            if (uri != null) vm.addAuthorisedFolder(uri)
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        val actions = AppActions(
            play = { items, index -> play(items, index) },
            requestMedia = { requestMedia() },
            requestNotifications = { requestNotifications() },
            addFolder = { folderPicker.launch(null) },
            openAppSettings = { openAppSettings() },
            hasNotificationPermission = { hasNotificationPermission() },
        )

        setContent {
            val s by vm.settings.collectAsStateWithLifecycle()
            NovaTheme(accentIndex = s.accent) {
                NovaRoot(vm, actions)
            }
        }

        // Ask once on first launch; afterwards the Home screen explains and offers a button.
        if (Build.VERSION.SDK_INT >= 30 && !Environment.isExternalStorageManager()) requestAllFilesAccess()
        else if (!vm.hasPermission.value && !Permissions.mediaAsked(this)) requestMedia()
    }

    override fun onResume() {
        super.onResume()
        if (hasResumedOnce) vm.refresh() // picks up newly downloaded files and permission changes
        else hasResumedOnce = true // the ViewModel already starts the initial scan
    }

    private fun play(items: List<VideoItem>, index: Int) {
        if (items.isEmpty()) return
        PlaybackRequests.pending = PlaybackRequests.Pending(items, index)
        startActivity(Intent(this, PlayerActivity::class.java))
    }

    private fun requestMedia() {
        if (nova.media.hasAllFilesAccess()) {
            vm.refresh()
            return
        }
        if (Build.VERSION.SDK_INT >= 30 && ContextCompat.checkSelfPermission(this, Permissions.media) == PackageManager.PERMISSION_GRANTED &&
            !Environment.isExternalStorageManager()) {
            requestAllFilesAccess()
            return
        }
        val perm = Permissions.media
        val canAsk = !Permissions.mediaAsked(this) || ActivityCompat.shouldShowRequestPermissionRationale(this, perm)
        if (canAsk) {
            Permissions.markMediaAsked(this)
            mediaPermission.launch(perm)
        } else {
            openAppSettings()
        }
    }

    private fun requestAllFilesAccess() {
        if (Build.VERSION.SDK_INT < 30 || Environment.isExternalStorageManager()) {
            vm.refresh()
            return
        }
        val intent = Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION,
            Uri.parse("package:$packageName"))
        runCatching { startActivity(intent) }.onFailure { openAppSettings() }
    }

    private fun requestNotifications() {
        if (Build.VERSION.SDK_INT >= 33) notificationPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
    }

    private fun hasNotificationPermission(): Boolean =
        Build.VERSION.SDK_INT < 33 ||
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED

    private fun openAppSettings() {
        startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName")))
    }
}
