package com.novaplayer

import android.content.ContentUris
import android.content.Context
import android.net.Uri
import android.provider.MediaStore
import androidx.documentfile.provider.DocumentFile
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

data class VideoItem(val uri: Uri, val name: String, val duration: Long = 0L, val size: Long = 0L, val modified: Long = 0L)

class MediaRepository(private val context: Context) {
    suspend fun scanMediaStore(): List<VideoItem> = withContext(Dispatchers.IO) {
        val result = mutableListOf<VideoItem>()
        val collection = MediaStore.Video.Media.getContentUri(MediaStore.VOLUME_EXTERNAL)
        val projection = arrayOf(MediaStore.Video.Media._ID, MediaStore.Video.Media.DISPLAY_NAME,
            MediaStore.Video.Media.DURATION, MediaStore.Video.Media.SIZE, MediaStore.Video.Media.DATE_MODIFIED)
        try {
            context.contentResolver.query(collection, projection, null, null,
                "${MediaStore.Video.Media.DISPLAY_NAME} COLLATE NOCASE ASC")?.use { c ->
                val id = c.getColumnIndexOrThrow(MediaStore.Video.Media._ID)
                val name = c.getColumnIndexOrThrow(MediaStore.Video.Media.DISPLAY_NAME)
                val duration = c.getColumnIndexOrThrow(MediaStore.Video.Media.DURATION)
                val size = c.getColumnIndexOrThrow(MediaStore.Video.Media.SIZE)
                val modified = c.getColumnIndexOrThrow(MediaStore.Video.Media.DATE_MODIFIED)
                while (c.moveToNext()) result += VideoItem(
                    ContentUris.withAppendedId(collection, c.getLong(id)),
                    c.getString(name) ?: "Video", c.getLong(duration), c.getLong(size), c.getLong(modified))
            }
        } catch (_: SecurityException) { }
        result
    }

    suspend fun scanTree(treeUri: Uri): List<VideoItem> = withContext(Dispatchers.IO) {
        val root = DocumentFile.fromTreeUri(context, treeUri) ?: return@withContext emptyList()
        val result = mutableListOf<VideoItem>()
        fun walk(dir: DocumentFile, depth: Int) {
            if (depth > 12) return
            dir.listFiles().forEach { f ->
                if (f.isDirectory) walk(f, depth + 1)
                else if (f.isFile && isVideo(f.name, f.type)) result += VideoItem(
                    f.uri, f.name ?: "Video", 0L, f.length(), f.lastModified())
            }
        }
        walk(root, 0)
        result.sortedWith(compareBy(String.CASE_INSENSITIVE_ORDER) { it.name })
    }

    private fun isVideo(name: String?, mime: String?): Boolean {
        if (mime?.startsWith("video/") == true) return true
        return name?.substringAfterLast('.', "")?.lowercase() in
            setOf("mp4","mkv","avi","mov","webm","3gp","mpg","mpeg","ts","m4v")
    }

    suspend fun siblingCandidates(incoming: Uri): List<VideoItem> {
        // A provider URI is not assumed to expose its parent folder. MediaStore is the safe first attempt.
        val all = scanMediaStore()
        val target = all.indexOfFirst { it.uri == incoming }
        return if (target >= 0) all else emptyList()
    }
}
