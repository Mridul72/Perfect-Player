package com.novaplayer

import android.content.ContentUris
import android.content.Context
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.provider.OpenableColumns
import androidx.documentfile.provider.DocumentFile
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

/** A library item can be backed by either MediaStore, a SAF document, or a direct file URI. */
data class VideoItem(
    val uri: Uri,
    val name: String,
    val duration: Long = 0L,
    val size: Long = 0L,
    val modified: Long = 0L,
    val folder: String = ""
)

class MediaRepository(private val context: Context) {
    fun hasFullStorageAccess(): Boolean = Build.VERSION.SDK_INT < 30 || Environment.isExternalStorageManager()

    /** Full scan when Android's special all-files permission is granted; otherwise MediaStore fallback. */
    suspend fun scanLibrary(): List<VideoItem> = withContext(Dispatchers.IO) {
        if (hasFullStorageAccess()) scanFilesystem() else scanMediaStore()
    }

    suspend fun scanFilesystem(): List<VideoItem> = withContext(Dispatchers.IO) {
        if (!hasFullStorageAccess()) return@withContext scanMediaStore()
        val root = Environment.getExternalStorageDirectory()
        val result = mutableListOf<VideoItem>()
        val visited = HashSet<String>()
        fun walk(dir: File, depth: Int) {
            if (depth > 32) return
            val canonical = try { dir.canonicalPath } catch (_: Exception) { return }
            if (!visited.add(canonical)) return
            // Android/data and Android/obb are protected app-private locations and are not scanned.
            if (dir.name.equals("data", true) && dir.parentFile?.name.equals("Android", true)) return
            if (dir.name.equals("obb", true) && dir.parentFile?.name.equals("Android", true)) return
            val children = try { dir.listFiles() } catch (_: SecurityException) { null } ?: return
            for (child in children) {
                try {
                    if (child.isDirectory) walk(child, depth + 1)
                    else if (child.isFile && isVideo(child.name)) {
                        result += VideoItem(Uri.fromFile(child), child.name, 0L, child.length(), child.lastModified(), child.parent ?: "")
                    }
                } catch (_: SecurityException) { /* Continue scanning accessible siblings. */ }
            }
        }
        walk(root, 0)
        result.distinctBy { it.uri.toString() }.sortedWith(compareBy(String.CASE_INSENSITIVE_ORDER) { it.name })
    }

    suspend fun scanMediaStore(): List<VideoItem> = withContext(Dispatchers.IO) {
        val result = mutableListOf<VideoItem>()
        val collection = MediaStore.Video.Media.getContentUri(MediaStore.VOLUME_EXTERNAL)
        val projection = arrayOf(MediaStore.Video.Media._ID, MediaStore.Video.Media.DISPLAY_NAME,
            MediaStore.Video.Media.DURATION, MediaStore.Video.Media.SIZE, MediaStore.Video.Media.DATE_MODIFIED,
            MediaStore.Video.Media.RELATIVE_PATH)
        try {
            context.contentResolver.query(collection, projection, null, null,
                "${MediaStore.Video.Media.DISPLAY_NAME} COLLATE NOCASE ASC")?.use { c ->
                val id = c.getColumnIndexOrThrow(MediaStore.Video.Media._ID)
                val name = c.getColumnIndexOrThrow(MediaStore.Video.Media.DISPLAY_NAME)
                val duration = c.getColumnIndexOrThrow(MediaStore.Video.Media.DURATION)
                val size = c.getColumnIndexOrThrow(MediaStore.Video.Media.SIZE)
                val modified = c.getColumnIndexOrThrow(MediaStore.Video.Media.DATE_MODIFIED)
                val folder = c.getColumnIndex(MediaStore.Video.Media.RELATIVE_PATH)
                while (c.moveToNext()) result += VideoItem(
                    ContentUris.withAppendedId(collection, c.getLong(id)), c.getString(name) ?: "Video",
                    c.getLong(duration), c.getLong(size), c.getLong(modified),
                    if (folder >= 0) c.getString(folder).orEmpty() else "")
            }
        } catch (_: SecurityException) { }
        result
    }

    suspend fun scanTree(treeUri: Uri): List<VideoItem> = withContext(Dispatchers.IO) {
        val root = DocumentFile.fromTreeUri(context, treeUri) ?: return@withContext emptyList()
        val result = mutableListOf<VideoItem>()
        fun walk(dir: DocumentFile, depth: Int) {
            if (depth > 32) return
            val children = try { dir.listFiles() } catch (_: Exception) { emptyArray() }
            children.forEach { f ->
                if (f.isDirectory) walk(f, depth + 1)
                else if (f.isFile && isVideo(f.name)) result += VideoItem(
                    f.uri, f.name ?: "Video", 0L, f.length(), f.lastModified(), dir.uri.toString())
            }
        }
        walk(root, 0)
        result.sortedWith(compareBy(String.CASE_INSENSITIVE_ORDER) { it.name })
    }

    private fun isVideo(name: String?): Boolean = name?.substringAfterLast('.', "")?.lowercase() in
        setOf("mp4", "mkv", "avi", "mov", "webm", "3gp", "mpg", "mpeg", "ts", "m4v", "wmv", "flv", "vob", "ogv", "m2ts")

    fun displayName(uri: Uri): String? = queryString(uri, OpenableColumns.DISPLAY_NAME)
    private fun queryString(uri: Uri, column: String): String? = try {
        context.contentResolver.query(uri, arrayOf(column), null, null, null)?.use { c ->
            if (c.moveToFirst()) c.getString(c.getColumnIndexOrThrow(column)) else null
        }
    } catch (_: Exception) { null }

    private fun incomingSize(uri: Uri): Long? = try {
        context.contentResolver.query(uri, arrayOf(OpenableColumns.SIZE), null, null, null)?.use { c ->
            if (c.moveToFirst() && !c.isNull(0)) c.getLong(0) else null
        }
    } catch (_: Exception) { null }

    /** Resolve a 1DM/content URI to our indexed file by name + size, then queue only its siblings. */
    suspend fun siblingCandidates(incoming: Uri): List<VideoItem> = withContext(Dispatchers.IO) {
        val all = scanLibrary()
        val name = displayName(incoming) ?: incoming.lastPathSegment?.substringAfterLast('/') ?: return@withContext emptyList()
        val candidates = all.filter { it.name.equals(name, ignoreCase = true) }
        if (candidates.isEmpty()) return@withContext emptyList()
        val size = incomingSize(incoming)
        val matched = if (size != null && size > 0) candidates.firstOrNull { it.size == size } else null
        val target = matched ?: candidates.first()
        val siblings = all.filter { it.folder == target.folder }
            .sortedWith(compareBy(String.CASE_INSENSITIVE_ORDER) { it.name })
        if (siblings.size > 1) siblings else listOf(target)
    }
}
