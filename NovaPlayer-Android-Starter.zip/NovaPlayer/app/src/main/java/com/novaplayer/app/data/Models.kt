package com.novaplayer.app.data

import android.net.Uri
import android.provider.DocumentsContract
import com.novaplayer.app.util.NaturalOrder

data class VideoItem(
    val uri: String,
    val name: String,
    val sizeBytes: Long = -1,
    val durationMs: Long = 0,
    val width: Int = 0,
    val height: Int = 0,
    val dateModifiedSec: Long = 0,
    val dateAddedSec: Long = 0,
    /** Relative folder such as "Download/1DM/" ("" when unknown or at the volume root). */
    val folderPath: String = "",
    val volume: String = "external_primary",
    val mimeType: String? = null,
    val isAudio: Boolean = false,
) {
    /** Stable identity used for favourites and resume positions (content URIs can change). */
    val key: String get() = if (uri.startsWith("file:")) uri else "$name|$sizeBytes"
    val title: String get() = name.substringBeforeLast('.', name)
    val folderName: String
        get() = folderPath.trimEnd('/').substringAfterLast('/').ifEmpty { "Storage root" }
    val resolutionLabel: String? get() = if (width > 0 && height > 0) "${width}×${height}" else null
}

enum class SortField(val label: String) {
    NAME("Name"), DATE("Date"), DURATION("Duration"), SIZE("Size")
}

data class FolderEntry(
    val path: String,
    val name: String,
    val count: Int,
    val thumb: VideoItem?,
    val totalBytes: Long,
)

data class AuthorisedFolder(val uri: String, val name: String)

data class HistoryEntry(
    val video: VideoItem,
    val positionMs: Long,
    val durationMs: Long,
    val lastPlayed: Long,
) {
    val progress: Float
        get() = if (durationMs > 0) (positionMs.toFloat() / durationMs).coerceIn(0f, 1f) else 0f

    /** Worth offering "continue watching": started, but not (nearly) finished. */
    val resumable: Boolean
        get() = durationMs > 0 && positionMs > 5_000 && positionMs < durationMs * 0.95
}

/** One row of a Storage Access Framework directory listing. */
data class SafEntry(
    val docId: String,
    val uri: Uri,
    val name: String,
    val mime: String?,
    val size: Long,
    val modifiedMs: Long,
) {
    val isDir: Boolean get() = mime == DocumentsContract.Document.MIME_TYPE_DIR
}

data class AppSettings(
    // appearance / library
    val accent: Int = 0,
    val libraryGrid: Boolean = true,
    val gridColumns: Int = 2,
    val showThumbnails: Boolean = true,
    val sortField: String = "NAME",
    val sortAscending: Boolean = true,
    val rememberFolder: Boolean = true,
    val lastFolder: String = "root",
    // playback
    val resume: Boolean = true,
    val autoNext: Boolean = true,
    val repeatMode: Int = 0,
    val defaultSpeed: Float = 1f,
    val rememberPlayback: Boolean = true,
    val defaultResize: Int = 0,
    val seekStepSec: Int = 10,
    // player
    val controlsTimeoutSec: Int = 4,
    val orientationMode: Int = 0,
    val bgPlayback: Boolean = false,
    val pip: Boolean = true,
    val softwareDecoder: Boolean = false,
    // gestures
    val gestures: Boolean = true,
    val seekSens: Float = 1f,
    val brightnessSens: Float = 1f,
    val volumeSens: Float = 1f,
    val doubleTapSec: Int = 10,
    // subtitles
    val subSize: Float = 20f,
    val subColor: Int = 0xFFFFFFFF.toInt(),
    val subBottom: Float = 0.08f,
    val subBackground: Float = 0.35f,
    val subAutoLoad: Boolean = true,
) {
    val sort: SortField get() = runCatching { SortField.valueOf(sortField) }.getOrDefault(SortField.NAME)
}

object FolderOps {
    fun direct(videos: List<VideoItem>, prefix: String): List<VideoItem> =
        videos.filter { it.folderPath == prefix }

    /** Immediate sub-folders of [prefix], with recursive video counts. */
    fun subfolders(videos: List<VideoItem>, prefix: String): List<FolderEntry> =
        videos.filter { it.folderPath.length > prefix.length && it.folderPath.startsWith(prefix) }
            .groupBy { prefix + it.folderPath.removePrefix(prefix).substringBefore('/') + "/" }
            .map { (path, list) ->
                FolderEntry(
                    path = path,
                    name = path.trimEnd('/').substringAfterLast('/'),
                    count = list.size,
                    thumb = list.maxByOrNull { it.dateModifiedSec },
                    totalBytes = list.sumOf { maxOf(it.sizeBytes, 0L) },
                )
            }
            .sortedWith(compareBy<FolderEntry, String>(NaturalOrder) { it.name })

    /** Every folder that directly holds videos, regardless of nesting. */
    fun flat(videos: List<VideoItem>): List<FolderEntry> =
        videos.groupBy { it.folderPath }
            .map { (path, list) ->
                FolderEntry(
                    path = path,
                    name = if (path.isEmpty()) "Storage root" else path.trimEnd('/').substringAfterLast('/'),
                    count = list.size,
                    thumb = list.maxByOrNull { it.dateModifiedSec },
                    totalBytes = list.sumOf { maxOf(it.sizeBytes, 0L) },
                )
            }
            .sortedWith(compareBy<FolderEntry, String>(NaturalOrder) { it.name })
}

fun List<VideoItem>.sortedByField(field: SortField, ascending: Boolean): List<VideoItem> {
    val cmp: Comparator<VideoItem> = when (field) {
        SortField.NAME -> compareBy<VideoItem, String>(NaturalOrder) { it.name }
        SortField.DATE -> compareBy<VideoItem> { it.dateModifiedSec }
        SortField.DURATION -> compareBy<VideoItem> { it.durationMs }
        SortField.SIZE -> compareBy<VideoItem> { it.sizeBytes }
    }
    return sortedWith(if (ascending) cmp else cmp.reversed())
}
