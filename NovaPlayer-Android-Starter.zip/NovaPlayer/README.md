# NovaPlayer Android project

NovaPlayer is an offline-first Android video-player project built with Kotlin, Jetpack Compose and AndroidX Media3.

## Build

Requirements: Android Studio with JDK 17, Android SDK Platform 35 and Android Build Tools 35.0.0.

From the project directory:

```bash
gradle :app:assembleDebug
```

The debug APK is written to `app/build/outputs/apk/debug/app-debug.apk`.

A GitHub Actions workflow is included at `.github/workflows/build-apk.yml`. It installs the Android SDK packages and builds the debug APK. The repository workflow can be run manually using `workflow_dispatch`.

## Current implementation

- `ACTION_VIEW` and `ACTION_SEND` handling for `video/*` incoming intents, including `data`, `ClipData` and `EXTRA_STREAM`.
- Media3 playback, seek bar, play/pause, previous/next, 10-second skip, playback speed choices, tap-to-toggle controls and double-tap seek.
- Landscape immersive playback mode and a custom NovaPlayer launcher icon.
- SAF tree selection, persisted read permission, recursive `DocumentFile` folder scan and a remembered authorised tree.
- MediaStore video listing, basic library/folder screens, search and settings UI.
- No ad or analytics SDKs are included.

## Important limitations — not release-certified

This is not yet a feature-complete MX Player replacement. The following need further implementation and/or device validation: robust matching across arbitrary 1DM document-provider URIs (including providers that expose different display names), full folder management and nested-folder navigation UI, vertical volume/brightness gestures, swipe seeking, subtitle file picker and subtitle delay/style controls, PiP, background playback service, audio-only mode, sleep timer, hardware/software decoder switching, detailed media metadata, thumbnails in all library views, favourites/history persistence, comprehensive settings, and accessibility/localisation.

Android providers do not generally expose a parent directory for a shared `content://` URI. NovaPlayer therefore cannot guarantee automatic folder discovery from 1DM. The SAF folder picker is the supported fallback; once a folder is authorised, its permission is persisted where the provider supports it. Real 1DM behaviour must be verified on the target phone.

## Permissions

The manifest declares media read permissions for MediaStore discovery and uses the Storage Access Framework for user-selected folders. SAF permissions are granted by the user and persisted by the app. No broad all-files access permission is requested.

## QA status

Source archive integrity was checked. The project has **not** been built with a local Android SDK or tested on a physical Samsung Galaxy S25 Ultra in this environment. Run the included GitHub Actions workflow and test 1DM → Open with → NovaPlayer on-device before treating any build as release-ready.
