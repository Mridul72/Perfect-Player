# Nova Player (Perfect-Player project)

Android video-player prototype using Jetpack Compose and Media3 ExoPlayer.

## 1DM folder playback

When a video is shared from 1DM, Android may grant access only to that individual content URI, not the containing folder. In that case, tap the folder icon in Nova Player and select the exact folder containing the downloaded videos. The app persists the selected folder read permission and builds a playlist from video files directly inside that folder. The original 1DM URI is retained for the currently opened video; sibling videos are opened through the selected SAF folder permission.

MediaStore-backed video URIs are also grouped by their MediaStore relative path when possible.

This is a prototype. Folder access depends on the storage provider exposing child documents and on Android allowing the selected folder. Test with the actual 1DM download location on the target device before treating the feature as production-ready.

## Build

Open with Android Studio or use the repository's GitHub Actions workflow. The project uses Java/Kotlin JVM target 17, compile SDK 35, and Media3 ExoPlayer.
