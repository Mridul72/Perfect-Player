# Nova Player (prototype 0.1.0)

A native Android video-player starter focused on MX Player-style folder playback and 1DM `ACTION_VIEW` integration.

## Current implementation
- Registers as a handler for `video/*` `ACTION_VIEW` intents.
- Uses Android Media3 ExoPlayer for playback.
- For MediaStore-backed incoming URIs, queries videos in the same `RELATIVE_PATH`, sorts by filename, and creates a playlist.
- Falls back to playing the incoming URI alone when the provider does not expose MediaStore folder metadata.
- AMOLED-style Compose playback shell.

## Important limitation
1DM may provide a `content://` URI that is not a MediaStore URI, or may grant access only to the selected file. In that case Android does not let this app enumerate sibling files from the URI alone. A production build needs a persisted SAF folder grant / folder selection flow and provider-specific testing. This prototype does not yet implement the complete SAF permission persistence flow, full folder browser, subtitle UI, or gesture controls.

## Build
Open this folder in Android Studio (Hedgehog or newer), allow Gradle sync, then Build > Build Bundle(s) / APK(s) > Build APK(s). The generated APK is under `app/build/outputs/apk/debug/`.

Target: Android 15 / API 35; min API 26.
