# NovaPlayer — Android project

Kotlin + Jetpack Compose + AndroidX Media3 video player project.

## Automatic library discovery (the important change)

NovaPlayer now has two discovery paths:

1. **Automatic full shared-storage scan:** on Android 11+, first launch asks once for Android's special **All files access** permission. After the user enables it, NovaPlayer recursively scans shared internal storage itself, including dot-prefixed/hidden directories and folders containing `.nomedia`, then indexes videos by their actual parent directory. It excludes Android/data and Android/obb because Android protects those app-private locations.
2. **MediaStore fallback:** if the special permission is declined, NovaPlayer uses Android's indexed video collection. This is less complete: Android's media index can omit hidden or `.nomedia` content.

When opened through another app (for example 1DM), NovaPlayer starts the exact incoming URI immediately. It then resolves the incoming item against its library by display filename and, when available, file size; once matched, it replaces the one-item playback with the sorted sibling-video queue from the same directory. This avoids relying on equality between unrelated `content://` and `file://` URIs.

The Library settings page also provides a button to reopen Android's All files access settings if the first request was declined. SAF folder selection remains as a fallback for storage providers or locations Android does not expose through shared storage.

### Android permission reality

This is not a silent permission. Android requires the user to grant All files access in system settings. It is a special, sensitive permission and Google Play restricts which apps may request it; this project is intended for personal/sideload testing unless its distribution eligibility is reviewed. Even with it, Android/data and Android/obb remain inaccessible. If the user declines, hidden and `.nomedia` folders cannot be guaranteed to appear.

## Build

Requirements: Android Studio, JDK 17, Android SDK Platform 35 and Build Tools 35.0.0.

```bash
gradle :app:assembleDebug
```

The debug APK is written to `app/build/outputs/apk/debug/app-debug.apk`. The included GitHub Actions workflow can build the project in CI. The checked-in `gradlew` is a bootstrap placeholder; generate the standard wrapper from Android Studio/Gradle (`gradle wrapper --gradle-version 8.9`) before relying on `./gradlew` outside CI.

## Included functionality

- `ACTION_VIEW` / `ACTION_SEND` video handoff, Media3 playback, seek bar, play/pause, next/previous, 10-second skip, basic speed selection, landscape immersive mode.
- MediaStore fallback, recursive filesystem scan with All files access, recursive SAF scan, filename/size matching for incoming provider URIs, same-directory sibling queue.
- Basic Compose Home, Folders, Videos and Settings screens; dark styling; no ad or analytics SDKs.

## Not yet feature-complete

This is still a starter build, not MX Player parity. PiP, background playback service, external subtitle browser and delay controls, full audio-track UI, decoder selection, advanced gesture controls, thumbnails, favourites/history persistence, sleep timer, and comprehensive settings remain incomplete. The 1DM handoff and folder matching must be tested on the actual Samsung device with the specific 1DM version and file provider.

## QA status

The source archive is packaged, but this environment has no Android SDK/Gradle installation and no connected Samsung device. Therefore this revision has **not** been compiled or device-tested here. Run the CI build and verify: (a) All files access is granted, (b) hidden and `.nomedia` directories appear, and (c) opening a video in `Download/1DMP/Videos` from 1DM creates a Next/Previous queue containing only that directory's videos.
