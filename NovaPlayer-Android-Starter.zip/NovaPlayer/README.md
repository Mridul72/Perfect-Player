# NovaPlayer

NovaPlayer is an offline-first Android video player foundation built with Kotlin, Jetpack Compose and AndroidX Media3.

## Build
- Android Studio Ladybug or newer
- JDK 17
- Android SDK platform 35
- Run `./gradlew :app:assembleDebug`

## 1DM and folder access
NovaPlayer accepts video `ACTION_VIEW` and `ACTION_SEND` intents. Android providers may share only a single document URI; that does not grant parent-folder access. Use **Folders → Choose folder** or the folder button in the player to grant persistent SAF access. The app then scans the authorised tree and builds a filename-sorted queue.

## Current implementation status
Implemented: intent entry points, MediaStore video listing, SAF folder-tree permission and recursive scan, basic Compose library/folders/settings surfaces, Media3 playback, seek bar, play/pause, skip 10 seconds and queue navigation for an authorised folder.

Not yet implemented or device-verified: production-grade thumbnails and metadata extraction, persisted playback history/favourites, complete subtitle UI and sync, audio track/decoder settings, PiP/background playback, configurable gestures, sleep timer, robust matching of a 1DM provider URI to a SAF document, full Android 16 permission edge cases, and physical 1DM acceptance testing.

This project must be treated as an engineering baseline, not a verified MX Player replacement. Test on the target device before release.
